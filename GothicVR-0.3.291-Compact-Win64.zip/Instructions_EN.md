# Gothic Remake VR 0.3.291 · Tester guide

[English](#english) · [Русский](#русский)

## English

This compact kit downloads **70.5 MB** from GitHub on the first installation for UEVR and GORE. Select **Install** with an internet connection. Setup verifies both downloads and keeps them in **%LOCALAPPDATA%/GothicVR/SetupCache** for reuse. If a download fails, restore the connection and select **Install** again. The installer music can start once GORE is ready.

**Creators — Anunnak & Codex**

### Install

1. Install Gothic 1 Remake through Steam on Windows x64. This kit checks for **Build106_CL176207**. Connect the headset and both controllers to PCVR and confirm that the headset can display your PCVR home.
2. Close Gothic. Extract **all** of the ZIP into a normal folder on your PC. Keep **Setup.exe** and **Package** together. Open **Setup.exe**.
3. Check the detected game folder. Use **Browse…** to select the folder containing the **G1R** subfolder if necessary. **Create a GothicVR desktop shortcut** adds the desktop icon. **Play the music from Xardas’ tower** enables the soundtrack. Select **Install**, wait for completion, then select **Close**. Setup installs UEVR and the helpers’ Python runtime.
4. Start **GothicVR 0.3.291** from the desktop or Start menu with your headset connected. The launcher opens the game through Steam, starts the menu mouse and telemetry helpers, and asks the bundled UEVR frontend to attach to Gothic. Accept a Windows prompt from UEVR if it appears. If the game shows its mod selection screen, enable **GothicVRBridge** and continue. Load a save or start a game in Gothic.

### First session

The working VR preset starts automatically on a fresh profile. **Insert → LuaLoader → Script UI** opens its settings on the PC. Adjust eye height while standing or sitting in your usual playing position. Use the 1 cm buttons for small adjustments and **Recenter view** to reorient the headset. You can also adjust the body turn threshold, toggle the graphics profile or show FPS. Close the UEVR overlay with **Insert** before playing. An existing calibration or an explicitly disabled VR preset is respected.

On Quest, **X** opens the inventory. Aim with the right controller and click with the right trigger. To assign a potion, click it and then click a free quick slot. If the slots are hidden, point at the potion, hold the left trigger, click the slot with the right trigger, then release the left trigger. **B** opens the VR quick wheel. In save/load screens, aim with your right hand and click with the **left trigger**. In dialogue, use the right stick and **A**.

### Troubleshooting

| Symptom | What to do |
| --- | --- |
| Setup cannot find the game or reports a build mismatch | In Steam, open Gothic’s installed files and browse to the game root. Check **G1R/Version/version.txt**. This kit is built for the version listed above. |
| Sound plays but the headset stays in PCVR home | Wait for the game menu. Open the bundled UEVR frontend, select **G1R-Win64-Shipping**, choose your working **OpenXR** or **OpenVR** runtime and press **Inject** once. Keep the game window in the foreground. If another UEVR instance was already open, use a single frontend for the next launch. |
| Hands, body or wheel are missing | With the save loaded, open **Insert → LuaLoader → Main → Reset scripts**. Open **Script UI**, check the main VR preset and close the overlay. |
| Inventory cursor is stuck | Close the UEVR overlay, click the Gothic window on the PC and reopen the inventory with **X**. Use the GothicVR shortcut for the next session so the mouse helper starts. For assignment, use the left-trigger gesture above. |
| A game script or patch error appears at startup | Close Gothic completely. Rerun **Setup.exe** for the correct game build. Reset scripts reloads Lua only. If Setup reports a modified legacy module, back up that named file outside the game’s Mods folder before retrying. |
| Camera height or tracking feels wrong | Get into the position you normally use. Recenter in the headset, then use the eye height setting in **Script UI**. |
| FPS falls or headset motion looks uneven | Enable the FPS display. Compare the optional VR graphics profile on and off in the same spot. Check the PCVR connection and headset render resolution. |
| Music does not start during setup | Select the correct game folder and enable the music checkbox. Setup reads the tower theme from **G1R/Content/FMOD/Desktop/Music.bank**. |

### Files and repair

The game bridge is installed under **G1R/Mods/GothicVRBridge**. The UEVR profile is under **%APPDATA%/UnrealVRMod/G1R-Win64-Shipping**. The launcher and installed copies of these guides are under **%LOCALAPPDATA%/GothicVR/0.3.291**. Setup preserves existing profile defaults and makes backups of replaced files under **%LOCALAPPDATA%/GothicVR/Backups**. Each backup’s **changes.json** maps file paths to backup copies. Reinstall with the game closed to repair the mod. For a flat session, close Gothic and UEVR, launch through Steam and disable GothicVRBridge in the game’s mod selection.

When reporting a problem, include the version, headset, VR runtime, exact action and whether it happened after loading or resetting scripts. The profile’s **data** folder holds the mod’s reports, including **gothic_vr_mouse_bridge_status.json** for the pointer and **gothic_vr_inventory_assignment.json** for slots. Game crash reports are normally under **%LOCALAPPDATA%/G1R/Saved/Crashes**.

## Русский

При первой установке компактная версия скачивает с GitHub **70,5 МБ** для UEVR и GORE. Подключитесь к интернету и нажмите **Install**. Установщик проверит контрольные суммы и сохранит файлы в **%LOCALAPPDATA%/GothicVR/SetupCache** для повторной установки. При обрыве связи восстановите подключение и снова нажмите **Install**. Музыка установщика сможет заиграть после подготовки GORE.

**Авторы — Anunnak и Codex**

### Установка

1. Установите Gothic 1 Remake из Steam на Windows x64. Установщик проверяет версию **Build106_CL176207**. Подключите шлем и оба контроллера к ПК и убедитесь, что в шлеме открывается домашнее пространство PCVR.
2. Закройте Gothic. **Полностью распакуйте ZIP** в обычную папку. Оставьте **Setup.exe** и папку **Package** рядом. Запустите **Setup.exe**.
3. В окне установки проверьте путь к игре. Кнопка **Browse…** позволяет выбрать папку, внутри которой находится **G1R**. Галочка **Create a GothicVR desktop shortcut** добавляет ярлык на рабочий стол, а **Play the music from Xardas’ tower** включает музыку. Нажмите **Install**, дождитесь завершения и нажмите **Close**. Установщик подготовит UEVR и Python для помощников.
4. С подключённым шлемом откройте **GothicVR 0.3.291** с рабочего стола или из меню «Пуск». Лаунчер запускает игру через Steam, помощник мыши, монитор и подключение штатного UEVR к Gothic. Если Windows покажет запрос на запуск UEVR, подтвердите его. Если Gothic откроет выбор модов, отметьте **GothicVRBridge** и продолжите. Загрузите сохранение или начните новую игру.

### Первый запуск и управление

На новом профиле рабочий VR включается автоматически. На ПК откройте **Insert → LuaLoader → Script UI**. Встаньте или сядьте в привычное положение, отрегулируйте высоту глаз. Для подстройки есть шаг в 1 см и кнопка центрирования вида. Здесь же можно поменять угол доворота корпуса, включить графический профиль и вывести FPS. Перед игрой закройте оверлей клавишей **Insert**. При обновлении сохраняются прежняя калибровка и явное отключение рабочего VR.

На Quest кнопка **X** открывает инвентарь. Правая рука наводит указатель, правый курок выбирает предмет. Чтобы поставить зелье в быстрый слот, нажмите правым курком на зелье и на свободную ячейку. Если ячейки скрыты, наведитесь на зелье, удерживайте левый курок, щёлкните правым по ячейке и отпустите левый. **B** открывает круг предметов. В меню сохранения и загрузки наводите правую руку и нажимайте **левый курок**. В диалогах используйте правый стик и **A**.

### Если возникла проблема

| Что происходит | Что сделать |
| --- | --- |
| Установщик не видит игру или сообщает о другой сборке | В Steam откройте установленные файлы Gothic и выберите корень игры. Сверьте значение в **G1R/Version/version.txt** с версией выше. |
| В шлеме только звук или домашнее пространство PCVR | Дождитесь главного меню. Откройте окно UEVR из комплекта, выберите **G1R-Win64-Shipping**, свой рабочий режим **OpenXR** или **OpenVR** и один раз нажмите **Inject**. Вернитесь в окно Gothic. Если до запуска был открыт ещё один UEVR, при следующем запуске оставьте один экземпляр. |
| После загрузки пропали руки, тело или круг | При загруженном сохранении откройте **Insert → LuaLoader → Main → Reset scripts**. В **Script UI** проверьте общую галочку VR. Закройте оверлей. |
| Курсор инвентаря стоит на месте | Закройте оверлей UEVR, щёлкните окно игры на ПК и заново откройте инвентарь кнопкой **X**. В следующую сессию входите через ярлык GothicVR, чтобы запустился помощник мыши. Для ячеек используйте жест с левым курком, описанный выше. |
| При запуске ошибка игрового скрипта или патча | Полностью закройте Gothic и повторите установку для поддерживаемой версии игры. Reset scripts перезагружает только Lua. Если установщик нашёл изменённый старый модуль, сохраните указанный файл отдельно за пределами папки Mods и повторите установку. |
| Камера высоко, низко или смотрит в сторону | Займите привычное игровое положение, выполните центрирование шлема и подберите высоту глаз в **Script UI**. |
| Появились рывки или низкий FPS | Включите счётчик и сравните графический профиль в одной сцене. Проверьте подключение PCVR и разрешение рендеринга шлема. |
| При установке нет музыки | Выберите папку игры и включите галочку музыки. Тема башни Ксардаса берётся из **G1R/Content/FMOD/Desktop/Music.bank**. |

### Где лежат файлы

Игровой модуль устанавливается в **G1R/Mods/GothicVRBridge**. Профиль UEVR находится в **%APPDATA%/UnrealVRMod/G1R-Win64-Shipping**. Лаунчер и инструкции остаются в **%LOCALAPPDATA%/GothicVR/0.3.291**. Существующие настройки профиля сохраняются. Резервные копии заменённых файлов находятся в **%LOCALAPPDATA%/GothicVR/Backups**. В каждой папке **changes.json** связывает путь с его резервной копией. Для восстановления комплекта закройте игру и повторите установку. Чтобы поиграть на мониторе, закройте Gothic и UEVR, запустите игру из Steam и отключите GothicVRBridge в выборе модов.

Для отчёта о проблеме укажите версию, шлем, режим VR, действие перед сбоем и была ли перед ним загрузка или Reset scripts. В папке **data** профиля лежат отчёты мода. Для курсора пригодится **gothic_vr_mouse_bridge_status.json**, для быстрых ячеек — **gothic_vr_inventory_assignment.json**. Отчёты аварий игры обычно находятся в **%LOCALAPPDATA%/G1R/Saved/Crashes**.
