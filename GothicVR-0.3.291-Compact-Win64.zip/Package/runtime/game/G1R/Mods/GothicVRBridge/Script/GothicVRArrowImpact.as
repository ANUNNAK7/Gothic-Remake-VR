// These are the stock arrow's impact decisions. All ordinary hit effects,
// penetration, attachment and bounce stay in the game's projectile code.
UCLASS(meta=(ReplaceParentClass))
class ABowArrowProjectileVisual_GothicVR : ABowArrowProjectileVisual
{
    void RecordContact(AActor HitActor)
    {
        auto Runtime = UGothicVRInventoryBridge.GetDefaultObject().Runtime;
        if (IsValid(Runtime)) Runtime.ObserveBowContact(this, HitActor);
    }

    UFUNCTION(BlueprintOverride)
    bool CanAttachArrowOnHitActor_Scriptable(AActor HitActor, float surfaceHardness)
    {
        RecordContact(HitActor);
        return Super::CanAttachArrowOnHitActor_Scriptable(HitActor, surfaceHardness);
    }

    UFUNCTION(BlueprintOverride)
    bool HasBouncingWhenHit_Scriptable(AActor HitActor, float surfaceHardness)
    {
        RecordContact(HitActor);
        return Super::HasBouncingWhenHit_Scriptable(HitActor, surfaceHardness);
    }
}
