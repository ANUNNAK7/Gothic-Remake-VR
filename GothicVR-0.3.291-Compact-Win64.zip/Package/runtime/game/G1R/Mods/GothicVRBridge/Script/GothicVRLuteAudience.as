class UVRLuteConductor : UActorComponent
{
    // Transient, passive registry on the musician. No world or NPC references are retained.
    UPROPERTY(Transient) TSet<int> Active;
    UPROPERTY(Transient) TMap<int, float> Turned;
    int NextSerial = 0;
    float Expires = -1.0f;

    int Admit()
    {
        NextSerial++;
        Active.Add(NextSerial);
        return NextSerial;
    }

    bool Live(AGothicCharacter Hero, int Serial) const
    {
        return IsValid(Hero) && Hero == GetOwner() && Hero.GetGameTimeSinceCreation() < Expires && Active.Contains(Serial);
    }
}

class UVRLuteApplauseState : UGothicCharacterAIState
{
    // Actor and value are explicitly reflected so that DoInterruptState's duplicate/template
    // resolves the same musician and serial, independent of the identity of the AI state.
    UPROPERTY() AGothicCharacter Musician;
    UPROPERTY() int Serial = 0;

    bool CanListen(UVRLuteConductor Board) const
    {
        return IsValid(Board) && Board.Live(Musician, Serial) && VRLuteInRange(Musician, Self) &&
            VRLuteCanInterrupt(Self, Musician) && !bShouldExitState;
    }

    UFUNCTION(BlueprintOverride)
    void DoTask()
    {
        if (!IsValid(Musician)) return;
        auto Board = UVRLuteConductor::Get(Musician);
        if (!CanListen(Board)) return;
        AI.EndAnyOngoingInteraction();
        if (!CanListen(Board)) return;
        AI.TurnToCharacter(Musician);
        if (!CanListen(Board)) return;
        // The conductor plays the visible montage; the routine only holds its place until release.
        while (CanListen(Board))
        {
            Board.Turned.Add(Serial, Musician.GetGameTimeSinceCreation());
            WaitSeconds(0.32f);
        }
    }

    UFUNCTION(BlueprintOverride)
    void OnGracefulExitRequested()
    {
        bShouldExitState = true;
        StopWaitingAndContinueTask();
    }
}
struct FVRLuteListener
{
    UPROPERTY() AGothicCharacter NPC;
    int Serial = 0;
    bool FacingReady = false;
    UPROPERTY() UAnimInstance Anim;
    UPROPERTY() UAnimMontage Performance;
    UPROPERTY() UCharacterAIState PreviousState;
    FVector StartPosition;
    FVector LastFacing;
    FRotator StartRotation;
    bool TurnedIdle = false;
    bool OwnsClip = false;
    bool Playing = false;
    bool SeenPlaying = false;
    float NextClip = 0.0f;
    float ClipDeadline = 0.0f;
    float WaitUntil = 0.0f;

    // Returns true only on a new visible performance. Both the scheduled audience and
    // stationary actors without an AI schedule follow this exact presentation path.
    bool Present(float Now, FName LoopSection)
    {
        Playing = OwnsClip && Anim.Montage_IsPlaying(Performance);
        if (Playing && Now >= ClipDeadline)
        {
            Anim.Montage_Stop(0.24f, Performance);
            NextClip = Now + 0.45f;
            Playing = false;
            OwnsClip = false;
            return false;
        }
        if (Playing || Now < NextClip || Anim.Montage_IsPlaying(Performance)) return false;
        NextClip = Now + 1.0f;
        if (NPC.PlayAnimMontage(Performance, 1.0f, n"Entry") <= 0.0f) return false;
        Anim.Montage_SetNextSection(n"Entry", LoopSection, Performance);
        Anim.Montage_SetNextSection(LoopSection, n"None", Performance);
        OwnsClip = true;
        ClipDeadline = Now + 6.0f;
        Playing = Anim.Montage_IsPlaying(Performance);
        return Playing;
    }
}

struct FVRLuteCheers
{
    float NextCall = -1.0f;
    int Cursor = 0;
    int Accepted = 0;
    int Attempts = 0;
    int Missing = 0;
    int Rejected = 0;
    int Spoken = 0;

    void Reset()
    {
        NextCall = -1.0f; Cursor = 0; Accepted = 0;
    }

    bool Say(AGothicCharacter Speaker)
    {
        Attempts++;
        auto Speech = Speaker.CharacterState.Voiceline;
        if (!IsValid(Speech)) { Missing++; return false; }
        FGameplayTag First = GameplayTag::Sound_Voice_Reaction_Concert_Appreciate;
        FGameplayTag Second = GameplayTag::Sound_Voice_Reaction_Concert_Brawl;
        if (Accepted % 2 == 1)
        {
            First = GameplayTag::Sound_Voice_Reaction_Concert_Brawl;
            Second = GameplayTag::Sound_Voice_Reaction_Concert_Appreciate;
        }
        FGenericVoicelineRequestContext Context;
        FGameplayTag Line = First;
        // A public audience call, addressed like the stock untargeted barks.
        if (!Speech.HasVoicelineForWithContext(First, nullptr, Context))
        {
            Line = Second;
            if (!Speech.HasVoicelineForWithContext(Second, nullptr, Context))
            {
                Line = GameplayTag::Sound_Voice_Reaction_Interjection_Happy;
                if (!Speech.HasVoicelineForWithContext(Line, nullptr, Context)) { Missing++; return false; }
            }
        }
        if (!Speech.SayVoicelineWithContext(Line, nullptr, Context, EPerceptionNoiseLoudness::Loud))
        { Rejected++; return false; }
        Spoken++;
        return true;
    }

    void Tick(AGothicCharacter Hero, const TArray<FVRLuteListener>&in Listeners, float Now)
    {
        int Count = Listeners.Num();
        if (Count == 0 || !IsValid(Hero.CharacterState)) return;
        if (NextCall < 0.0f) { NextCall = Now + 2.5f; return; }
        if (Now < NextCall) return;
        // Visit a few listeners per opportunity, rotating past missing or busy voices.
        NextCall = Now + 1.25f;
        for (int I = 0; I < Math::Min(Count, 4); I++)
        {
            int Index = Cursor % Count;
            Cursor = (Index + 1) % Count;
            if (!Listeners[Index].FacingReady) continue;
            auto Speaker = Listeners[Index].NPC;
            if (!VRLuteInRange(Hero, Speaker) || !VRLuteCanInterrupt(Speaker, Hero) || Speaker.CharacterState.IsSpeaking()) continue;
            if (Say(Speaker))
            {
                Accepted += 1;
                NextCall = Now + Math::RandRange(7, 12);
                return;
            }
        }
    }
}

struct FVRLuteAudience
{
    UPROPERTY() TArray<FVRLuteListener> Listeners;
    UPROPERTY() UAnimMontage Clap;
    UPROPERTY() UAnimMontage SeatedClap;
    UPROPERTY() FVRLuteCheers Chorus;
    UPROPERTY() FVRLuteDistrict District;
    UPROPERTY() UVRLuteConductor Board;
    int ScanCursor = 0;
    UPROPERTY() int LastNearby = 0;
    UPROPERTY() int Joined = 0;
    UPROPERTY() int Applauded = 0;
    UPROPERTY() int RoutineTasks = 0;
    UPROPERTY() int DirectClips = 0;
    UPROPERTY() int Released = 0;
    bool Requested = false;
    bool CheerAudible = false;
    bool Pulse = false;
    bool TriedAsset = false;
    float Until = 0.0f;
    float NextScan = 0.0f;
    float NextCheck = 0.0f;

    void Release(int I, AGothicCharacter Hero)
    {
        auto L = Listeners[I];

        if (IsValid(Hero) && IsValid(Board) && Board.GetOwner() == Hero)
        {
            Board.Active.Remove(L.Serial);
            Board.Turned.Remove(L.Serial);
        }
        if (IsValid(Hero) && IsValid(L.NPC) && L.NPC.GetWorld() == Hero.GetWorld())
        {
            if (L.Serial > 0 && IsValid(Board) && Board.GetOwner() == Hero)
            {
                auto AI = L.NPC.GetGothicAI();
                if (IsValid(AI))
                {
                    auto Routine = AI.GetDailyRoutineIfActive();
                    if (IsValid(Routine))
                    {
                        auto Owned = Cast<UVRLuteApplauseState>(Routine.InterruptState);
                        if (IsValid(Owned) && Owned.Serial == L.Serial && Owned.Musician == Hero)
                            Owned.OnGracefulExitRequested();
                    }
                }
            }
            if (IsValid(L.Anim) && IsValid(L.Performance))
            {
                bool OwnClip = L.OwnsClip && L.Anim.Montage_IsPlaying(L.Performance);
                auto Active = L.NPC.GetCurrentMontage();
                auto AI = L.NPC.GetGothicAI();
                bool SameState = IsValid(AI) ? AI.CurrentState == L.PreviousState : !IsValid(L.PreviousState);
                if (L.TurnedIdle && SameState && VRLuteCanInterrupt(L.NPC, Hero) &&
                    (!IsValid(Active) || (OwnClip && Active == L.Performance)) && !L.NPC.CharacterState.IsDoingAnyInteraction() &&
                    L.NPC.GetVelocity().SizeSquared() < 25.0f && (L.NPC.GetActorLocation()-L.StartPosition).SizeSquared() < 25.0f &&
                    L.NPC.GetActorForwardVector().DotProduct(L.LastFacing) > 0.995f)
                    L.NPC.SetActorRotation(L.StartRotation);
                if (OwnClip) L.Anim.Montage_Stop(0.24f, L.Performance);
            }
        }
        Listeners.RemoveAt(I);
        Released++;
    }

    void Clear(AGothicCharacter InWorldHero)
    {
        for (int I = Listeners.Num()-1; I >= 0; I--) Release(I, InWorldHero);
        Requested = false; Pulse = false; CheerAudible = false; NextScan = 0.0f; NextCheck = 0.0f; Until = 0.0f;
        TriedAsset = false; Clap = nullptr; SeatedClap = nullptr; ScanCursor = 0;
        Chorus.Reset();
        if (IsValid(InWorldHero) && IsValid(Board) && Board.GetOwner() == InWorldHero)
        { Board.Active.Reset(); Board.Turned.Reset(); Board.Expires = -1.0f; }
        Board = nullptr;
        District.Reset();
    }

    void Invite(AGothicCharacter Hero, float Now)
    {
        District.Refresh(Hero, Now);
        LastNearby = District.Candidates.Num();
        if (LastNearby == 0) { ScanCursor = 0; return; }
        int Checked = 0;
        int Added = 0;
        while (Checked < LastNearby && Checked < 32 && Added < 5)
        {
            ScanCursor = ScanCursor % LastNearby;
            auto N = District.Candidates[ScanCursor];
            ScanCursor++; Checked++;
            if (!VRLuteCanInterrupt(N, Hero) || !District.InRange(Hero, N)) continue;
            bool Occupied = false;
            for (int J = 0; J < Listeners.Num(); J++)
            {
                if (Listeners[J].NPC == N) { Occupied = true; break; }
            }
            if (Occupied) continue;
            FVRLuteListener L;
            L.NPC = N;
            L.WaitUntil = Now + 0.2f + 0.12f * Added;
            auto AI = N.GetGothicAI();
            if (IsValid(AI) && IsValid(AI.GetDailyRoutineIfActive()))
            {
                // Gothic exposes one interrupt slot; never overwrite an unrelated in-flight response.
                if (AI.GetDailyRoutineIfActive().IsDoingInterruptState()) continue;
                if (!IsValid(Board)) continue;
                L.Serial = Board.Admit();
                auto Reaction = Cast<UVRLuteApplauseState>(NewObject(AI, UVRLuteApplauseState::StaticClass()));
                Reaction.Musician = Hero;
                Reaction.Serial = L.Serial;
                AI.GetDailyRoutineIfActive().DoInterruptState(Reaction);
                RoutineTasks++;
            }
            else
            {
                if (!IsValid(N.Mesh)) continue;
                L.Anim = N.Mesh.GetAnimInstance();
                L.Performance = N.IsSitting() ? SeatedClap : Clap;
                if (!IsValid(L.Anim) || !IsValid(L.Performance) || IsValid(N.GetCurrentMontage()) ||
                    N.CharacterState.IsDoingAnyInteraction()) continue;
                if (IsValid(AI)) L.PreviousState = AI.CurrentState;
                L.StartRotation = N.GetActorRotation(); L.StartPosition = N.GetActorLocation();
            }
            Listeners.Add(L); Added++; Joined++;
        }
    }

    void Tick(AGothicCharacter Hero, float Now, float Delta)
    {
        if (Pulse) { Until = Now + 1.6f; Pulse = false; }
        if (!Requested || Now > Until || Hero.IsDead() || Hero.IsDefeated() || Hero.IsInCombat() || Hero.IsInConversation())
        { Clear(Hero); return; }
        if (!TriedAsset)
        {
            TriedAsset = true;
            FSoftObjectPath Asset("/Game/AnimLibrary/Humanoid/Man/Living/Dancing/A_Man_Dancing_Clap_Montage.A_Man_Dancing_Clap_Montage");
            Clap = Cast<UAnimMontage>(Asset.TryLoad());
            FSoftObjectPath SeatedAsset("/Game/AnimLibrary/Humanoid/Man/Living/Dancing/A_Man_Sit_Dancing_Montage.A_Man_Sit_Dancing_Montage");
            SeatedClap = Cast<UAnimMontage>(SeatedAsset.TryLoad());
        }
        if (!IsValid(Board)) Board = UVRLuteConductor::GetOrCreate(Hero);
        if (IsValid(Board)) Board.Expires = Hero.GetGameTimeSinceCreation() + 2.0f;
        if (Now >= NextScan)
        { NextScan = Now + 0.65f; Invite(Hero, Now); }
        if (Now < NextCheck) return;
        NextCheck = Now + 0.16f;
        for (int I = Listeners.Num()-1; I >= 0; I--)
        {
            auto N = Listeners[I].NPC;
            if (!VRLuteCanInterrupt(N, Hero) || !District.InRange(Hero, N)) { Release(I, Hero); continue; }
            if (!IsValid(N.Mesh) || !IsValid(N.Mesh.GetAnimInstance())) { Release(I, Hero); continue; }
            auto Anim = N.Mesh.GetAnimInstance();
            auto AI = N.GetGothicAI();
            auto Active = N.GetCurrentMontage();
            if (IsValid(Listeners[I].Anim) && Listeners[I].Anim != Anim) { Release(I, Hero); continue; }
            Listeners[I].Anim = Anim;
            if (Now < Listeners[I].WaitUntil) continue;
            FVector ToHero = Hero.GetActorLocation() - N.GetActorLocation();
            ToHero.Z = 0.0f;
            bool Aligned = ToHero.SizeSquared() < 1.0f || N.GetActorForwardVector().DotProduct(ToHero.GetSafeNormal()) >= 0.94f;
            if (Listeners[I].Serial > 0)
            {
                if (!IsValid(Board) || !IsValid(AI))
                { Release(I, Hero); continue; }
                auto Routine = AI.GetDailyRoutineIfActive();
                float LastTurn = 0.0f;
                bool TurnFinished = Board.Turned.Find(Listeners[I].Serial, LastTurn);
                if (TurnFinished && Hero.GetGameTimeSinceCreation() - LastTurn > 1.5f) { Release(I, Hero); continue; }
                if (IsValid(Routine) && IsValid(Routine.InterruptState) && Routine.IsDoingInterruptState())
                {
                    auto Owned = Cast<UVRLuteApplauseState>(Routine.InterruptState);
                    if (!IsValid(Owned) || Owned.Serial != Listeners[I].Serial || Owned.Musician != Hero)
                    { Release(I, Hero); continue; }
                }
                if (!TurnFinished && !IsValid(Routine) && Now > Listeners[I].WaitUntil + 1.6f)
                { Release(I, Hero); continue; }
                if (!Listeners[I].FacingReady)
                {
                    // Actors can already face the musician and omit a turn montage.
                    if (!TurnFinished && (!Aligned || IsValid(Active) || N.CharacterState.IsDoingAnyInteraction())) continue;
                    Listeners[I].FacingReady = true;
                }
                if (!IsValid(Listeners[I].Performance)) Listeners[I].Performance = N.IsSitting() ? SeatedClap : Clap;
            }
            else
            {
                if ((IsValid(AI) && (AI.CurrentState != Listeners[I].PreviousState || IsValid(AI.GetDailyRoutineIfActive()))) ||
                    N.CharacterState.IsDoingAnyInteraction() || (IsValid(Active) && Active != Listeners[I].Performance))
                { Release(I, Hero); continue; }
                if (!Listeners[I].FacingReady && !N.IsSitting() && !Aligned)
                {
                    FRotator Goal = N.GetActorRotation(); Goal.Yaw = ToHero.Rotation().Yaw;
                    N.SetActorRotation(Math::RInterpConstantTo(N.GetActorRotation(), Goal, 0.16f, 150.0f));
                    Listeners[I].LastFacing = N.GetActorForwardVector();
                    Listeners[I].TurnedIdle = true;
                    continue;
                }
                Listeners[I].FacingReady = true;
            }
            auto Performance = Listeners[I].Performance;
            if (!IsValid(Performance)) continue;
            FName LoopSection = Performance == SeatedClap ? n"Idle01" : n"Loop01";
            if (Listeners[I].Present(Now, LoopSection)) DirectClips++;
            if (Listeners[I].Playing && !Listeners[I].SeenPlaying)
            { Listeners[I].SeenPlaying = true; Applauded++; }
        }
        if (CheerAudible) Chorus.Tick(Hero, Listeners, Now);
    }
}
