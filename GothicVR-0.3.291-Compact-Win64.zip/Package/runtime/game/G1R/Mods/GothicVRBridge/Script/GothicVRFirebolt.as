struct FVRSpellStart
{
    bool Active = false;
    bool Placed = false;
    float Birth = 0.0f;
    FTimerHandle Timer;

    bool Begin(ASpellBallVisual_AS Ball)
    {
        if (Active) return false;
        Active = true;
        Birth = Ball.GetGameTimeSinceCreation();
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        Bridge.VRMagicHookCount += 1;
        Placed = Bridge.PlaceVRSpell(Ball, false, 0.0f);
        return true;
    }

    void Schedule(ASpellBallVisual_AS Ball)
    {
        if (!Active) return;
        Timer = System::SetTimerDelegate(FTimerDynamicDelegate(Ball, n"FinishVRLaunch"), 0.001f, false);
    }

    void Finish(ASpellBallVisual_AS Ball)
    {
        if (!Active || Ball.m_HasCollided) return;
        float Age = Ball.GetGameTimeSinceCreation() - Birth;
        if (Age < 0.0f || Age > 0.12f) return;
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        AActor Caster = Bridge.VRSpellCaster(Ball);
        if (Caster == nullptr) return;
        // Certain abilities assign Owner after the actor is spawned.
        // An early-placed projectile gets its heading only and never snaps back.
        if (!Placed) Placed = Bridge.PlaceVRSpell(Ball, true, Age);
        if (Placed) Bridge.ApplyVRProjectileLaunch(Ball, Caster);
    }

    void End()
    {
        Active = false;
        Placed = false;
        System::ClearAndInvalidateTimerHandle(Timer);
    }
}

// Official G1R inheritance injection; no world scan or per-frame Lua UObject calls.
UCLASS(meta=(ReplaceParentClass))
class AFireboltVisual_GothicVR : AFireboltVisual
{
    FVRSpellStart VRStart;

    UFUNCTION(BlueprintOverride)
    void OnProjectileBeginPlay()
    {
        if (!VRStart.Begin(this)) return;
        Super::OnProjectileBeginPlay();
        VRStart.Schedule(this);
    }

    UFUNCTION()
    void FinishVRLaunch() { VRStart.Finish(this); }

    UFUNCTION(BlueprintOverride)
    void OnProjectileEndPlay()
    {
        VRStart.End();
        Super::OnProjectileEndPlay();
    }
}
