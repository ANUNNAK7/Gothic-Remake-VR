// The game's skinned-mesh interpolation expects USkeletalMeshComponent.
// Poseable meshes are written directly by the VR rig and have no animation instance.
class AGothicVRPoseOwner : AActor
{
    default bNeverApplyTickOptimizations = true;
}

delegate void FGothicVRGrassTick();

struct FVRIncomingFists
{
    UPROPERTY() AGothicCharacter Source;
    FVector Left;
    FVector Right;
    FVector PreviousLeft;
    FVector PreviousRight;
    float Time = -1000.0f;
    float PreviousTime = -1000.0f;
}

struct FGothicVRTorchProbe
{
    UPROPERTY() AActor Source;
    UPROPERTY() UNiagaraComponent Flame;
    UPROPERTY() AInteractiveGasObjectActor Latched;
    UPROPERTY() TArray<UPrimitiveComponent> Burners;
    FVector Base;
    FVector Tip;
    FVector SearchPoint;
    float SearchTime = -10.0f;
    float SampleTime = -10.0f;
    bool Pending = false;
}

struct FGothicVRBowFlight
{
    UPROPERTY() AActor Arrow;
    UPROPERTY() UWeaponDefinition Weapon;
    UPROPERTY() float Draw;
    UPROPERTY() float Expires;
    bool ContactSeen = false;
}

struct FGothicVRBodyInput
{
    int GripSerial = 0;
    int StrikeState = 0; // 0 standing, 1 defeated, 2 dead at contact
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() FName Bone;
    UPROPERTY() FVector Point;
    UPROPERTY() FVector Goal;
    UPROPERTY() FVector Velocity;
    UPROPERTY() FVector Normal;
    UPROPERTY() float Time = -1000.0f;
    UPROPERTY() bool Grip = false;
    UPROPERTY() bool TorchStrike = false;
    bool RestingSlap = false;
}

struct FVRLandingObservation
{
    UPROPERTY() AGothicCharacter Target;
    int State = -1;
    float Seen;
    float Until;
    float NextSample;
    FName Driver;
    FVector RecentVelocity;
    float MomentumUntil;
    int Releases;
    TArray<FName> Limbs;
    TArray<float> Span;
    TArray<int> Lag;
    TArray<float> ParentSpan;
}

struct FGothicVRDownedBody
{
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() USkeletalMeshComponent Mesh;
    UPROPERTY() TArray<FName> OwnedRoots;
    UPROPERTY() TArray<FName> OwnedSpine;
    bool SpineChecked = false;
    float NextSupportCheck = 0.0f;
    FName DriverBone = n"pelvis";
    UPROPERTY() UPrimitiveComponent CrossedFloor;
    FVector FloorPoint, FloorNormal;
    float FloorUntil = 0.0f;
    bool OwnPelvis = false;
    bool OwnFloorResponse = false;
    ECollisionResponse OldFloorResponse;
    FName FloorProfile;
    ECollisionChannel FloorObjectType;
    ECollisionEnabled FloorMode;
    FVector LastSafeHip;
    FVector BlockedFollowHip;
    bool FollowBlocked = false;
    FVector SafeCapsule;
    bool HasSafeCapsule = false;
    FVector EntryCapsule;
    float EntryHalfHeight = 0.0f;
    float AnchorHalfHeight = 0.0f;
    float LastTouch = -1000.0f;
    float NextVoice = 0.0f;
    float Weight = 0.0f;
    FVector DragVelocity;
}

struct FGothicVRHandDefeat
{
    UPROPERTY() AGothicCharacter Target;
    int Hits = 0;
}

struct FGothicVRGetupWatch
{
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() USkeletalMeshComponent Mesh;
    FVector Anchor;
    FVector Entry;
    float EntryHalfHeight;
    float HalfHeight;
    float NextCheck;
    float Until;
    bool Placed = false;
    int StandingSamples = 0;
    bool Aligned = false;
    float HoverStart = -1.0f;
    FVector HoverOrigin;
    bool HoverSettled = false;
}

// Same stay-down tag as the stock story effect, without its persistence or
// its quest-removal asset tag. We remove only the handle we obtained.
class UGE_VRManipulatedDowned : UScriptGameplayEffect
{
    default DurationPolicy = EGameplayEffectDurationType::Infinite;
    default TargetTagsComponent.InheritableGrantedTagsContainer.AddTag(GameplayTag::Character_StayDefeated);
}

struct FGothicVRRecoveryHold
{
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() UGothicAbilitySystemComponent ASC;
    UPROPERTY() FActiveGameplayEffectHandle Effect;
    float Interval;
    float Until;
}

struct FGothicVRProvocation
{
    int LeftGrip = 0;
    int RightGrip = 0;
    bool LastWasGrip = false;
    float GripSample = -1000.0f;
    float NextComplaint = 0.0f;
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() int Count = 0;
    UPROPERTY() float LastTouch = -1000.0f;
    UPROPERTY() float LastEpisode = -1000.0f;
    UPROPERTY() int VoiceStage = 0;
    UPROPERTY() float NextVoiceTime = 0.0f;
    UPROPERTY() float VoiceWaitStart = -1.0f;
    UPROPERTY() float AttackAt = -1.0f;
    UPROPERTY() float AttackDeadline = -1.0f;
}

// External displacement has its own velocity: animation/braking must not erase
// the player's pull before movement runs. The capsule still sweeps normally.
struct FGothicVRBodyMotion
{
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() UGothicMovementComponent Movement;
    UPROPERTY() FVector Speed;
    UPROPERTY() FVector RequestedSpeed;
    UPROPERTY() FVector PreviousPosition;
    UPROPERTY() float LastInput = -1000.0f;
    UPROPERTY() int Inputs = 0;
}

struct FGothicVRBodyReaction
{
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() USkeletalMeshComponent Mesh;
    FRotator Base, Written;
    FVector Drive, Desired;
    float LastTouch = -1000.0f;
    bool Applied = false;
}

struct FGothicVRArmDrive
{
    FVector HandleGoal;
    FVector DownedGripOffset;
    FName DownedGripBone;
    bool HasHandleGoal = false;
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() USkeletalMeshComponent Mesh;
    UPROPERTY() FName Root;
    UPROPERTY() FVector StartAnchor;
    float Weight = 0.0f;
    float LastTouch = -1000.0f;
}

struct FGothicVRCorpseContact
{
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() float LastTouch = -1000.0f;
    UPROPERTY() float NextWake = 0.0f;
    UPROPERTY() float NextRagdoll = 0.0f;
    UPROPERTY() bool ObservedSimulation = false;
    bool WasDown = false;
    bool FaceUp = true;
    bool RecoveryPending = false;
    FVector SafeCapsule;
    bool HasSafeCapsule = false;
    float RecoverUntil = 0.0f;
}

// World-owned executor. UEVR submits poses/requests; engine Tick owns all gameplay
// callbacks, physics handles and cleanup. Never run death/AI/GAS from a CDO callback.
class AGothicVRRuntime : AActor
{
    UPROPERTY(DefaultComponent, RootComponent) USceneComponent Root;
    UPROPERTY(DefaultComponent) UPhysicsHandleComponent LeftHandle;
    UPROPERTY(DefaultComponent) UPhysicsHandleComponent RightHandle;
    // Stop is a native, reflected zero-parameter method. This private timeline
    // has no tracks, never plays, and is used only from this actor's Tick.
    UPROPERTY(DefaultComponent) UTimelineComponent GrassDispatchSignal;
    default GrassDispatchSignal.bAutoActivate = false;
    UPROPERTY(DefaultComponent) UPostProcessComponent SwimVision;
    default SwimVision.bUnbound = true;
    default SwimVision.BlendRadius = 0.0f;
    default SwimVision.bEnabled = false;
    default SwimVision.Priority = 12.0f;
    default SwimVision.BlendWeight = 0.0f;
    default SwimVision.Settings.bOverride_ColorGain = true;
    default SwimVision.Settings.ColorGain = FVector4(0.40f, 0.76f, 0.93f, 1.0f);
    default SwimVision.Settings.bOverride_ColorOffset = true;
    default SwimVision.Settings.ColorOffset = FVector4(0.0f, 0.020f, 0.036f, 0.0f);
    default SwimVision.Settings.bOverride_ColorSaturation = true;
    default SwimVision.Settings.ColorSaturation = FVector4(0.82f, 0.86f, 0.90f, 1.0f);
    default bNeverApplyTickOptimizations = true;

    UPROPERTY() AGothicCharacter Hero;
    UPROPERTY() UWeaponDefinition LastVRWeapon;
    int WeaponCommand = 0;
    UPROPERTY() bool VRFistsDrawn = false;

    UFUNCTION(BlueprintCallable)
    void QueueVRWeaponCommand(int Command)
    {
        if (Command >= 1 && Command <= 3) WeaponCommand = Command;
    }

    void UpdateWeaponToggle()
    {
        auto Carry = Hero.CarryComponent;
        VRFistsDrawn = IsValid(Carry) && Hero.HasDrawnFists();
        if (IsValid(Carry))
        {
            auto Current = Cast<UWeaponDefinition>(Carry.EquippedItemDefinition);
            if (IsValid(Current) && Current != LastVRWeapon && !VRFistsDrawn && Hero.HasDrawnWeapon()) LastVRWeapon = Current;
        }
        if (WeaponCommand == 0) return;
        int Command = WeaponCommand;
        WeaponCommand = 0;
        auto ASC = Hero.GetGothicAbilitySystemComponent();
        if (InteractionOwnsMovement || Hero.IsInConversation() || Hero.IsDefeated() || !IsValid(ASC) || !IsValid(Carry)) return;
        bool Drawn = Hero.HasDrawnWeapon() || Hero.HasDrawnTorch() || Hero.HasDrawnMagicSpell() || VRFistsDrawn;
        if (Command == 3)
        {
            if (Drawn) ASC.TryActivateAbilityByClass(UGameplayAbilityShelveWeapon::StaticClass());
            return;
        }
        auto Slots = DataModule::GetContainerDataModule(Hero);
        auto Inventory = Hero.GetInventory();
        if (Command == 2)
        {
            if (!Drawn || !IsValid(Slots) || !IsValid(Inventory)) return;
            // Equipped quickbar slots 0 and 1 identify the two actual loadout weapons.
            // Spells and bare fists return to the equipped melee slot.
            EInventoryTypes Kind = Hero.HasDrawnMeleeWeapon() && !VRFistsDrawn ? EInventoryTypes::RangedSlot : EInventoryTypes::MeleeSlot;
            const auto& Items = Slots.GetItemsInConst(Kind);
            for (const auto& Item : Items)
            {
                if (Item.m_SlotData.m_ItemCount > 0 && Item.m_SlotData.m_ItemDefinition.Get() != nullptr)
                {
                    Inventory.EquipItem(Kind, Item.m_Id);
                    return;
                }
            }
            return;
        }
        if (Drawn) return;
        if (IsValid(LastVRWeapon) && IsValid(Slots) && IsValid(Inventory))
        {
            for (int Kind = 3; Kind <= 5; Kind++)
            {
                const auto& Items = Slots.GetItemsInConst(EInventoryTypes(Kind));
                for (const auto& Item : Items)
                {
                    if (Item.m_SlotData.m_ItemCount > 0 && Item.m_SlotData.m_ItemDefinition.Get() == LastVRWeapon.Class)
                    {
                        Inventory.EquipItem(EInventoryTypes(Kind), Item.m_Id);
                        return;
                    }
                }
            }
        }
        ASC.TryActivateAbilityByClass(UGameplayAbilityEquipWeaponAuto::StaticClass());
    }
    UPROPERTY() AActor FocusNameTarget;
    UPROPERTY() UTextBlock FocusNameOutput;
    UPROPERTY() UTextBlock FocusStyledOutput;
    UPROPERTY() UFont FocusTypeface;
    UPROPERTY() TArray<UTextBlock> FocusNameSources;
    UPROPERTY() int FocusNameResult = 0;
    UPROPERTY() int FocusDuplicateMask = 0;
    UPROPERTY() bool FocusNameChanged = false;
    UPROPERTY() bool FocusCanInteract = false;
    int FocusNameRequest = 0;

    // Lua submits references only. Native FText and the interaction interface
    // stay in the game Tick, including localized/custom item names.
    UFUNCTION()
    void QueueFocusName(int Request, AActor Target, UTextBlock Output, UFont Typeface = nullptr)
    {
        FocusNameTarget = Target; FocusNameOutput = Output; FocusNameRequest = Request;
        FocusTypeface = Typeface;
        FocusNameSources.Empty();
    }

    UFUNCTION()
    void QueueFocusSource(int Request, UTextBlock Source)
    {
        if (Request == FocusNameRequest && Request > 0 && IsValid(Source) &&
            Source != FocusNameOutput && FocusNameSources.Num() < 16) FocusNameSources.Add(Source);
    }

    void ResolveFocusName()
    {
        int Request = FocusNameRequest;
        FocusNameRequest = 0;
        FocusNameResult = -Request;
        FocusNameChanged = false;
        FocusCanInteract = false;
        FocusDuplicateMask = 0;
        if (IsValid(FocusNameTarget) && IsValid(FocusNameOutput) && FocusNameTarget.GetWorld() == Hero.GetWorld())
        {
            auto Character = Cast<AGothicCharacter>(FocusNameTarget);
            auto Interaction = UInteractiveComponent::Get(FocusNameTarget);
            FText DisplayLabel;
            if (IsValid(Character)) DisplayLabel = Character.GetCharacterDisplayName();
            else if (IsValid(Interaction)) DisplayLabel = Interaction.DisplayName();
            FString Value = DisplayLabel.ToString();
            if (Value.Len() > 0)
            {
                if (FocusStyledOutput != FocusNameOutput)
                {
                    FSlateFontInfo FontInfo = FocusNameOutput.Font;
                    if (IsValid(FocusTypeface)) { FontInfo.FontObject = FocusTypeface; FontInfo.TypefaceFontName = n"Default"; }
                    FontInfo.OutlineSettings.OutlineSize = 2;
                    FontInfo.OutlineSettings.OutlineColor = FLinearColor::Black;
                    FocusNameOutput.SetFont(FontInfo);
                    FocusNameOutput.SetColorAndOpacity(FLinearColor(1.0f, 0.96f, 0.86f, 1.0f));
                    FocusNameOutput.SetShadowColorAndOpacity(FLinearColor::Black);
                    FocusNameOutput.SetShadowOffset(FVector2D(1.0, 2.0));
                    FocusStyledOutput = FocusNameOutput;
                }
                FocusNameChanged = FocusNameOutput.GetText().ToString() != Value;
                if (FocusNameChanged) FocusNameOutput.SetText(DisplayLabel);
                for (int i = 0; i < FocusNameSources.Num(); i++)
                {
                    auto Source = FocusNameSources[i];
                    if (IsValid(Source) && Source.GetText().ToString() == Value) FocusDuplicateMask |= (1 << i);
                }
                auto Sensor = UInteractSensor::Get(Hero);
                FocusCanInteract = IsValid(Sensor) && Sensor.GetNearestInteraction() == FocusNameTarget &&
                    !Hero.IsDefeated() && !Hero.IsInConversation() && Sensor.CanInteract() &&
                    (!IsValid(Interaction) || (!Interaction.GetForceDisableUI() && !Interaction.GetForceDisableInteraction() &&
                    Interaction.IsUsable() && !Interaction.IsBeingUsed()));
                FocusNameResult = Request;
            }
        }
        QueueFocusName(0, nullptr, nullptr);
    }
    UPROPERTY() FVRLuteAudience LuteAudience;

    UFUNCTION(BlueprintCallable)
    void SetVRLuteAudience(AGothicCharacter Musician, bool Playing, bool Hold = false)
    {
        if (Musician != Hero) return;
        LuteAudience.Requested = Playing || Hold;
        LuteAudience.Pulse = Playing || Hold;
        LuteAudience.CheerAudible = Playing;
    }

    UFUNCTION(BlueprintPure)
    int GetVRLuteListenerCount() const { return LuteAudience.Listeners.Num(); }

    UFUNCTION(BlueprintPure)
    int GetVRLuteNearbyCount() const { return LuteAudience.LastNearby; }

    UFUNCTION(BlueprintPure)
    int GetVRLuteClapCount() const
    {
        int Count = 0;
        for (int I = 0; I < LuteAudience.Listeners.Num(); I++)
        {
            if (LuteAudience.Listeners[I].Playing) Count += 1;
        }
        return Count;
    }

    UFUNCTION(BlueprintPure)
    int GetVRLuteCheerCount() const { return LuteAudience.Chorus.Accepted; }

    UFUNCTION(BlueprintPure)
    int GetVRLuteReleasedCount() const { return LuteAudience.Released; }

    UFUNCTION(BlueprintPure)
    int GetVRLuteJoinedTotal() const { return LuteAudience.Joined; }

    UFUNCTION(BlueprintPure)
    int GetVRLuteClapStartTotal() const { return LuteAudience.DirectClips; }

    UFUNCTION(BlueprintPure)
    int GetVRLuteVoiceAttempts() const { return LuteAudience.Chorus.Attempts; }

    UFUNCTION(BlueprintPure)
    int GetVRLuteVoiceMissing() const { return LuteAudience.Chorus.Missing; }

    UFUNCTION(BlueprintPure)
    int GetVRLuteVoiceRejected() const { return LuteAudience.Chorus.Rejected; }

    UFUNCTION(BlueprintPure)
    int GetVRLuteVoiceSpoken() const { return LuteAudience.Chorus.Spoken; }

    UPROPERTY() FVRWoodCache LocalWood;
    UPROPERTY() FName VRWoodMesh;
    UPROPERTY() bool VRWoodApproximate = false;
    UPROPERTY() int VRWoodInstance = -1;
    UPROPERTY() UStaticMeshComponent LastWoodPart;

    UFUNCTION(BlueprintCallable)
    void SetVRFoliageOwnerClass(TSubclassOf<AActor> OwnerClass)
    {
        if (LocalWood.FoliageClass == OwnerClass) return;
        LocalWood.Clear();
        LocalWood.FoliageClass = OwnerClass;
    }

    UFUNCTION(BlueprintCallable)
    int GetVRWoodCount() const
    {
        return LocalWood.Stems.Num()+LocalWood.ActiveProps;
    }

    UFUNCTION(BlueprintPure)
    bool IsVRYardTreeReady() const
    {
        return IsValid(LocalWood.YardTree) && IsValid(LocalWood.YardTree.StaticMesh);
    }

    UFUNCTION(BlueprintCallable)
    bool SweepVRWood(FVector From, FVector To, float Radius, float Limit, FHitResult&out Hit)
    {
        if (GetVRWoodCount() == 0 || !OwnerWorldAvailable()) return false;
        bool Approximate;
        int InstanceIndex;
        if (!LocalWood.Sweep(From, To, Radius, Limit, Hit, Approximate, InstanceIndex)) return false;
        auto Part = Cast<UStaticMeshComponent>(Hit.GetComponent());
        if (Part != LastWoodPart && IsValid(Part) && IsValid(Part.StaticMesh))
        {
            LastWoodPart = Part;
            VRWoodMesh = Part.StaticMesh.Name;
        }
        VRWoodApproximate = Approximate;
        VRWoodInstance = InstanceIndex;
        return true;
    }
    UPROPERTY() TArray<FGothicVRBowFlight> BowFlights;
    UPROPERTY() int BowDamageMatches = 0;
    UPROPERTY() FString BowDamageMatch = "none";
    UPROPERTY() float BowDamageDraw = 0.0f;
    UPROPERTY() int BowFinishRequests = 0;

    UPROPERTY() int BowReleaseSerial = 0;
    UPROPERTY() FGothicVRCrossbowShot VRCrossbow;

    UFUNCTION(BlueprintCallable)
    bool IsVRReleasedCrossbowBolt(AActor Actor) const
    {
        if (!IsValid(Actor)) return false;
        if (Actor == VRCrossbow.LastLaunched) return true;
        for (auto Flight : VRCrossbow.Flying)
            if (Flight.Bolt == Actor) return true;
        return false;
    }

    UFUNCTION(BlueprintCallable)
    bool IsVRCrossbowRailPending(int Serial) const
    {
        return Serial == VRCrossbow.Serial && (VRCrossbow.Phase == 1 || VRCrossbow.Phase == 2);
    }

    UFUNCTION(BlueprintCallable)
    bool IsVRWaitingCrossbowBolt(AActor Actor) const
    {
        return IsValid(Actor) && VRCrossbow.Phase == 2 && Actor == VRCrossbow.Current.Bolt;
    }

    UFUNCTION(BlueprintCallable)
    bool WasVRCrossbowReleaseIssued(int Serial) const
    {
        return Serial > 0 && VRCrossbow.IssuedSerial == Serial;
    }

    UFUNCTION(BlueprintCallable)
    int QueueVRCrossbowShot(AGothicCharacter Shooter, UCrossbowComponent EquippedCrossbow, FVector Muzzle, FVector Forward, USceneComponent PresentedRail, FVector LocalNock, int StateAtTrigger = -1)
    {
        if (!Ready() || Shooter != Hero || Hero.IsDefeated() || Hero.IsInConversation() || InteractionOwnsMovement) return 0;
        if (!IsValid(PresentedRail) || PresentedRail.GetWorld() != Hero.GetWorld()) return 0;
        int Request = VRCrossbow.Arm(Hero, EquippedCrossbow, Muzzle, Forward, GetGameTimeSinceCreation());
        if (Request > 0)
        {
            VRCrossbow.PresentedRail = PresentedRail;
            VRCrossbow.LocalNock = LocalNock;
            VRCrossbow.StateAtTrigger = StateAtTrigger;
            if (StateAtTrigger == int(EArcheryState::BowInHandNotchedRelaxed))
                VRCrossbow.NockedAtTrigger = EquippedCrossbow.GetCurrentArrow();
        }
        return Request;
    }

    UFUNCTION(BlueprintCallable)
    int PrimeVRCrossbow(AGothicCharacter Shooter, UCrossbowComponent EquippedCrossbow)
    {
        if (!Ready() || Shooter != Hero || Hero.IsDefeated() || Hero.IsInConversation() || InteractionOwnsMovement) return 0;
        return VRCrossbow.Arm(Hero, EquippedCrossbow, Hero.GetActorLocation(), Hero.GetActorForwardVector(), GetGameTimeSinceCreation(), true);
    }

    UFUNCTION(BlueprintCallable)
    void CancelVRCrossbowShot(AGothicCharacter Shooter, int Serial)
    {
        if (Shooter == Hero && Serial == VRCrossbow.Serial && (VRCrossbow.Phase == 1 || VRCrossbow.Phase == 3))
            VRCrossbow.Close("cancelled");
    }

    UFUNCTION(BlueprintCallable)
    int GetVRCrossbowPhase(int Serial) const
    {
        return Serial == VRCrossbow.Serial ? VRCrossbow.Phase : 0;
    }
    UPROPERTY() float BowMontageAfterRelease = -1.0f;
    UPROPERTY() float BowCommandAfterRelease = -1.0f;
    UPROPERTY() UBowComponent QueuedBowComponent;
    UPROPERTY() AArrowVisual QueuedBowArrow;
    bool BowCommandAccepted = false;
    UPROPERTY() UWeaponDefinition BowReleaseWeapon;
    UPROPERTY() UAnimInstance BowReleaseAnim;
    UPROPERTY() UAnimMontage BowReleaseMontage;
    float BowReleaseAt = -1.0f;
    float BowNormalRate = 0.0f;
    float BowFastRate = 0.0f;
    bool BowReleaseDone = false;

    // Lua arms a short window for a *committed* physical shot. No input,
    // projectile launch or inventory action is performed by this lease.
    UFUNCTION(BlueprintCallable)
    int ArmVRBowRelease(AGothicCharacter Shooter, UWeaponDefinition Weapon)
    {
        if (!Ready() || Shooter != Hero || !IsValid(Weapon) || IsValid(BowReleaseWeapon)) return 0;
        BowReleaseWeapon = Weapon;
        BowReleaseAt = GetGameTimeSinceCreation();
        BowReleaseDone = false;
        BowMontageAfterRelease = -1.0f;
        BowCommandAfterRelease = -1.0f;
        BowCommandAccepted = false;
        BowReleaseSerial += 1;
        return BowReleaseSerial;
    }

    bool CanReleaseNockedVRArrow(UBowComponent Bow, AArrowVisual Arrow) const
    {
        if (!Ready() || Hero.IsDefeated() || Hero.IsInConversation() || InteractionOwnsMovement ||
            !IsValid(Bow) || Bow.GetOwner() != Hero || !IsValid(Arrow) || Arrow.GetWorld() != GetWorld() ||
            Bow.GetCurrentArrow() != Arrow || Bow.IsAiming() || Bow.IsNotchingArrowOntoBow() || Bow.IsWaitingToFinishRelease()) return false;
        auto Carry = Hero.GetCarryComponent();
        auto Visual = Bow.GetBowOrCrossbowWeapon();
        if (!IsValid(Carry) || !IsValid(Visual) || Carry.GetItemVisual() != Visual ||
            Carry.GetEquippedItemDefinition() != BowReleaseWeapon || !IsValid(Arrow.m_MovementComp) ||
            Arrow.m_MovementComp.Velocity.SizeSquared() > 100.0f) return false;
        auto Parent = Arrow.GetAttachParentActor();
        if (Parent == Hero || Parent == Visual) return true;
        auto ArrowOwner = Arrow.GetOwner();
        return !IsValid(Parent) && (ArrowOwner == Hero || ArrowOwner == Visual) &&
            (Arrow.GetActorLocation()-Visual.GetActorLocation()).SizeSquared() <= 10000.0f;
    }

    UFUNCTION(BlueprintCallable)
    bool QueueVRNockedRelease(int Serial, UBowComponent Bow, AArrowVisual Arrow)
    {
        if (Serial != BowReleaseSerial || BowReleaseDone || BowCommandAccepted ||
            BowReleaseAt < 0.0f || !CanReleaseNockedVRArrow(Bow,Arrow)) return false;
        BowCommandAccepted = true;
        QueuedBowComponent = Bow;
        QueuedBowArrow = Arrow;
        return true;
    }

    UFUNCTION(BlueprintCallable)
    void FinishVRBowRelease(int Serial)
    {
        if (Serial == BowReleaseSerial) BowReleaseDone = true;
    }

    void ClearBowRelease()
    {
        if (IsValid(BowReleaseAnim) && IsValid(BowReleaseMontage) &&
            BowReleaseAnim.Montage_IsPlaying(BowReleaseMontage) &&
            Math::Abs(BowReleaseAnim.Montage_GetPlayRate(BowReleaseMontage) - BowFastRate) < 0.001f)
            BowReleaseAnim.Montage_SetPlayRate(BowReleaseMontage, BowNormalRate);
        BowReleaseWeapon = nullptr;
        BowReleaseAnim = nullptr;
        BowReleaseMontage = nullptr;
        QueuedBowArrow = nullptr;
        QueuedBowComponent = nullptr;
        BowReleaseAt = -1.0f;
    }

    void BowReleaseTick()
    {
        if (BowReleaseAt < 0.0f) return;
        float Elapsed = GetGameTimeSinceCreation() - BowReleaseAt;
        auto Carry = Hero.GetCarryComponent();
        if (BowReleaseDone || Elapsed > 0.48f || InteractionOwnsMovement || Hero.IsInConversation() ||
            !IsValid(Carry) || Carry.GetEquippedItemDefinition() != BowReleaseWeapon || !IsValid(Hero.Mesh))
        {
            ClearBowRelease();
            return;
        }
        if (BowCommandAccepted && BowCommandAfterRelease < 0.0f)
        {
            auto Bow = QueuedBowComponent;
            auto Arrow = QueuedBowArrow;
            QueuedBowComponent = nullptr;
            QueuedBowArrow = nullptr;
            if (Elapsed > 0.12f || !CanReleaseNockedVRArrow(Bow,Arrow))
            {
                ClearBowRelease();
                return;
            }
            // 251 recorded BowInHandNotchedRelaxed -> WaitingToEnterQuickRelease
            // with the arrow already present, then ~0.25s before the montage.
            // Enter its stock quick-shot state once, directly from the confirmed
            // nocked state. Only the stock release notify launches/debits.
            BowCommandAfterRelease = Elapsed;
            Bow.ChangeState(EArcheryState::QuickReleaseBowString);
        }
        auto Anim = Hero.Mesh.GetAnimInstance();
        auto Montage = Hero.GetCurrentMontage();
        if (IsValid(BowReleaseMontage))
        {
            if (Anim != BowReleaseAnim || Montage != BowReleaseMontage ||
                BowReleaseAnim.Montage_GetPosition(BowReleaseMontage) > 0.47f)
                ClearBowRelease();
            return;
        }
        if (!IsValid(Anim) || !IsValid(Montage)) return;
        FName MontageName = Montage.Name;
        if (MontageName != n"Man_Bow_N_QuickShootReload_AnimMontage" && MontageName != n"Man_Bow_STL_QuickShootReload_AnimMontage" &&
            MontageName != n"Man_Bow_N_ShootReload_AnimMontage" && MontageName != n"Man_Bow_STL_ShootReload_AnimMontage") return;
        // Ignore an old reload or blend-out left over from an earlier shot.
        if (!Anim.Montage_IsPlaying(Montage) || Anim.Montage_GetPosition(Montage) > 0.15f) return;
        float Rate = Anim.Montage_GetPlayRate(Montage);
        if (Rate <= 0.0f || Rate > 2.0f) return;
        BowReleaseAnim = Anim;
        BowReleaseMontage = Montage;
        BowNormalRate = Rate;
        BowFastRate = Rate * 3.0f;
        BowMontageAfterRelease = Elapsed;
        // Advance normal animation time: all stock notifies are traversed in order.
        Anim.Montage_SetPlayRate(Montage, BowFastRate);
    }

    UFUNCTION(BlueprintCallable)
    bool RememberBowFlight(AGothicCharacter Shooter, AArrowVisual Arrow, UWeaponDefinition Weapon, float Draw)
    {
        if (!Ready() || Shooter != Hero || !IsValid(Arrow) || Arrow.GetWorld() != GetWorld() ||
            !IsValid(Weapon) || !Weapon.GetItemType().MatchesTag(GameplayTag::Item_Weapon_Bow)) return false;
        float Now = GetGameTimeSinceCreation();
        for (int I = BowFlights.Num() - 1; I >= 0; I--)
        {
            if (BowFlights[I].Expires < Now || !IsValid(BowFlights[I].Arrow) || BowFlights[I].Arrow == Arrow)
                BowFlights.RemoveAt(I);
        }
        if (BowFlights.Num() >= 12) BowFlights.RemoveAt(0);
        FGothicVRBowFlight Flight;
        Flight.Arrow = Arrow;
        Flight.Weapon = Weapon;
        Flight.Draw = Math::Clamp(Draw, 0.0f, 1.0f);
        Flight.Expires = Now + 12.0f;
        BowFlights.Add(Flight);
        return true;
    }

    void TryBowFinish(AActor HitActor)
    {
        auto Victim = Cast<AGothicCharacter>(HitActor);
        if (IsValid(Victim) && Finishable(Victim) && QueueFinisher(Hero, Victim, true) == 1)
            BowFinishRequests += 1;
    }

    // The engine can query attachment or bounce even when a defeated character
    // receives no damage execution. Count the first actual contact once. Keep
    // the flight until GAS has also had a chance to read its physical draw.
    void ObserveBowContact(AArrowVisual Arrow, AActor HitActor)
    {
        if (BowFlights.IsEmpty() || !Ready() || !IsValid(Arrow) || !IsValid(HitActor) ||
            Arrow.GetWorld() != GetWorld() || HitActor.GetWorld() != GetWorld() || HitActor == Hero) return;
        float Now = GetGameTimeSinceCreation();
        for (int I = 0; I < BowFlights.Num(); I++)
        {
            if (BowFlights[I].Arrow != Arrow || BowFlights[I].ContactSeen || BowFlights[I].Expires < Now) continue;
            BowFlights[I].ContactSeen = true;
            TryBowFinish(HitActor);
            return;
        }
    }

    // A post-damage bounce can see an opponent knocked down by this very
    // bolt. Share one first-contact decision between GAS and the hit hooks.
    void ObserveCrossbowContact(AArrowVisual Bolt, AActor HitActor)
    {
        if (!IsValid(Bolt) || !IsValid(HitActor) || HitActor == Hero || !Ready() ||
            HitActor.GetWorld() != GetWorld() || Bolt.GetWorld() != GetWorld()) return;
        float Now = GetGameTimeSinceCreation();
        if (VRCrossbow.Phase == 2 && VRCrossbow.Current.Bolt == Bolt)
        {
            if (VRCrossbow.Current.ContactSeen || Now > VRCrossbow.Deadline) return;
            VRCrossbow.Current.ContactSeen = true;
            TryBowFinish(HitActor);
            return;
        }
        for (int I = 0; I < VRCrossbow.Flying.Num(); I++)
        {
            if (VRCrossbow.Flying[I].Bolt != Bolt) continue;
            if (VRCrossbow.Flying[I].ContactSeen || Now > VRCrossbow.Flying[I].Until) return;
            VRCrossbow.Flying[I].ContactSeen = true;
            TryBowFinish(HitActor);
            return;
        }
    }

    void ObserveCrossbowDamage(UWeaponDefinition Weapon, AActor Causer, AActor Victim, const FHitResult&in Hit)
    {
        auto Exact = Cast<AArrowVisual>(Causer);
        if (IsValid(Exact))
        {
            ObserveCrossbowContact(Exact, Victim);
            return;
        }
        auto Part = Hit.GetComponent();
        if (!IsValid(Part) || Part.GetOwner() != Victim) return;
        float Now = GetGameTimeSinceCreation();
        AArrowVisual Candidate;
        if (VRCrossbow.Phase == 2 && Now <= VRCrossbow.Deadline &&
            VRCrossbow.Current.NearImpact(Weapon, Hit.ImpactPoint))
            Candidate = VRCrossbow.Current.Bolt;
        for (auto Flight : VRCrossbow.Flying)
        {
            if (Now > Flight.Until || !Flight.NearImpact(Weapon, Hit.ImpactPoint)) continue;
            if (IsValid(Candidate)) return;
            Candidate = Flight.Bolt;
        }
        if (IsValid(Candidate)) ObserveCrossbowContact(Candidate, Victim);
    }

    float ResolveBowDraw(AGothicCharacter Shooter, UWeaponDefinition Weapon, AActor Causer,
                         AActor Target, const FHitResult&in Hit, float Original)
    {
        if (Shooter != Hero || BowFlights.IsEmpty() || !Ready()) return Original;
        int Candidate = -1;
        int Nearby = 0;
        bool Exact = false;
        auto Part = Hit.GetComponent();
        bool HasImpact = IsValid(Part) && Part.GetOwner() == Target;
        float Now = GetGameTimeSinceCreation();
        for (int I = 0; I < BowFlights.Num(); I++)
        {
            auto Flight = BowFlights[I];
            if (Flight.Weapon != Weapon || Flight.Expires < Now || !IsValid(Flight.Arrow) ||
                Flight.Arrow.GetWorld() != GetWorld()) continue;
            if (Flight.Arrow == Causer) { Candidate = I; Exact = true; break; }
            if (HasImpact && Flight.Arrow.GetVelocity().SizeSquared() > 10000.0f &&
                (Flight.Arrow.GetActorLocation() - Hit.ImpactPoint).SizeSquared() < 45.0f * 45.0f)
            {
                Candidate = I;
                Nearby += 1;
            }
        }
        if (Candidate < 0 || (!Exact && Nearby != 1)) return Original;
        BowDamageDraw = BowFlights[Candidate].Draw;
        bool FirstContact = !BowFlights[Candidate].ContactSeen;
        BowFlights.RemoveAt(Candidate);
        // Before Super::Execute: a hit on a standing opponent can knock them
        // down normally, but cannot also count as a subsequent finishing shot.
        if (FirstContact) TryBowFinish(Target);
        BowDamageMatch = Exact ? "projectile" : "unique_moving_arrow_at_impact";
        BowDamageMatches += 1;
        return BowDamageDraw;
    }
    UPROPERTY() AGothicCharacter ConsumeOwner;
    UPROPERTY() AItemVisualWorld ConsumeWorldItem;
    UPROPERTY() TSubclassOf<UItemDefinition> ConsumeDefinition;
    UPROPERTY() int ConsumeSerial = 0;
    UPROPERTY() int ConsumeStatus = -1; // 0 pending, 1 accepted, 2 existing debit, -1 rejected
    UPROPERTY() UAnimMontage ConsumeMontage;
    UPROPERTY() bool ConsumePlaying = false;
    UPROPERTY() FString ConsumeReason;
    UPROPERTY() float ConsumeSwampweedBefore = -1.0f;
    UPROPERTY() float ConsumeSwampweedAfter = -1.0f;
    float ConsumeSwampweedSampleAt = -1.0f;
    bool ConsumeCancelled = false;
    float ConsumeDeadline = 0.0f;
    bool ConsumeFromWorld = false;
    int ConsumeBefore = 0;

    float GetVRSwampweedLevel() const
    {
        if (!OwnerWorldAvailable()) return -1.0f;
        auto AbilityComponent = Hero.GetGothicAbilitySystemComponent();
        if (!IsValid(AbilityComponent)) return -1.0f;
        auto Attribute = UAngelscriptAttributeSet::GetGameplayAttribute(UAttributeSet_Swampweed::StaticClass(), n"Swampweed");
        bool Success = false;
        float Value = AbilitySystem::GetFloatAttributeFromAbilitySystemComponent(AbilityComponent, Attribute, Success);
        return Success ? Value : -1.0f;
    }

    UFUNCTION(BlueprintCallable)
    int QueueVRConsumption(AGothicCharacter Player, TSubclassOf<UItemDefinition> Definition, AItemVisualWorld WorldItem, int Before, UAnimMontage Montage)
    {
        if (!Ready() || Player != Hero || Definition == nullptr || Before < 0 || ConsumeStatus == 0) return 0;
        ConsumeOwner = Player;
        ConsumeWorldItem = WorldItem;
        ConsumeFromWorld = WorldItem != nullptr;
        ConsumeDefinition = Definition;
        ConsumeMontage = Montage;
        ConsumePlaying = false;
        ConsumeCancelled = false;
        ConsumeDeadline = GetGameTimeSinceCreation() + 3.0f;
        ConsumeBefore = Before;
        ConsumeStatus = 0;
        ConsumeReason = "queued";
        ConsumeSwampweedBefore = -1.0f;
        ConsumeSwampweedAfter = -1.0f;
        ConsumeSwampweedSampleAt = -1.0f;
        ConsumeSerial += 1;
        return ConsumeSerial;
    }

    void ClearConsumeRequest(FString Reason = "runtime_suspended")
    {
        ConsumeReason = Reason;
        ConsumeOwner = nullptr;
        ConsumeWorldItem = nullptr;
        ConsumeDefinition = nullptr;
        ConsumeMontage = nullptr;
        ConsumeStatus = -1;
    }

    UFUNCTION(BlueprintCallable)
    void CancelVRConsumption(int Serial)
    {
        if (Serial == ConsumeSerial && ConsumeStatus == 0) ConsumeCancelled = true;
    }

    void DispatchConsumeOnce(AGothicCharacter Player, TSubclassOf<UItemDefinition> Definition, int Available)
    {
        // Enter terminal state before the gameplay call, including synchronous inventory notifications.
        ClearConsumeRequest("stock_changed");
        int Now = UGothicVRInventoryBridge.GetDefaultObject().CountVRItem(Player, Definition);
        if (Now == Available - 1) { ConsumeStatus = 2; ConsumeReason = "already_debited"; return; }
        if (Now != Available) return;
        bool Accepted = Player.Inventory.ConsumeItemOfKind(Definition);
        ConsumeStatus = Accepted ? 1 : -1;
        ConsumeReason = Accepted ? "inventory_accepted" : "inventory_declined";
    }

    void ConsumptionTick()
    {
        if (ConsumeStatus != 0) return;
        auto Player = ConsumeOwner;
        auto WorldItem = ConsumeWorldItem;
        auto Definition = ConsumeDefinition;
        if (Player != Hero || !IsValid(Player.Inventory) || Definition == nullptr || ConsumeCancelled)
        {
            if (Player == Hero && ConsumePlaying && IsValid(ConsumeMontage) && Hero.GetCurrentMontage() == ConsumeMontage)
                Hero.StopAnimMontage(ConsumeMontage);
            ClearConsumeRequest(ConsumeCancelled ? "cancelled" : "owner_invalid");
            return;
        }
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (ConsumePlaying)
        {
            if (IsValid(ConsumeMontage) && Hero.GetCurrentMontage() == ConsumeMontage)
            {
                if (GetGameTimeSinceCreation() <= ConsumeDeadline) return;
                Hero.StopAnimMontage(ConsumeMontage);
                ClearConsumeRequest("presentation_timeout");
                return;
            }
            DispatchConsumeOnce(Player, Definition, ConsumeBefore + (ConsumeFromWorld ? 1 : 0));
            return;
        }
        if (IsValid(Hero.GetCurrentMontage()))
        {
            if (GetGameTimeSinceCreation() > ConsumeDeadline) ClearConsumeRequest("busy_before_use");
            return;
        }
        // Clear the queued state before the inventory callbacks. A failed transfer cannot be repeated next tick.
        ConsumeStatus = -1;
        if (Bridge.CountVRItem(Player, Definition) != ConsumeBefore) { ClearConsumeRequest("stock_changed_before_use"); return; }
        if (ConsumeFromWorld)
        {
            if (!IsValid(WorldItem) || WorldItem.GetWorld() != GetWorld() || !IsValid(WorldItem.ItemDefinition) ||
                WorldItem.ItemDefinition.Class != Definition.Get() || !IsValid(WorldItem.GetInteractiveComponent())) { ClearConsumeRequest("world_item_invalid"); return; }
            Player.Inventory.AddItemOfClass(Definition, 1);
            if (Bridge.CountVRItem(Player, Definition) != ConsumeBefore + 1) { ClearConsumeRequest("world_credit_missing"); return; }
            WorldItem.GetInteractiveComponent().RemoveForever();
            if (IsValid(WorldItem)) WorldItem.DestroyActor();
        }
        else if (ConsumeBefore < 1) { ClearConsumeRequest("empty_stack"); return; }
        auto ItemClass = Definition.Get();
        if (ItemClass == UItMi_Joint_01::StaticClass() || ItemClass == UItMi_Joint_02::StaticClass() ||
            ItemClass == UItMi_Joint_03::StaticClass())
        {
            // Submit the native action at the gesture. Its notifications and animation own the use.
            ConsumeSwampweedBefore = GetVRSwampweedLevel();
            DispatchConsumeOnce(Player, Definition, ConsumeBefore + (ConsumeFromWorld ? 1 : 0));
            ConsumePlaying = ConsumeStatus == 1;
            if (Hero == Player && OwnerWorldAvailable())
            {
                ConsumeSwampweedAfter = GetVRSwampweedLevel();
                ConsumeSwampweedSampleAt = GetGameTimeSinceCreation() + 1.0f;
            }
            return;
        }
        float Duration = IsValid(ConsumeMontage) ? Hero.PlayAnimMontage(ConsumeMontage, 1.0f, n"None") : 0.0f;
        ConsumeDeadline = GetGameTimeSinceCreation() + Math::Max(Duration, 0.5f) + 3.0f;
        ConsumePlaying = true;
        ConsumeReason = "presentation_started";
        ConsumeStatus = 0;
    }

    UPROPERTY() TArray<FGothicVRBodyInput> FistHits;
    UPROPERTY() TArray<FGothicVRBodyInput> PendingHandImpacts;
    UPROPERTY() TArray<FGothicVRBodyInput> PendingFistBounties;
    UPROPERTY() TArray<FGothicVRHandDefeat> HandDefeats;
    UPROPERTY() int HandBodyImpulses = 0;
    UPROPERTY() int LastDownedHitCount = 0;
    UPROPERTY() int FistDefeatXP = 0;
    UPROPERTY() TArray<FGothicVRBodyInput> RecentPunch;
    UPROPERTY() TArray<float> NextFist;
    UPROPERTY() TArray<FGothicVRArmDrive> ArmDrives;
    UPROPERTY() int FistDamageCalls = 0;
    float StrengthScale = 1.0f;
    float NextStrengthSample = -1.0f;
    UPROPERTY() float Heartbeat = -1000.0f;
    UPROPERTY() bool Enabled = false;
    UPROPERTY() TArray<FGothicVRBodyInput> Hands;
    UPROPERTY() TArray<int> GripModes; // 0 none, 1 character movement, 2 existing rigid body
    UPROPERTY() TArray<float> GripTime;
    UPROPERTY() TArray<float> GripRetry;
    UPROPERTY() TArray<FGothicVRProvocation> Provocations;
    UPROPERTY() TArray<FGothicVRBodyMotion> BodyMotions;
    UPROPERTY() TArray<FGothicVRBodyReaction> BodyReactions;
    UPROPERTY() TArray<UAnimMontage> BodyReactionMontages;
    UPROPERTY() TArray<FGothicVRCorpseContact> CorpseContacts;
    UPROPERTY() TArray<FGothicVRCorpseContact> LiveContacts;
    UPROPERTY() int LiveRagdollRequests = 0;
    UPROPERTY() int LiveRagdollResumes = 0;
    UPROPERTY() FString LiveRagdollStatus = "idle";
    UPROPERTY() FString LiveRagdollTarget;
    UPROPERTY() bool BodyDead = false;
    UPROPERTY() bool BodyDefeated = false;
    UPROPERTY() FName BodyInputBone;
    int BodyReactionWarmIndex = 0;
    UPROPERTY() int BodyReactionReady = 0;
    UPROPERTY() int BodyReactionCount = 0;
    UPROPERTY() FString BodyReactionStatus = "warming";
    UPROPERTY() FString BodyReactionMontage;
    UPROPERTY() int CorpseWakeRequests = 0;
    UPROPERTY() int CorpseRagdollRequests = 0;
    UPROPERTY() int CorpseResumeCount = 0;
    UPROPERTY() FString CorpseStatus = "idle";
    UPROPERTY() FString CorpseTarget;
    UPROPERTY() bool CorpseSimulating = false;
    UPROPERTY() bool CorpseAnySimulation = false;
    UPROPERTY() bool CorpseAwake = false;
    UPROPERTY() bool CorpseRagdollTag = false;
    UPROPERTY() int CorpseCollision = 0;
    UPROPERTY() TArray<AGothicCharacter> Held;
    UPROPERTY() TArray<UAnimMontage> VRFinishingMontages;
    UPROPERTY() TArray<FGothicVRFinishingHit> VRFinishingPending;
    UPROPERTY() TArray<FGothicVRMeleeHit> MeleeHits;
    UPROPERTY() TArray<FGothicVRFinishingHit> PendingDeathReports;
    UPROPERTY() int WitnessRevision = 0;
    UPROPERTY() int WitnessEligible = 0;
    UPROPERTY() int WitnessDelivered = 0;
    UPROPERTY() FString WitnessOutcome = "idle";
    UPROPERTY() int VRFinishingWarmIndex = 0;
    UPROPERTY() int VRFinishingNext = 0;
    UPROPERTY() FString VRFinishingStatus = "warming";
    UPROPERTY() FString VRFinishingMontage;
    float WarmTime = 0.0f;
    UPROPERTY() FVector SwimForce;
    UPROPERTY() bool WaterDiving = false;
    UPROPERTY() bool HasWadingSurface = false;
    UPROPERTY() float WadingSurfaceZ = 0.0f;
    bool Wet = false;
    bool SwimmingPose = false;
    float WaterProbeTime = -1.0f;
    float EyeDepth = 0.0f;
    float EyeTime = -1000.0f;
    UPROPERTY() float SwimTime = -1000.0f;
    UPROPERTY() bool HasSwimFloor = false;
    bool CapsuleOnSwimFloor = false;
    UPROPERTY() FVector SwimFloorPoint;
    UPROPERTY() FVector SwimFloorNormal;
    float NextSwimFloorSample = 0.0f;
    UPROPERTY() float SwimSpeed = 0.0f;
    UPROPERTY() float SwimObservedZ = 0.0f;
    float SwimVerticalGoal = -5.0f;
    FVector SwimPlanarGoal;
    float SwimLastPlanarSpeed = 0.0f;
    float SwimLastSample = -1000.0f;
    float SwimLastHeight = 0.0f;
    float SwimVerticalTrim = 0.0f;
    UPROPERTY() FVector BladeA;
    UPROPERTY() FVector BladeB;
    UPROPERTY() float BladeTime = -1000.0f;
    UPROPERTY() FVector PreviousBladeA;
    UPROPERTY() FVector PreviousBladeB;
    UPROPERTY() FVector GuardOrigin;
    bool HasPreviousBlade = false;
    bool GuardMoving = false;
    UPROPERTY() TArray<FGothicVRBodyInput> PushSamples;
    UPROPERTY() TArray<float> PushTravel;
    UPROPERTY() float GuardRaised = -1000.0f;
    FVector GuardLeftElbow;
    FVector GuardLeftWrist;
    FVector GuardRightElbow;
    FVector GuardRightWrist;
    bool GuardLeftArm = false;
    bool GuardRightArm = false;
    bool GuardLeftHand = false;
    bool GuardRightHand = false;
    FVector GuardLeftPalmBase;
    FVector GuardLeftKnuckles;
    FVector GuardRightPalmBase;
    FVector GuardRightKnuckles;
    float GuardArmsTime = -1000.0f;
    UPROPERTY() int ForearmBlocks = 0;
    UPROPERTY() int PalmBlocks = 0;
    UPROPERTY() int GuardIncomingMelee = 0;
    UPROPERTY() int GuardMeasuredSweeps = 0;
    UPROPERTY() int GuardContactFallbacks = 0;
    UPROPERTY() int GuardFistSweeps = 0;
    UPROPERTY() int GuardVelocitySweeps = 0;
    UPROPERTY() FString LastGuardSource;
    UPROPERTY() int LastGuardPart = 0;
    UPROPERTY() TArray<FVRIncomingFists> IncomingFists;

    UFUNCTION(BlueprintCallable)
    void SampleVRIncomingFists(AGothicCharacter Source,FVector Left,FVector Right)
    {
        if (!Enabled || !IsValid(Source) || Source==Hero || !IsValid(Hero) || Source.GetWorld()!=Hero.GetWorld()) return;
        float Now=GetGameTimeSinceCreation();
        int Slot=-1;
        for (int I=0; I<IncomingFists.Num(); I++)
        {
            if (IncomingFists[I].Source==Source) { Slot=I; break; }
            if (Now-IncomingFists[I].Time>0.15f) Slot=I;
        }
        if (Slot<0)
        {
            if (IncomingFists.Num()>=4) return;
            Slot=IncomingFists.Num(); IncomingFists.SetNum(Slot+1);
        }
        auto& H=IncomingFists[Slot];
        if (H.Source==Source && H.Time==Now) return;
        H.PreviousTime=H.Source==Source ? H.Time : -1000.0f;
        H.PreviousLeft=H.Left; H.PreviousRight=H.Right;
        H.Source=Source; H.Time=Now; H.Left=Left; H.Right=Right;
    }

    UFUNCTION(BlueprintCallable)
    void SubmitVRForearmGuard(bool Left, FVector LE, FVector LW, bool Right, FVector RE, FVector RW,
                              bool LeftHand, FVector LP, FVector LK, bool RightHand, FVector RP, FVector RK)
    {
        GuardLeftArm = Left; GuardRightArm = Right;
        GuardLeftElbow = LE; GuardLeftWrist = LW;
        GuardRightElbow = RE; GuardRightWrist = RW;
        GuardLeftHand = LeftHand; GuardRightHand = RightHand;
        GuardLeftPalmBase = LP; GuardLeftKnuckles = LK;
        GuardRightPalmBase = RP; GuardRightKnuckles = RK;
        GuardArmsTime = GetGameTimeSinceCreation();
    }
    UPROPERTY() int Blocks = 0;
    UPROPERTY() int Parries = 0;
    UPROPERTY() int Grabs = 0;
    UPROPERTY() int PhysicalGrabs = 0;
    UPROPERTY() int BodyRequests = 0;
    UPROPERTY() int BodyRejected = 0;
    UPROPERTY() FString BodyStatus = "idle";
    UPROPERTY() FString BodyTarget;
    UPROPERTY() FName BodyBone;
    UPROPERTY() int BodyMoveFrames = 0;
    UPROPERTY() int BodyBlockedFrames = 0;
    UPROPERTY() float BodyMovedCm = 0.0f;
    UPROPERTY() FVector BodyRequestedStep;
    UPROPERTY() FVector BodyActualStep;
    UPROPERTY() FVector BodyBetweenTicks;
    UPROPERTY() bool BodyRootMotion = false;
    UPROPERTY() bool BodyMovementTick = false;
    UPROPERTY() int BodyMovementMode = 0;
    UPROPERTY() int BodyCustomMode = 0;
    UPROPERTY() float BodyFloorDistance = -1.0f;
    UPROPERTY() FString BodyEligibility;
    UPROPERTY() FString BodyPose;
    UPROPERTY() FString BodyBlocker;
    UPROPERTY() int PushFrames = 0;
    UPROPERTY() int Warnings = 0;
    UPROPERTY() int Fights = 0;
    UPROPERTY() int ProvocationVoices = 0;
    UPROPERTY() int ProvocationVoiceFailures = 0;
    UPROPERTY() int ProvocationVoiceStage = 0;
    UPROPERTY() FString ProvocationVoiceStatus = "idle";
    UPROPERTY() FString ProvocationVoiceTarget;
    UPROPERTY() FString ProvocationVoiceTag;
    UPROPERTY() bool CombatVoiceWindow = false;
    UPROPERTY() int NearbySpeaking = 0;
    UPROPERTY() int VoiceObservations = 0;
    UPROPERTY() FString LastNearbySpeaker;
    UPROPERTY() FVector LastSpeakerPosition;
    float NextVoiceObservation = 0.0f;
    float VoiceContactUntil = -1.0f;
    float NextProvocationTick = 0.0f;
    UPROPERTY() int SwimFrames = 0;

    UFUNCTION(BlueprintOverride)
    void BeginPlay()
    {
        GrassTickMarker.BindUFunction(GrassDispatchSignal, n"Stop");
        TorchProbes.SetNum(2);
        PushSamples.SetNum(2); PushTravel.SetNum(2);
        Hands.SetNum(3); // left, right, weapon contact (never a grab)
        GripModes.SetNum(2);
        GripTime.SetNum(2);
        GripRetry.SetNum(2);
        Held.SetNum(2);
        FistHits.SetNum(2); RecentPunch.SetNum(2); NextFist.SetNum(2); ArmDrives.SetNum(2);
        BodyMotions.SetNum(4);
        BodyReactionMontages.SetNum(4);
        LeftHandle.SetLinearStiffness(2400.0f);
        RightHandle.SetLinearStiffness(2400.0f);
        LeftHandle.SetLinearDamping(180.0f);
        RightHandle.SetLinearDamping(180.0f);
        LeftHandle.SetInterpolationSpeed(18.0f);
        RightHandle.SetInterpolationSpeed(18.0f);
    }

    UFUNCTION(BlueprintCallable)
    void SubmitHeartbeat(AActor Player, bool Active)
    {
        // Keep the last owner for validated teardown on explicit disable.
        if (Active || IsValid(Player))
        {
            if (Hero != Player)
            {
                ConsumeSwampweedSampleAt = -1.0f;
                LastVRWeapon = nullptr;
                WeaponCommand = 0;
                VRFistsDrawn = false;
            }
            Hero = Cast<AGothicCharacter>(Player);
        }
        Enabled = Active;
        Heartbeat = GetGameTimeSinceCreation();
    }

    UFUNCTION(BlueprintCallable)
    void SubmitBody(int Hand, AActor Target, FName Bone, FVector Point, FVector Goal, FVector HandVelocity, bool Grip, FVector SurfaceNormal, int GripSerial = 0)
    {
        if (Hand < 0 || Hand > 2 || Hands.Num() != 3) return;
        BodyRequests += 1;
        FGothicVRBodyInput Input;
        Input.Target = Cast<AGothicCharacter>(Target);
        Input.Bone = Bone; Input.Point = Point; Input.Goal = Goal;
        Input.Velocity = HandVelocity; Input.Grip = Grip && Hand < 2;
        Input.GripSerial = Input.Grip ? GripSerial : 0;
        Input.Normal = SurfaceNormal.GetSafeNormal();
        Input.Time = GetGameTimeSinceCreation();
        Hands[Hand] = Input;
    }

    UFUNCTION(BlueprintCallable)
    void ClearBody(int Hand)
    {
        if (Hand >= 0 && Hand < Hands.Num()) Hands[Hand].Time = -1000.0f;
    }

    UFUNCTION(BlueprintCallable)
    void SubmitSwim(FVector Acceleration, float VerticalGoal, FVector PlanarGoal)
    {
        SwimForce = FVector(Acceleration.X, Acceleration.Y, 0.0f).GetClampedToMaxSize(1050.0f);
        SwimVerticalGoal = Math::Clamp(VerticalGoal, -145.0f, 145.0f);
        SwimPlanarGoal = FVector(PlanarGoal.X, PlanarGoal.Y, 0.0f).GetClampedToMaxSize(300.0f);
        SwimTime = GetGameTimeSinceCreation();
    }

    UFUNCTION(BlueprintCallable)
    bool CanSwim() const { return Ready() && SwimmingPose; }

    UFUNCTION(BlueprintCallable)
    bool CanSampleWater() const { return Ready() && Wet; }

    UFUNCTION(BlueprintCallable)
    void SubmitSwimView(float Depth)
    {
        EyeDepth = Math::Clamp(Depth, -2000.0f, 2000.0f);
        EyeTime = GetGameTimeSinceCreation();
    }

    void SwimVisionTick(float Delta)
    {
        if (!Wet)
        {
            if (SwimVision.bEnabled) SwimVision.bEnabled = false;
            if (SwimVision.BlendWeight != 0.0f) SwimVision.BlendWeight = 0.0f;
            EyeTime = -1000.0f;
            return;
        }
        const bool Underwater = EyeDepth > 0.0f && GetGameTimeSinceCreation() - EyeTime < 0.18f;
        if (SwimVision.bEnabled == Underwater) return;
        SwimVision.BlendWeight = Underwater ? 1.0f : 0.0f;
        SwimVision.bEnabled = Underwater;
    }

    UFUNCTION(BlueprintCallable)
    bool IsInteractionContact(AActor Actor) const
    {
        auto T = Cast<AGothicCharacter>(Actor);
        return IsValid(T) && IsValid(T.CharacterState) && T.IsHuman() && !T.IsDead() &&
            T.CharacterState.IsDoingAnyInteraction();
    }

    UFUNCTION(BlueprintCallable)
    bool IsCorpse(AActor Actor) const
    {
        auto Character = Cast<AGothicCharacter>(Actor);
        return IsValid(Character) && IsValid(Character.CharacterState) && Character.IsDead();
    }

    UFUNCTION(BlueprintCallable)
    int VRGripDisposition(AGothicCharacter Target) const
    {
        if (!Ready() || !IsValid(Target) || !IsValid(Target.CharacterState) || Target.GetWorld() != GetWorld()) return -1;
        if (Target.IsDead()) return 0;
        if (Target.IsDefeated()) return OwnDownedPose(Target,Target.Mesh) ? 2 : -1;
        if (Target.IsInConversation() || Target.HasGameplayTag(GameplayTag::State_PartOfCinematic) ||
            (Target.IsInCombat() && !Target.IsDefeated())) return -1;
        return 1;
    }

    UPROPERTY() AActor GrassController;
    UPROPERTY() UObject GrassData;
    UPROPERTY() FVector CutLocation;
    UPROPERTY() FVector CutDirection;
    bool GrassPending = false;
    UPROPERTY() FGothicVRGrassTick GrassTickMarker;
    UPROPERTY() bool GrassDispatchWindow = false;
    UPROPERTY() int GrassAcknowledged = 0;
    UPROPERTY() int GrassMarkerRuns = 0;
    UPROPERTY() int GrassSignalReceipts = 0;
    UPROPERTY() int GrassRequests = 0;
    UPROPERTY() int GrassDispatches = 0;

    UFUNCTION(BlueprintCallable)
    bool QueueGrassCut(AActor Controller, UObject Data, FVector Point, FVector Direction)
    {
        if (!Ready() || !IsValid(Controller) || Controller.GetWorld() != GetWorld() || !IsValid(Data) ||
            (Point - Hero.GetActorLocation()).Size() > 240.0f || Direction.Size() < 1.0f) return false;
        GrassController = Controller;
        GrassData = Data;
        GrassPending = true;
        CutLocation = Point;
        CutDirection = Direction.GetSafeNormal();
        GrassRequests += 1;
        return true;
    }

    UFUNCTION(BlueprintCallable)
    bool HasContactWeapon(AActor Actor) const
    {
        auto Target = Cast<AGothicCharacter>(Actor);
        return Ready() && IsValid(Target) && Target.GetWorld() == GetWorld() && IsValid(Target.CarryComponent) &&
            Target.HasDrawnMeleeWeapon() && !Target.HasDrawnFists() && IsValid(Target.CarryComponent.ItemVisual);
    }

    UPROPERTY() FHitResult EnvironmentHit;
    UPROPERTY() int WorldImpactCalls = 0;
    bool ImpactPending = false;
    float LastImpact = -1.0f;

    UFUNCTION(BlueprintCallable)
    bool QueueEnvironmentImpact(FHitResult Hit)
    {
        if (!Ready() || ImpactPending || GetGameTimeSinceCreation() - LastImpact < 0.45f ||
            !IsValid(Hit.Component) || !IsValid(Hit.GetPhysMaterial()) || !IsValid(Hit.Component.Owner) ||
            Hit.Component.Owner.GetWorld() != GetWorld() || Cast<AGothicCharacter>(Hit.Component.Owner) != nullptr) return false;
        EnvironmentHit = Hit;
        ImpactPending = true;
        return true;
    }

    bool GuardLane(AGothicCharacter Source) const
    {
        if (!Ready() || GetGameTimeSinceCreation() - BladeTime > 0.16f ||
            !IsValid(Source) || Source.GetWorld() != GetWorld() || !IsValid(Hero.Mesh) || !IsValid(Source.Mesh)) return false;
        FVector Chest = Hero.Mesh.GetSocketLocation(n"spine_03");
        FVector Hand = Source.Mesh.GetSocketLocation(n"hand_r");
        FVector Lane = Hand - Chest;
        if (Lane.Size() < 12.0f || Lane.Size() > 230.0f) return false;
        FVector Axis = BladeB - BladeA;
        if (Axis.Size() < 12.0f || Math::Abs(Axis.GetSafeNormal().DotProduct(Lane.GetSafeNormal())) > 0.88f) return false;
        for (int I = 0; I <= 5; I++)
        {
            FVector Point = BladeA + Axis * (I / 5.0f) - Chest;
            float Along = Point.DotProduct(Lane.GetSafeNormal());
            if (Along >= 8.0f && Along <= 100.0f && Along <= Lane.Size() + 12.0f &&
                (Point - Lane.GetSafeNormal() * Along).Size() <= 34.0f) return true;
        }
        return false;
    }

    UFUNCTION(BlueprintCallable)
    bool DefendingAgainst(AActor Actor) const
    {
        auto Source = Cast<AGothicCharacter>(Actor);
        return IsValid(Source) && Source.HasGameplayTag(GameplayTag::State_Attack) && Source.HasDrawnMeleeWeapon() && GuardLane(Source);
    }

    UFUNCTION(BlueprintCallable)
    void SubmitBlade(FVector A, FVector B)
    {
        float Now = GetGameTimeSinceCreation();
        float Delta = Now - BladeTime;
        if (!Ready()) return;
        FVector Origin = Hero.GetActorLocation();
        FVector TipMotion = B - BladeB - (Origin - GuardOrigin);
        HasPreviousBlade = Delta > 0.001f && Delta < 0.09f && TipMotion.Size() < 40.0f && (Origin - GuardOrigin).Size() < 30.0f;
        PreviousBladeA = BladeA; PreviousBladeB = BladeB;
        float Speed = HasPreviousBlade ? TipMotion.Size() / Delta : 0.0f;
        if (Speed >= 75.0f && !GuardMoving) { GuardRaised = Now; GuardMoving = true; }
        if (Speed < 38.0f) GuardMoving = false;
        GuardOrigin = Origin;
        BladeA = A; BladeB = B; BladeTime = Now;
    }

    bool OwnerSuspended = false;
    bool CleanupOnRebind = false;
    UPROPERTY() bool FurniturePose = false;
    UPROPERTY() bool InteractionOwnsMovement = false;
    UPROPERTY() bool DownedPose = false;

    bool OwnerWorldAvailable() const
    {
        return IsValid(Hero) && IsValid(Hero.CharacterState) && IsValid(Hero.Mesh) &&
            IsValid(GetWorld()) && Hero.GetWorld() == GetWorld();
    }
    UPROPERTY() TArray<FGothicVRTorchProbe> TorchProbes;
    UPROPERTY() int TorchLitCount = 0;
    UPROPERTY() int TorchLitAttempts = 0;
    UPROPERTY() int TorchContactsQueued = 0;
    UPROPERTY() int TorchProbeCount = 0;
    UPROPERTY() int TorchSpotCount = 0;
    UPROPERTY() int TorchBurnerCount = 0;
    UPROPERTY() float TorchMinGap = -1.0f;
    UPROPERTY() FString TorchNearestBurner;
    UPROPERTY() FString TorchContactResult;

    UFUNCTION(BlueprintCallable)
    void ClearVRTorchProbe(int Hand)
    {
        if (!TorchProbes.IsValidIndex(Hand)) return;
        FGothicVRTorchProbe Empty;
        TorchProbes[Hand] = Empty;
    }

    UFUNCTION(BlueprintCallable)
    void SubmitVRTorchTip(int Hand, AActor Source, UNiagaraComponent Flame, FVector Base, FVector Tip)
    {
        if (!TorchProbes.IsValidIndex(Hand) || !IsValid(Source) || !IsValid(Flame)) return;
        if (TorchProbes[Hand].Source != Source) ClearVRTorchProbe(Hand);
        TorchProbes[Hand].Source = Source;
        TorchProbes[Hand].Flame = Flame;
        TorchProbes[Hand].Base = Base;
        TorchProbes[Hand].Tip = Tip;
        TorchProbes[Hand].SampleTime = GetGameTimeSinceCreation();
        TorchProbes[Hand].Pending = true;
    }

    void RefreshTorchBurners(FGothicVRTorchProbe& Probe, float Now)
    {
        Probe.SearchTime = Now;
        Probe.SearchPoint = Probe.Tip;
        Probe.Burners.Reset();
        TorchProbeCount += 1;
        // A standing character's interaction spot can be metres from the wick.
        // An unlit flame need not produce a collision body in a physics overlap.
        TArray<AActor> Actors;
        auto Spots = InteractionSpots::FindSpotsInRadius(Probe.Tip, 380.0f);
        TorchSpotCount = 0;
        for (auto Spot : Spots)
        {
            if (!Spot.IsActionPossibleHere(GameplayTag::Action_StartFire)) continue;
            auto Target = Cast<AInteractiveGasObjectActor>(Spot.ActorToInteractWith);
            if (!IsValid(Target) || Target.GetWorld() != GetWorld()) continue;
            TorchSpotCount += 1;
            Actors.AddUnique(Target);
        }
        TArray<EObjectTypeQuery> Types;
        Types.Add(EObjectTypeQuery::WorldStatic);
        Types.Add(EObjectTypeQuery::WorldDynamic);
        TArray<AActor> Ignore;
        Ignore.Add(Hero);
        TArray<AActor> Physical;
        System::SphereOverlapActors(Probe.Tip, 105.0f, Types, AInteractiveGasObjectActor::StaticClass(), Ignore, Physical);
        for (auto Actor : Physical)
        {
            auto Target = Cast<AInteractiveGasObjectActor>(Actor);
            if (!IsValid(Target) || Target.GetWorld() != GetWorld()) continue;
            auto Definition = Target.GetInteractiveObjectDefinition();
            if (IsValid(Definition) && Definition.m_DefaultInteraction == GameplayTag::Action_StartFire)
                Actors.AddUnique(Target);
        }
        for (auto Actor : Actors)
        {
            if (!IsValid(Actor.RootComponent) || Actor.RootComponent.ComponentHasTag(n"InnosPray")) continue;
            TArray<UPrimitiveComponent> Parts;
            Actor.GetComponentsByClass(UPrimitiveComponent::StaticClass(), Parts);
            for (auto Part : Parts)
            {
                if (!IsValid(Part)) continue;
                FString PartName = Part.GetName().ToString();
                if (PartName.StartsWith("FirePlane") || PartName.StartsWith("Spells Collision"))
                    Probe.Burners.Add(Part);
            }
        }
        TorchBurnerCount = Probe.Burners.Num();
    }

    void ResolveTorchTip(FGothicVRTorchProbe& Probe, float Now)
    {
        if (!Probe.Pending) return;
        Probe.Pending = false;
        if (!Ready() || Now - Probe.SampleTime > 0.2f || !IsValid(Probe.Source) ||
            !IsValid(Probe.Flame) || !Probe.Flame.IsActive() || Probe.Source.GetWorld() != GetWorld() ||
            !IsValid(Probe.Flame.GetOwner()) || Probe.Flame.GetOwner().GetWorld() != GetWorld() ||
            (Hero.GetActorLocation() - Probe.Tip).Size() > 260.0f) return;
        if (Now - Probe.SearchTime >= 0.55f ||
            (Now - Probe.SearchTime >= 0.10f && (Probe.SearchPoint - Probe.Tip).Size() > 32.0f))
            RefreshTorchBurners(Probe, Now);
        UPrimitiveComponent Nearest;
        FVector Wick;
        float Gap = 10000.f;
        for (auto Part : Probe.Burners)
        {
            if (!IsValid(Part) || !IsValid(Part.GetOwner())) continue;
            FVector Anchor = Part.GetWorldLocation();
            FVector E = Part.GetBounds().BoxExtent;
            FVector D = Probe.Tip - Anchor;
            bool Shape = Part.GetName().ToString().StartsWith("Spells Collision");
            float MaxZ = Shape ? Math::Min(12.0, E.Z) : 0.0;
            FVector Q = Anchor + FVector(Math::Clamp(D.X, -Math::Min(42.0, E.X), Math::Min(42.0, E.X)),
                Math::Clamp(D.Y, -Math::Min(42.0, E.Y), Math::Min(42.0, E.Y)),
                Math::Clamp(D.Z, -MaxZ, MaxZ));
            float Distance = (Q - Probe.Tip).Size();
            if (Distance < Gap) { Nearest = Part; Gap = Distance; Wick = Q; }
        }
        if (IsValid(Nearest) && (TorchMinGap < 0.0f || Gap < TorchMinGap))
        {
            TorchMinGap = Gap;
            TorchNearestBurner = Nearest.GetFullName();
        }
        if (!IsValid(Nearest) || Gap > 13.0f)
        {
            if (Gap > 22.0f) Probe.Latched = nullptr;
            return;
        }
        auto Target = Cast<AInteractiveGasObjectActor>(Nearest.GetOwner());
        if (!IsValid(Target) || Target == Probe.Latched) return;
        TArray<AActor> Ignore;
        Ignore.Add(Hero); Ignore.Add(Probe.Source); Ignore.Add(Probe.Flame.GetOwner()); Ignore.Add(Target);
        // Trace from behind the flame; an overlap on the far side of thin stone
        // must not ignite even when the tip and the selected wick coincide.
        FVector Start = Probe.Tip + (Probe.Base - Probe.Tip).GetSafeNormal() * 8.0f;
        FHitResult Block;
        if (System::LineTraceSingle(Start, Wick, ETraceTypeQuery::Visibility, true, Ignore, EDrawDebugTrace::None, Block, true))
        {
            TorchContactResult = "occluded";
            return;
        }
        Probe.Latched = Target;
        TorchContactsQueued += 1;
        auto Interaction = Target.GetInteractiveComponent();
        TorchContactResult = "interaction_disabled";
        if (!IsValid(Interaction) || Interaction.GetForceDisableInteraction() ||
            !Interaction.IsUsable() || Interaction.IsBeingUsed()) return;
        // A placed interaction spot may add requirements beyond the shared
        // object definition. Respect them at contact without claiming the spot.
        bool HasSpot = false;
        bool Claimable = false;
        auto NearbySpots = InteractionSpots::FindSpotsInRadius(Probe.Tip, 380.0f);
        for (auto Spot : NearbySpots)
        {
            if (!Spot.IsActionPossibleHere(GameplayTag::Action_StartFire) ||
                Cast<AInteractiveGasObjectActor>(Spot.ActorToInteractWith) != Target) continue;
            HasSpot = true;
            if (Spot.CanBeClaimedBy(Hero.CharacterState, GameplayTag::Action_StartFire))
            {
                Claimable = true;
                break;
            }
        }
        if (HasSpot && !Claimable)
        {
            TorchContactResult = "spot_unavailable";
            return;
        }
        auto Fire = Target.GetFireComponent();
        TorchContactResult = "already_lit_or_missing_fire";
        if (!IsValid(Fire) || Fire.IsFireOn()) return;
        TorchLitAttempts += 1;
        Target.SetLit(true, true);
        TorchContactResult = Fire.IsFireOn() ? "lit" : "requested";
        if (Fire.IsFireOn()) TorchLitCount += 1;
    }

    void TorchContactTick()
    {
        for (int Hand = 0; Hand < TorchProbes.Num(); Hand++)
        {
            ResolveTorchTip(TorchProbes[Hand], GetGameTimeSinceCreation());
        }
    }

    bool Ready() const
    {
        return Enabled && OwnerWorldAvailable() &&
            !Hero.IsDead() && GetGameTimeSinceCreation() - Heartbeat < 0.3f;
    }

    int HandTargetState(AGothicCharacter Target) const
    {
        if (Target.IsDead()) return 2;
        return Target.IsDefeated() ? 1 : 0;
    }

    UPROPERTY() UFMODEvent FistImpactEvent;
    UPROPERTY() UFMODEvent PalmImpactEvent;
    UPROPERTY() int RestingSlapSounds = 0;

    void SoundRestingSlapAt(FVector Point)
    {
        if (!IsValid(PalmImpactEvent))
            PalmImpactEvent = Cast<UFMODEvent>(LoadObject(nullptr,"/Game/FMOD/Events/SFX/Actions/Clap/SFX_ACTION_Clap_Single.SFX_ACTION_Clap_Single"));
        if (!IsValid(PalmImpactEvent)) return;
        FTransform Position;
        Position.SetLocation(Point);
        FMODBlueprint::PlayEventAtLocation(this,PalmImpactEvent,Position,true);
        RestingSlapSounds += 1;
    }

    void SoundFistAt(FVector Point)
    {
        if (!IsValid(FistImpactEvent))
            FistImpactEvent = Cast<UFMODEvent>(LoadObject(nullptr,"/Game/FMOD/Events/SFX/Physics/Impacts/Melee/SFX_PHYSICS_Impacts_Melee.SFX_PHYSICS_Impacts_Melee"));
        if (!IsValid(FistImpactEvent)) return;
        FTransform Position;
        Position.SetLocation(Point);
        auto Sound = FMODBlueprint::PlayEventAtLocation(this,FistImpactEvent,Position,false);
        if (!FMODBlueprint::EventInstanceIsValid(Sound)) return;
        FMODBlueprint::EventInstanceSetParameter(Sound,n"IMP_sourceWeapon",1.0f);
        FMODBlueprint::EventInstanceSetParameter(Sound,n"IMP_targetArmor",1.0f);
        // The FMOD Blueprint wrapper releases the one-shot when playback starts.
        FMODBlueprint::EventInstancePlay(Sound);
    }

    void ResolveHandContacts(float Now)
    {
        for (int I = HandDefeats.Num()-1; I >= 0; I--)
        {
            auto Target = HandDefeats[I].Target;
            if (!IsValid(Target) || Target.GetWorld() != GetWorld() || !IsValid(Target.CharacterState) || HandTargetState(Target) != 1)
                HandDefeats.RemoveAt(I);
        }
        for (int I = PendingHandImpacts.Num()-1; I >= 0; I--)
        {
            auto Hit = PendingHandImpacts[I];
            auto Target = Hit.Target;
            if (!Ready() || !IsValid(Target) || Target.GetWorld() != GetWorld() || !IsValid(Target.CharacterState) ||
                !IsValid(Target.Mesh) || HandTargetState(Target) != Hit.StrikeState || Now-Hit.Time > 0.5f)
            { PendingHandImpacts.RemoveAt(I); continue; }
            FName Bone = SimulatedBone(Target.Mesh, Hit.Bone);
            if (Bone == n"None") continue;
            PendingHandImpacts.RemoveAt(I);
            if ((Target.Mesh.GetSocketLocation(Bone)-Hit.Point).Size() > 60.0f) continue;
            FVector Center = Target.Mesh.GetCenterOfMass(Bone);
            float Mass = Math::Clamp(float(Target.Mesh.GetBoneMass(Bone)),0.1f,35.0f);
            FVector Kick = (Hit.Velocity * (0.38f * StrengthScale)).GetClampedToMaxSize(155.0f);
            FVector Contact = Center + (Hit.Point-Center).GetClampedToMaxSize(8.0f);
            Target.Mesh.AddImpulseAtLocation((Kick*Mass).GetClampedToMaxSize(3000.0f), Contact, Bone);
            HandBodyImpulses += 1;
        }
        for (int I = PendingFistBounties.Num()-1; I >= 0; I--)
        {
            auto Hit = PendingFistBounties[I];
            auto Target = Hit.Target;
            if (!Ready() || !IsValid(Target) || Target.GetWorld() != GetWorld() || !IsValid(Target.CharacterState) ||
                Target.IsDead() || Now-Hit.Time > 1.0f)
            { PendingFistBounties.RemoveAt(I); continue; }
            if (Now-Hit.Time < 0.12f || !Target.IsDefeated()) continue;
            PendingFistBounties.RemoveAt(I);
            auto Combat = DataModule::GetCombatDataModule(Target);
            auto ASC = Target.GetGothicAbilitySystemComponent();
            if (!IsValid(Combat) || Combat.GetLastAttackerCharacter() != Hero || !IsValid(ASC) ||
                !IsValid(Hero.CharacterState) || Target.CharacterState.HasGameplayTag(GameplayTag::State_KillBountyGranted)) continue;
            int Amount = int(Target.CharacterState.GetXPKillOrDefeatBountyAttribute());
            if (Amount <= 0) continue;
            ASC.AddTag(GameplayTag::State_KillBountyGranted);
            FistDefeatXP += Amount;
            Hero.CharacterState.GiveExperience(Amount);
        }
    }

    void StrikeRestingBody(FGothicVRBodyInput Hit)
    {
        auto Target = Hit.Target;
        if (Hit.StrikeState == 2) WakeCorpseContact(Target, Hit.Bone);
        else
        {
            if (!OwnDownedPose(Target, Target.Mesh)) return;
            RefreshDownedRecovery(Target);
            int Slot = BeginDowned(Target, Hit.Time);
            if (Slot >= 0)
            {
                DownedBodies[Slot].LastTouch = Hit.Time;
                EnableDownedTorso(Target, Slot);
            }
        }
        SoundFistAt(Hit.Point);
        if (PendingHandImpacts.Num() < 8) PendingHandImpacts.Add(Hit);
        if (Hit.StrikeState == 2 || !Finishable(Target)) return;
        int Slot = -1;
        for (int I = 0; I < HandDefeats.Num(); I++)
            if (HandDefeats[I].Target == Target) { Slot = I; break; }
        if (Slot < 0)
        {
            FGothicVRHandDefeat Entry;
            Entry.Target = Target;
            Slot = HandDefeats.Num();
            HandDefeats.Add(Entry);
        }
        int Count = HandDefeats[Slot].Hits;
        if (Count < 9) Count += 1;
        else if (Count == 9 && QueueFinisher(Hero, Target, true) == 1) Count = 10;
        HandDefeats[Slot].Hits = Count;
        LastDownedHitCount = Count;
    }

    UFUNCTION(BlueprintCallable)
    bool QueueFistHit(int Hand, AActor Actor, FVector Point, FVector HandVelocity)
    {
        if (Hand < 0 || Hand > 1 || FistHits.Num() != 2 || !Ready()) return false;
        auto Target = Cast<AGothicCharacter>(Actor);
        if (!IsValid(Target) || !IsValid(Target.CharacterState) || Target == Hero || Target.IsPlayerControlled() || Target.GetWorld() != GetWorld()) return false;
        float Now = GetGameTimeSinceCreation();
        if (Now < NextFist[Hand] || HandVelocity.Size() < 175.0f) return false;
        FGothicVRBodyInput Hit;
        Hit.StrikeState = HandTargetState(Target);
        if (Hand < Hands.Num() && Hands[Hand].Target == Target) Hit.Bone = Hands[Hand].Bone;
        Hit.Target = Target; Hit.Point = Point; Hit.Velocity = HandVelocity.GetClampedToMaxSize(450.0f); Hit.Time = Now;
        FistHits[Hand] = Hit; NextFist[Hand] = Now + 0.38f;
        return true;
    }

    UFUNCTION(BlueprintCallable)
    bool QueueRestingSlap(int Hand, AActor Actor, FVector Point, FVector HandVelocity)
    {
        auto Target = Cast<AGothicCharacter>(Actor);
        if (!IsValid(Target) || Target.GetWorld() != GetWorld() || !IsValid(Target.CharacterState) ||
            HandTargetState(Target) == 0 || !QueueFistHit(Hand, Actor, Point, HandVelocity)) return false;
        FistHits[Hand].RestingSlap = true;
        return true;
    }

    UFUNCTION(BlueprintCallable)
    bool QueueTorchHit(int Hand, AActor Actor, FVector Point, FVector HandVelocity)
    {
        auto Target = Cast<AGothicCharacter>(Actor);
        if (!IsValid(Target) || !IsValid(Target.CharacterState) || HandTargetState(Target) != 0) return false;
        if (HandVelocity.Size() < 210.0f || !QueueFistHit(Hand, Actor, Point, HandVelocity)) return false;
        FGothicVRBodyInput Hit = FistHits[Hand];
        Hit.TorchStrike = true;
        FistHits[Hand] = Hit;
        return true;
    }

    void FistTick()
    {
        float Now = GetGameTimeSinceCreation();
        ResolveHandContacts(Now);
        for (int I = 0; I < FistHits.Num(); I++)
        {
            auto Hit = FistHits[I];
            if (!IsValid(Hit.Target)) continue;
            FGothicVRBodyInput Empty;
            FistHits[I] = Empty;
            auto Target = Hit.Target;
            if (Ready() && !Hero.IsDefeated() && !Hero.IsInConversation() && Now - Hit.Time <= 0.15f &&
                IsValid(Target) && IsValid(Target.CharacterState) && Target.GetWorld() == GetWorld() &&
                Hit.StrikeState == HandTargetState(Target) && !Target.IsInConversation() &&
                (Hit.RestingSlap || Hit.StrikeState == 2 || !Target.HasGameplayTag(GameplayTag::State_Invulnerable)) &&
                !Target.HasGameplayTag(GameplayTag::State_PartOfCinematic) &&
                (Hit.Point - Hero.GetActorLocation()).Size() < 240.0f)
            {
                if (Hit.RestingSlap)
                {
                    if (Hit.StrikeState != 0) SoundRestingSlapAt(Hit.Point);
                    continue;
                }
                if (Hit.StrikeState != 0)
                {
                    if (!Hit.TorchStrike && IsValid(Target.Mesh)) StrikeRestingBody(Hit);
                    continue;
                }
                auto Source = GothicGAS::GetAbilitySystemComponent(Hero);
                auto Victim = GothicGAS::GetAbilitySystemComponent(Target);
                if (IsValid(Source) && IsValid(Victim))
                {
                    FGameplayEffectContext_HitResponse Data;
                    Data.WeaponUsed = UHumanFist_NoWeapon::StaticClass();
                    if (Hit.TorchStrike) Data.WeaponUsed = UItMw_1H_Torch::StaticClass();
                    Data.Impact = GameplayTag::Combat_HitType_Standard;
                    Data.SourceAttackDirection = I == 0 ? GameplayTag::Combat_Attack_Left : GameplayTag::Combat_Attack_Right;
                    Data.SourceDirection = MagicScript::GetCombatDirectionGivenHitLocation(Target.GetActorForwardVector(), Target.GetActorRightVector(), (Hero.GetActorLocation() - Target.GetActorLocation()).GetSafeNormal());
                    Data.CanBeParried = true; Data.CanBeDeflected = true;
                    Data.MultiplierSuperArmor = 1.0f;
                    FHitResult Sweep;
                    Sweep.SetActor(Target);
                    Sweep.SetComponent(Target.Mesh);
                    Sweep.BoneName = Hit.Bone;
                    Sweep.Location = Hit.Point;
                    Sweep.ImpactPoint = Hit.Point;
                    FistDamageCalls += 1;
                    // A single GAS hit owns recoil, defeat and AI. Keep the other
                    // hand from treating this contact as an independent shove.
                    RecentPunch[I] = Hit;
                    if (!Hit.TorchStrike && StrengthScale * Hit.Velocity.Size() > 370.0f)
                        Data.CustomKnockbackData = UKnockbackDataDefault::StaticClass();
                    float Before = Target.GetHealthAttribute();
                    GothicGAS::ApplyDamageTo(Source, Hero, Hero, Victim, Data, Sweep);
                    if (!Hit.TorchStrike && IsValid(Target) && IsValid(Target.CharacterState) && !Target.IsDead() &&
                        (Target.IsDefeated() || (Target.GetHealthAttribute() < Before && Target.GetHealthAttribute() <= 1.0f)))
                        PendingFistBounties.Add(Hit);
                }
            }
        }
    }

    // A pouch is a meta-item. Its actual inventory stays on the NPC until stow.
    UPROPERTY() APouchActor BeltPouch;
    UPROPERTY() AGothicCharacter PouchOwner;
    UPROPERTY() int PouchSerial = 0;
    UPROPERTY() int PouchPhase = 0; // 1 attempt, 2 held, 3 stow, 4 committing, 5 cancel
    UPROPERTY() FString PouchStatus = "idle";
    UPROPERTY() int PouchRequestedItems = 0;
    UPROPERTY() int PouchCreditedItems = 0;
    UPROPERTY() int PouchReturnedItems = 0;
    bool PouchVisualHidden = false;
    bool PouchHeldFromCorpse = false;

    AGothicCharacter BeltOwner(APouchActor Pouch) const
    {
        if (!IsValid(Pouch) || Pouch.GetWorld() != GetWorld()) return nullptr;
        // Ownership may persist on a dropped pouch. Require actual belt attachment.
        AActor Parent = Pouch.GetAttachParentActor();
        for (int I = 0; I < 3 && IsValid(Parent); I++)
        {
            auto Character = Cast<AGothicCharacter>(Parent);
            if (IsValid(Character)) return Character;
            Parent = Parent.GetAttachParentActor();
        }
        return nullptr;
    }

    UFUNCTION(BlueprintCallable)
    int RequestBeltPouch(APouchActor Pouch)
    {
        if (!Ready() || PouchPhase != 0 || !IsValid(Pouch)) return 0;
        auto OwnerCharacter = BeltOwner(Pouch);
        if (!IsValid(OwnerCharacter) || OwnerCharacter == Hero || !IsValid(OwnerCharacter.CharacterState) ||
            Pouch.IsHidden() ||
            (Pouch.GetActorLocation()-Hero.GetActorLocation()).Size() > 215.0f) return 0;
        BeltPouch = Pouch;
        PouchOwner = OwnerCharacter;
        PouchRequestedItems = 0;
        PouchCreditedItems = 0;
        PouchReturnedItems = 0;
        PouchPhase = 1;
        PouchSerial += 1;
        return PouchSerial;
    }

    UFUNCTION(BlueprintCallable)
    void ReleaseBeltPouch(int Serial, bool Stow)
    {
        if (Serial != PouchSerial || (PouchPhase != 1 && PouchPhase != 2)) return;
        if (Stow && PouchPhase == 2) PouchPhase = 3;
        else PouchPhase = 5; // game Tick restores the original visual
    }

    void ClearPouch()
    {
        if (PouchVisualHidden && IsValid(BeltPouch) && BeltPouch.GetWorld() == GetWorld())
            BeltPouch.SetActorHiddenInGame(false);
        PouchVisualHidden = false;
        PouchHeldFromCorpse = false;
        PouchPhase = 0;
        BeltPouch = nullptr;
        PouchOwner = nullptr;
    }

    int PouchStackCount(UDataModule_Container Container, EInventoryTypes Slot, TSubclassOf<UItemDefinition> Definition) const
    {
        int Count = 0;
        for (const auto& Row : Container.GetItemsInConst(Slot))
            if (Row.m_SlotData.m_ItemDefinition == Definition) Count += Row.m_SlotData.m_ItemCount;
        return Count;
    }

    void PouchTick()
    {
        if (PouchPhase == 0) return;
        if (PouchPhase == 5) { PouchStatus = "cancelled"; ClearPouch(); return; }
        auto Victim = PouchOwner;
        if (!IsValid(Victim) || Victim.GetWorld() != GetWorld() || !IsValid(Victim.CharacterState))
        { ClearPouch(); return; }
        if (PouchPhase != 4 && (BeltOwner(BeltPouch) != Victim || (PouchHeldFromCorpse && !Victim.IsDead())))
        { ClearPouch(); return; }
        if (PouchPhase == 2 || PouchPhase == 4) return;
        auto Source = DataModule::GetContainerDataModule(Victim);
        auto Destination = DataModule::GetContainerDataModule(Hero);
        if (!IsValid(Source) || !IsValid(Destination)) { ClearPouch(); return; }
        TArray<TSubclassOf<UItemDefinition>> Definitions;
        for (const auto& Row : Source.GetItemsInConst(EInventoryTypes::Pouch))
        {
            if (Row.m_SlotData.m_ItemCount <= 0 || Row.m_SlotData.m_ItemDefinition == nullptr) continue;
            Definitions.AddUnique(Row.m_SlotData.m_ItemDefinition);
        }
        // The loot window can already have taken some or all rows. A visible
        // corpse pouch can still be lifted and put back, including an empty one.
        if (Definitions.IsEmpty() && !Victim.IsDead()) { PouchStatus = "empty"; ClearPouch(); return; }
        if (PouchPhase == 1 && Victim.IsDead())
        {
            PouchHeldFromCorpse = true;
            PouchPhase = 2;
            PouchStatus = Definitions.IsEmpty() ? "held_corpse_empty" : "held_corpse";
            BeltPouch.SetActorHiddenInGame(true);
            PouchVisualHidden = true;
            return;
        }
        if (PouchPhase == 3)
        {
            // The authoritative game tick applies these inventory operations locally.
            // Never follow a queued transfer with a second grant. Check each actual
            // debit before crediting it; return any rejected credit to the same pocket.
            PouchPhase = 4;
            if (!Hero.HasAuthority() || !IsValid(Hero.Inventory) || !IsValid(Victim.Inventory))
            { PouchStatus = "inventory_unavailable"; ClearPouch(); return; }
            if (Definitions.IsEmpty())
            {
                // Loot All won the race. Stow the shell with zero inventory mutations.
                PouchStatus = "stowed_corpse_empty";
                PouchVisualHidden = false;
                ClearPouch();
                return;
            }
            for (auto Definition : Definitions)
            {
                int Before = PouchStackCount(Source, EInventoryTypes::Pouch, Definition);
                if (Before <= 0) continue;
                int Owned = PouchStackCount(Destination, EInventoryTypes::MainContainer, Definition);
                PouchRequestedItems += Before;
                Source.Multicast_ConsumeItemOfType(EInventoryTypes::Pouch, Definition, Before, false);
                int Remaining = PouchStackCount(Source, EInventoryTypes::Pouch, Definition);
                int Debited = Math::Clamp(Before - Remaining, 0, Before);
                if (Debited == 0) break;
                FItemPayload Payload;
                Destination.Multicast_AddNewItem(EInventoryTypes::MainContainer, Definition, Debited, Payload, false);
                int Credited = Math::Clamp(PouchStackCount(Destination, EInventoryTypes::MainContainer, Definition) - Owned, 0, Debited);
                PouchCreditedItems += Credited;
                if (Credited < Debited)
                {
                    Source.Multicast_AddNewItem(EInventoryTypes::Pouch, Definition, Debited - Credited, Payload, false);
                    PouchReturnedItems += Math::Clamp(PouchStackCount(Source, EInventoryTypes::Pouch, Definition) - Remaining, 0, Debited - Credited);
                    break;
                }
                if (Debited < Before) break;
            }
            bool Empty = true;
            for (const auto& Row : Source.GetItemsInConst(EInventoryTypes::Pouch))
                if (Row.m_SlotData.m_ItemDefinition != nullptr && Row.m_SlotData.m_ItemCount > 0) Empty = false;
            bool Complete = Empty && PouchCreditedItems > 0 && PouchCreditedItems == PouchRequestedItems;
            PouchStatus = Complete ? "transferred" : "transfer_incomplete";
            if (Complete && BeltOwner(BeltPouch) == Victim) PouchVisualHidden = false;
            ClearPouch();
            return;
        }
        if (!IsValid(Victim.Perception) || !IsValid(Hero.Perception)) { ClearPouch(); return; }
        float Skill = Hero.CharacterState.GetDexterityAttribute();
        float Difficulty = Victim.CharacterState.GetDexterityAttribute();
        bool Success = Math::RandRange(1,100) <= Math::Clamp(50.0f + Skill - Difficulty, 5.0f, 95.0f);
        PouchPhase = Success ? 2 : 0;
        PouchStatus = Success ? "held" : "caught";
        if (Success) { BeltPouch.SetActorHiddenInGame(true); PouchVisualHidden = true; }
        auto Event = Success ? GameplayTag::Perception_Pickpocketing_Succeeded : GameplayTag::Perception_Pickpocketing_Failed;
        Hero.Perception.ReportPerceptionEvent(Event, Victim.GetActorLocation(),
            SensedCharacter = Hero, TargetActor = Victim, InstigatorActor = Hero, AffectedActor = Victim);
        if (!Success)
        {
            ClearPouch();
            if (!Ready() || !IsValid(Victim) || !IsValid(Victim.CharacterState) ||
                Victim.GetWorld() != GetWorld() || Victim.IsDead()) return;
            auto VictimAI = Victim.GetCharacterAI();
            if (!IsValid(VictimAI)) return;
            // The thief's event feeds crime registration and visual witnesses.
            // The affected NPC also feels a failed grab from behind.
            FRememberedPerception Perception;
            Perception.EventTag = GameplayTag::AIEvent_Sensed_Pickpocketing_Failed_OnSelf;
            Perception.Origin.Character = Hero;
            Perception.Origin.CharacterState = Hero.CharacterState;
            Perception.Origin.AtPosition = Hero.GetActorLocation();
            Perception.Instigator = Perception.Origin;
            Perception.Target.Character = Victim;
            Perception.Target.CharacterState = Victim.CharacterState;
            Perception.Target.AtPosition = Victim.GetActorLocation();
            Perception.Affected = Perception.Target;
            VictimAI.AssessEvent(Perception.EventTag, Perception);
        }
    }

    bool IsWeaponImpactObject(AInteractiveGasObjectActor Object) const
    {
        if (!IsValid(Object)) return false;
        auto Definition = Object.GetInteractiveObjectDefinition();
        if (!IsValid(Definition) || Definition.m_OptionalObject.Get() == nullptr) return false;
        auto Door = Cast<UDoorInteractiveExtraData>(Definition.m_OptionalObject.Get().GetDefaultObject());
        return IsValid(Door) && Door.m_DoorType == EDoorType::Impact;
    }

    UFUNCTION(BlueprintCallable)
    bool QueueVRMeleeHit(AGothicCharacter Attacker, AActor Target, const FHitResult&in Sweep, FGameplayTag Attack)
    {
        if (!Ready() || Attacker != Hero || !IsValid(Target) || Target == Hero ||
            Target.GetWorld() != GetWorld() || MeleeHits.Num() >= 12) return false;
        auto Character = Cast<AGothicCharacter>(Target);
        if (IsValid(Character))
        {
            if (!IsValid(Character.CharacterState) || Character.IsDead() || Character.IsDefeated()) return false;
        }
        else if (Sweep.GetActor() != Target || !IsWeaponImpactObject(Cast<AInteractiveGasObjectActor>(Target))) return false;
        auto Carry = Hero.GetCarryComponent();
        if (!IsValid(Carry)) return false;
        auto Weapon = Cast<UWeaponMeleeDefinition>(Carry.GetEquippedItemDefinition());
        if (!IsValid(Weapon)) return false;
        for (int I = 0; I < MeleeHits.Num(); I++)
        {
            if (MeleeHits[I].Target == Target) return false;
        }
        FGothicVRMeleeHit Pending;
        Pending.Target = Target; Pending.Weapon = Weapon; Pending.Sweep = Sweep;
        Pending.Attack = Attack; Pending.Time = GetGameTimeSinceCreation();
        MeleeHits.Add(Pending);
        return true;
    }

    void MeleeTick()
    {
        auto Requests = MeleeHits;
        MeleeHits.Empty();
        for (auto Hit : Requests)
        {
            if (!Ready() || Hero.IsDead() || Hero.IsDefeated() || Hero.IsInConversation() ||
                !IsValid(Hit.Target) || Hit.Target.GetWorld() != GetWorld() || GetGameTimeSinceCreation() - Hit.Time > 0.25f) continue;
            auto Carry = Hero.GetCarryComponent();
            if (!IsValid(Carry) || !IsValid(Hit.Weapon) || Carry.GetEquippedItemDefinition() != Hit.Weapon ||
                !IsValid(Carry.GetItemVisual())) continue;
            auto Character = Cast<AGothicCharacter>(Hit.Target);
            if (!IsValid(Character))
            {
                auto Object = Cast<AInteractiveGasObjectActor>(Hit.Target);
                if (IsWeaponImpactObject(Object) && Object.CanReceiveImpact()) Object.OnImpact();
                continue;
            }
            if (!IsValid(Character.CharacterState) || Character.IsDead() || Character.IsDefeated()) continue;
            auto Source = GothicGAS::GetAbilitySystemComponent(Hero);
            auto Victim = GothicGAS::GetAbilitySystemComponent(Hit.Target);
            if (!IsValid(Source) || !IsValid(Victim)) continue;
            FGameplayEffectContext_HitResponse Data;
            Data.WeaponUsed = Hit.Weapon.GetClass();
            Data.SourceAttackDirection = Hit.Attack;
            Data.SourceDirection = MagicScript::GetCombatDirectionGivenHitLocation(Character.GetActorForwardVector(),
                Character.GetActorRightVector(), (Hero.GetActorLocation() - Character.GetActorLocation()).GetSafeNormal());
            Data.Impact = GameplayTag::Combat_HitType_Standard;
            Data.CanBeParried = true; Data.CanBeDeflected = true; Data.MultiplierSuperArmor = 1.0f;
            GothicGAS::ApplyDamageTo(Source, Hero, Carry.GetItemVisual(), Victim, Data, Hit.Sweep);
        }
    }

    // Match the source/target ASC filter used by UGE_Ex_Damage::Execute.
    bool FinishingDamageFilterAllows(AGothicCharacter Target) const
    {
        auto TargetASC = Target.GetGothicAbilitySystemComponent();
        auto SourceASC = Hero.GetGothicAbilitySystemComponent();
        if (!IsValid(TargetASC) || !IsValid(SourceASC)) return false;
        if (!TargetASC.HasGameplayTag(GameplayTag::Filter_Damage)) return true;
        TArray<FGameplayTag> RequiredTags;
        TargetASC.GetAllChildTags(GameplayTag::Filter_Damage, RequiredTags);
        for (auto Required : RequiredTags)
            if (SourceASC.HasGameplayTag(Required)) return true;
        return false;
    }

    bool Finishable(AGothicCharacter Target) const
    {
        return IsValid(Target) && IsValid(Target.CharacterState) && Target != Hero &&
            Target.GetWorld() == GetWorld() && !Target.IsPlayerControlled() &&
            Target.IsDefeated() && !Target.IsDead() && !Target.IsInConversation() &&
            !Target.GetPathName().Contains("GothicVR_Training") &&
            !Target.HasGameplayTag(GameplayTag::State_PartOfCinematic) &&
            !Target.HasGameplayTag(GameplayTag::State_Immortal) &&
            !Target.HasGameplayTag(GameplayTag::State_IgnoreAllDamage) &&
            FinishingDamageFilterAllows(Target) &&
            !Target.HasGameplayTag(GameplayTag::State_UnKillable) &&
            !Target.HasGameplayTag(GameplayTag::State_Invulnerable);
    }

    int QueueFinisher(AActor Attacker, AActor Victim, bool ImmediateFinish = false)
    {
        auto Target = Cast<AGothicCharacter>(Victim);
        if (!Ready() || !IsValid(Target) || !IsValid(Target.CharacterState) ||
            Target.GetWorld() != GetWorld()) return 2;
        if (!Target.IsDefeated()) return 0;
        if (Attacker != Hero || !Finishable(Target)) return 2;
        for (int I = 0; I < VRFinishingPending.Num(); I++)
        {
            if (VRFinishingPending[I].Target == Target) return 2;
        }
        for (auto Pending : PendingDeathReports)
            if (Pending.Target == Target) return 2;
        if (VRFinishingPending.Num() + PendingDeathReports.Num() >= 4) return 2;
        FGothicVRFinishingHit Request;
        Request.Hero = Hero; Request.Target = Target;
        Request.ImmediateFinish = ImmediateFinish;
        VRFinishingPending.Add(Request);
        VRFinishingStatus = "queued";
        return 1;
    }

    void FinishTick(float Delta)
    {
        for (int I = VRFinishingPending.Num() - 1; I >= 0; I--)
        {
            // Copy before gameplay callbacks: never retain an array reference across GAS.
            FGothicVRFinishingHit P = VRFinishingPending[I];
            if (!Ready() || P.Hero != Hero || !Finishable(P.Target))
            {
                VRFinishingPending.RemoveAt(I); continue;
            }
            auto Carry = Hero.GetCarryComponent();
            if (!P.ImmediateFinish && (!IsValid(Carry) || Cast<UWeaponMeleeDefinition>(Carry.GetEquippedItemDefinition()) == nullptr))
            {
                VRFinishingPending.RemoveAt(I); continue;
            }
            P.Time += Delta;
            if (P.Phase == 0)
            {
                P.Phase = 1;
                VRFinishingPending[I] = P;
                if (!P.ImmediateFinish && P.Target.IsHuman() && !VRFinishingMontages.IsEmpty())
                {
                    P.Montage = VRFinishingMontages[VRFinishingNext % VRFinishingMontages.Num()];
                    VRFinishingNext += 1;
                    P.Duration = P.Target.PlayAnimMontage(P.Montage, 1.0f, n"None");
                    VRFinishingMontage = P.Montage.GetPathName();
                }
                VRFinishingStatus = "reaction_started";
            }
            if (P.ImmediateFinish || P.Time >= 0.65f)
            {
                VRFinishingPending.RemoveAt(I); // disarm before re-entrant game callbacks
                auto SourceASC = GothicGAS::GetAbilitySystemComponent(Hero);
                auto TargetASC = GothicGAS::GetAbilitySystemComponent(P.Target);
                if (!IsValid(SourceASC) || !IsValid(TargetASC)) continue;
                auto Combat = DataModule::GetCombatDataModule(P.Target);
                if (IsValid(Combat)) Combat.SetLastAttackerCharacter(Hero);
                auto Spec = SourceASC.MakeOutgoingSpec(UGameplayEffect_KillCharacter::StaticClass(), 0.0f, SourceASC.MakeEffectContext());
                TArray<AGothicCharacter> Witnesses;
                if (P.Target.IsHuman() && IsValid(Hero.Perception))
                {
                    for (auto Observer : Hero.Perception.GetAllPotentiallyReachableCharactersInRadiusSortedByDistance(2400.0f))
                    {
                        if (!IsValid(Observer) || Observer == Hero || Observer == P.Target ||
                            !IsValid(Observer.CharacterState) || Observer.GetWorld() != GetWorld() ||
                            Observer.IsDead() || Observer.IsDefeated() || !IsValid(Observer.Controller)) continue;
                        if (Observer.CharacterState.CanSeeCharacter(Hero.CharacterState) &&
                            Observer.CharacterState.CanSeeCharacter(P.Target.CharacterState) &&
                            Observer.Controller.LineOfSightTo(Hero) && Observer.Controller.LineOfSightTo(P.Target))
                            Witnesses.AddUnique(Observer);
                    }
                }
                P.Witnesses = Witnesses;
                P.Time = GetGameTimeSinceCreation() + 2.0f;
                PendingDeathReports.Add(P);
                WitnessRevision += 1;
                WitnessEligible = Witnesses.Num();
                WitnessDelivered = 0;
                WitnessOutcome = "awaiting_death";
                ExecutionXP = 0;
                ExecutionXPBefore = -1;
                ExecutionXPAfter = -1;
                ExecutionXPStatus = "awaiting_death";
                TargetASC.AddTag(GameplayTag::State_Dead);
                SourceASC.ApplyGameplayEffectSpecToTarget(Spec, TargetASC);
                if (!IsValid(P.Target) || P.Target.GetWorld() != GetWorld()) continue;
                auto FX = P.Target.GetFXComponent();
                if (IsValid(FX)) FX.PlayEffect(GameplayTag::FX_Death, nullptr);
                // Native death owns sound, montage and ragdoll. No forced montage replay.
                VRFinishingStatus = "finished";
                continue;
            }
            VRFinishingPending[I] = P;
        }
    }

    UPROPERTY() int ExecutionXP = 0;
    UPROPERTY() int ExecutionXPBefore = -1;
    UPROPERTY() int ExecutionXPAfter = -1;
    UPROPERTY() FString ExecutionXPStatus;

    void AwardExecutionBounty(AGothicCharacter Killer, AGothicCharacter Victim)
    {
        ExecutionXP = 0;
        ExecutionXPStatus = "unavailable";
        if (!Ready() || Killer != Hero || !IsValid(Victim) || Victim.GetWorld() != GetWorld() ||
            !Victim.IsDead() || !IsValid(Victim.CharacterState) || !IsValid(Killer.CharacterState)) return;
        auto VictimASC = Victim.GetGothicAbilitySystemComponent();
        if (!IsValid(VictimASC) || !IsValid(Killer.CharacterState.AbilitySystemComponent)) return;
        if (Victim.CharacterState.HasGameplayTag(GameplayTag::State_ExecutedBountyGranted))
        { ExecutionXPStatus = "already_granted"; return; }
        int Amount = int(Victim.CharacterState.GetXPExecutedBountyAttribute());
        if (Amount <= 0) { ExecutionXPStatus = "no_bounty"; return; }
        // Claim the separate execution bounty before GiveExperience can notify
        // listeners synchronously. The defeat bounty was handled by Gothic.
        VictimASC.AddTag(GameplayTag::State_ExecutedBountyGranted);
        ExecutionXP = Amount;
        ExecutionXPStatus = "awarded";
        ExecutionXPBefore = int(Killer.CharacterState.GetExperienceAttribute());
        Killer.CharacterState.GiveExperience(Amount);
        if (IsValid(Killer) && IsValid(Killer.CharacterState))
            ExecutionXPAfter = int(Killer.CharacterState.GetExperienceAttribute());
    }

    void ReportFinishingDeath(AGothicCharacter Killer, AGothicCharacter Victim, const TArray<AGothicCharacter>&in Witnesses)
    {
        AwardExecutionBounty(Killer, Victim);
        if (!Ready() || Killer != Hero || !IsValid(Victim) || Victim.GetWorld() != GetWorld() ||
            !IsValid(Victim.CharacterState) || !Victim.IsDead() || !Victim.IsHuman()) return;
        // Murder uses FromCriminal and a single global record per victim. A witness
        // can assess that record only after it exists, regardless of perception order.
        auto Crimes = Cast<UCrimeProcessingSubsystem_Human>(UCrimeProcessingSubsystem_Human::Get());
        int CrimeId = -1;
        if (IsValid(Crimes) && IsValid(UCrimeMemorySubsystem::Get(Killer.CharacterState)) &&
            IsValid(Crimes.GetCrimeDefinition(GameplayTag::Crime_Murder)))
        {
            auto Record = Crimes.MakeNewCrimeRegisterData(GameplayTag::Crime_Murder,
                Killer.CharacterState, nullptr, Victim.CharacterState);
            if (Record.bIsValid) CrimeId = Crimes.RegisterGlobalCrimeOnly(Record);
        }
        FRememberedPerception Event;
        Event.EventTag = GameplayTag::AIEvent_Sensed_OtherKilled;
        for (auto Observer : Witnesses)
        {
            if (!Ready() || Killer != Hero || !IsValid(Victim) || !IsValid(Victim.CharacterState) ||
                Victim.GetWorld() != GetWorld()) break;
            if (!IsValid(Observer) || !IsValid(Observer.CharacterState) || Observer.GetWorld() != GetWorld() ||
                Observer.IsDead() || Observer.IsDefeated()) continue;
            auto AI = Observer.GetCharacterAI();
            if (!IsValid(AI)) continue;
            Event.Sensing.Character = Observer;
            Event.Sensing.CharacterState = Observer.CharacterState;
            Event.Sensing.AtPosition = Observer.GetActorLocation();
            Event.Origin.Character = Victim;
            Event.Origin.CharacterState = Victim.CharacterState;
            Event.Origin.AtPosition = Victim.GetActorLocation();
            Event.Affected = Event.Origin;
            Event.Target = Event.Origin;
            Event.Instigator.Character = Killer;
            Event.Instigator.CharacterState = Killer.CharacterState;
            Event.Instigator.AtPosition = Killer.GetActorLocation();
            AI.AssessEvent(Event.EventTag, Event);
            WitnessDelivered += 1;
        }
        WitnessOutcome = CrimeId < 0 ? "crime_registration_failed" :
            (WitnessEligible == 0 ? "no_visible_witnesses" :
            (WitnessDelivered == WitnessEligible ? "assessed" : "witness_unavailable"));
    }

    void FinishWitnessTick()
    {
        if (PendingDeathReports.IsEmpty()) return;
        float Now = GetGameTimeSinceCreation();
        for (int I = PendingDeathReports.Num() - 1; I >= 0; I--)
        {
            if (!PendingDeathReports.IsValidIndex(I)) continue;
            auto P = PendingDeathReports[I];
            bool Valid = Ready() && Hero == P.Hero && IsValid(P.Target) &&
                P.Target.GetWorld() == GetWorld() && IsValid(P.Target.CharacterState);
            bool Dead = Valid && P.Target.IsDead();
            if (Valid && !Dead && Now < P.Time) continue;
            PendingDeathReports.RemoveAt(I);
            WitnessRevision += 1;
            WitnessEligible = P.Witnesses.Num();
            WitnessDelivered = 0;
            if (Dead) ReportFinishingDeath(P.Hero, P.Target, P.Witnesses);
            else WitnessOutcome = Valid ? "death_timeout" : "target_unavailable";
        }
    }

    UPhysicsHandleComponent Handle(int I) { return I == 0 ? LeftHandle : RightHandle; }
    // 220 crashed inside ApplyPhysicalAnimationSettingsBelow on a bridge guard.
    // Never create motors or rebuild bodies here. Gothic's Action_Ragdoll owns
    // transitions; we may only grab a body once native simulation is observed.
    FName SimulatedBone(USkeletalMeshComponent Mesh, FName Requested)
    {
        FName Bone = Requested;
        for (int I = 0; I < 24 && Mesh.GetBoneIndex(Bone) >= 0; I++)
        {
            if (Mesh.IsSimulatingPhysics(Bone)) return Bone;
            Bone = Mesh.GetParentBone(Bone);
        }
        return n"None";
    }

    void ReactToBodyContact(AGothicCharacter Target, FGothicVRBodyInput Input, float Pressure)
    {
        if (!Target.IsHuman() || Target.IsDead() || Target.IsDefeated() || Target.IsInConversation() ||
            Target.HasGameplayTag(GameplayTag::State_Ragdoll) ||
            Target.HasGameplayTag(GameplayTag::State_PartOfCinematic)) return;
        FVector Drive = Input.Grip ? Input.Goal - Input.Point : -Input.Normal * Pressure;
        // Pressing down on an off-centre shoulder of a bent-over NPC tilts the trunk.
        FVector Lever = Input.Point - Target.Mesh.GetSocketLocation(n"pelvis");
        Lever.Z = 0.0f;
        Drive += Lever.GetClampedToMaxSize(32.0f) * (-Drive.Z / 45.0f);
        Drive.Z = 0.0f;
        Drive = (Drive * StrengthScale * (Input.Grip ? 0.32f : 0.75f)).GetClampedToMaxSize(8.0f);
        int Index = -1;
        for (int I = 0; I < BodyReactions.Num(); I++)
            if (BodyReactions[I].Target == Target) { Index = I; break; }
        if (Index < 0)
        {
            if (Drive.Size() < 0.25f || BodyReactions.Num() >= 8) return;
            FGothicVRBodyReaction R;
            R.Target = Target; R.Mesh = Target.Mesh;
            Index = BodyReactions.Num(); BodyReactions.Add(R); BodyReactionCount += 1;
        }
        BodyReactions[Index].Desired += Drive;
        BodyReactions[Index].LastTouch = GetGameTimeSinceCreation();
    }

    UPROPERTY() UAnimMontage GetUpFront;
    UPROPERTY() UAnimMontage GetUpBack;
    bool RecoveryWarmed = false;

    void WarmRecovery()
    {
        if (RecoveryWarmed) return;
        RecoveryWarmed = true;
        FString Folder = "/Game/AnimLibrary/Humanoid/Man/Movement/Grounded/N/GetUp/";
        FString Front = "A_Man_N_GetUp_Front_Montage";
        FString Back = "A_Man_N_GetUp_Back_Montage";
        FSoftObjectPath F(Folder + Front + "." + Front), B(Folder + Back + "." + Back);
        GetUpFront = Cast<UAnimMontage>(F.TryLoad());
        GetUpBack = Cast<UAnimMontage>(B.TryLoad());
    }

    void RecoveryTick()
    {
        float Now = GetGameTimeSinceCreation();
        for (int I = LiveContacts.Num() - 1; I >= 0; I--)
        {
            auto C = LiveContacts[I];
            auto T = C.Target;
            if (Now - C.LastTouch > 12.0f || !Ready() || !IsValid(T) || T.IsActorBeingDestroyed() ||
                T.GetWorld()!=GetWorld() || !IsValid(T.Mesh) || !IsValid(T.CharacterState) || T.IsDead() || T.IsDefeated())
            { LiveContacts.RemoveAt(I); continue; }
            if (!C.RecoveryPending) continue;
            if (T.Mesh.IsSimulatingPhysics(n"pelvis"))
            {
                C.WasDown = true;
                FVector Right = T.Mesh.GetSocketLocation(n"clavicle_r") - T.Mesh.GetSocketLocation(n"clavicle_l");
                FVector Up = T.Mesh.GetSocketLocation(n"head") - T.Mesh.GetSocketLocation(n"pelvis");
                C.FaceUp = Right.CrossProduct(Up).Z >= 0.0f;
                LiveContacts[I] = C; continue;
            }
            if (!C.WasDown || T.HasGameplayTag(GameplayTag::State_Ragdoll)) continue;
            if (C.HasSafeCapsule) RestoreBuriedCapsule(T,C.SafeCapsule);
            LiveContacts[I].RecoveryPending = false;
            LiveContacts[I].RecoverUntil = Now + 1.0f;
            auto Anim = T.Mesh.GetAnimInstance();
            auto Montage = C.FaceUp ? GetUpBack : GetUpFront;
            float RecoveryGap;
            auto Movement = T.GetGothicMovementComponent();
            if (!IsValid(Anim) || !IsValid(Montage) || IsValid(T.GetCurrentMontage()) ||
                !IsValid(Movement) || !CapsuleFloor(T,Movement,T.GetActorLocation(),RecoveryGap) ||
                T.IsInConversation() || T.HasGameplayTag(GameplayTag::State_PartOfCinematic)) continue;
            float Length = Anim.Montage_Play(Montage, 1.0f, EMontagePlayReturnType::MontageLength, 0.0f, false);
            LiveContacts[I].RecoverUntil = Now + Math::Clamp(Length, 0.5f, 4.0f);
        }
    }

    void BodyLeanTick(float Delta)
    {
        float Now = GetGameTimeSinceCreation();
        for (int I = BodyReactions.Num() - 1; I >= 0; I--)
        {
            auto R = BodyReactions[I];
            if (!IsValid(R.Mesh) || !IsValid(R.Target) || !IsValid(R.Target.CharacterState) || R.Target.GetWorld() != GetWorld() || R.Target.Mesh != R.Mesh)
            { BodyReactions.RemoveAt(I); continue; }
            bool Physical = R.Target.IsDead() || R.Target.IsDefeated() ||
                R.Target.HasGameplayTag(GameplayTag::State_Ragdoll) || R.Mesh.IsSimulatingPhysics(n"pelvis");
            FRotator Current = R.Mesh.RelativeRotation;
            bool Own = R.Applied && Current.Equals(R.Written, 0.02f);
            if (!Own) R.Base = Current;
            bool Stop = Physical || !Ready() || R.Target.IsInConversation() ||
                R.Target.HasGameplayTag(GameplayTag::State_PartOfCinematic);
            if (Stop || (Now - R.LastTouch > 0.12f && R.Drive.Size() < 0.06f))
            {
                // The defeat tag can arrive before Chaos takes the pelvis.
                // Release our exact lean in that kinematic interval so Gothic
                // cannot capture a VR tilt as its recovery pose.
                if (Own && (!Physical || (!R.Target.IsDead() && !R.Mesh.IsSimulatingPhysics(n"pelvis") &&
                    !R.Target.HasGameplayTag(GameplayTag::State_Ragdoll) && R.Mesh.GetAttachParent()==R.Target.CapsuleComponent)))
                    R.Mesh.SetRelativeRotation(R.Base);
                BodyReactions.RemoveAt(I); continue;
            }
            // Hold across a missed sample. Apply a single offset per actor after both hands.
            if (R.Desired.Size() > 0.01f || Now - R.LastTouch > 0.12f)
                R.Drive += (R.Desired.GetClampedToMaxSize(8.0f) - R.Drive) * (1.0f - Math::Exp(-10.0f * Delta));
            R.Desired = FVector::ZeroVector;
            FRotator Next = R.Base;
            Next.Pitch -= R.Drive.DotProduct(R.Mesh.GetForwardVector());
            Next.Roll += R.Drive.DotProduct(R.Mesh.GetRightVector());
            R.Mesh.SetRelativeRotation(Next);
            R.Written = R.Mesh.RelativeRotation; R.Applied = true;
            BodyReactions[I] = R;
            BodyReactionStatus = "continuous_lean";
        }
    }

    UPROPERTY() TArray<FVRLandingObservation> LandingActors;
    float NextLandingScan = 0.0f;
    UPROPERTY() int BodyLandingObserved = 0;
    UPROPERTY() int BodyLandingReleased = 0;
    UPROPERTY() FString LastBodyLanding = "idle";
    UPROPERTY() FName LastBodyLandingBone;

    bool LandingSurface(AGothicCharacter T,FVector From,FVector To,FVector&out Normal)
    {
        TArray<EObjectTypeQuery> Types;
        Types.Add(EObjectTypeQuery::WorldStatic); Types.Add(EObjectTypeQuery::WorldDynamic);
        Types.Add(UCollisionProfile::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
        TArray<AActor> Ignore; Ignore.Add(T); Ignore.Add(Hero);
        TArray<FHitResult> Hits;
        System::SphereTraceMultiForObjects(From,To,2.5f,Types,false,Ignore,EDrawDebugTrace::None,Hits,true);
        for (auto Hit : Hits)
        {
            auto Comp=Hit.Component;
            if (!IsValid(Comp) || IsValid(Cast<AGothicCharacter>(Comp.GetOwner())) ||
                (int(Comp.GetCollisionEnabled())!=2 && int(Comp.GetCollisionEnabled())!=3) ||
                Comp.GetCollisionResponseToChannel(T.Mesh.GetCollisionObjectType())!=ECollisionResponse::ECR_Block ||
                T.Mesh.GetCollisionResponseToChannel(Comp.GetCollisionObjectType())!=ECollisionResponse::ECR_Block) continue;
            Normal=Hit.Normal.GetSafeNormal();
            if (Normal.SizeSquared()>0.9f) return true;
        }
        return false;
    }

    void LandingTick()
    {
        float Now=GetGameTimeSinceCreation();
        if (Now>=NextLandingScan)
        {
            NextLandingScan=Now+0.35f;
            TArray<EObjectTypeQuery> Types; Types.Add(EObjectTypeQuery::Pawn);
            Types.Add(UCollisionProfile::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
            TArray<AActor> Ignore; Ignore.Add(Hero);
            TArray<AActor> Nearby;
            System::SphereOverlapActors(Hero.GetActorLocation(),550.0f,Types,AGothicCharacter::StaticClass(),Ignore,Nearby);
            for (auto Actor : Nearby)
            {
                auto T=Cast<AGothicCharacter>(Actor);
                if (!IsValid(T) || T.IsActorBeingDestroyed() || T==Hero || !IsValid(T.Mesh) || !IsValid(T.CharacterState)) continue;
                int Slot=-1;
                for (int J=0; J<LandingActors.Num(); J++) if (LandingActors[J].Target==T) { Slot=J; break; }
                if (Slot<0)
                {
                    if (LandingActors.Num()>=16)
                    {
                        if (T.IsDead()) continue;
                        for (int J=0; J<LandingActors.Num(); J++)
                            if (LandingActors[J].State==2 && Now>=LandingActors[J].Until)
                            { LandingActors.RemoveAt(J); break; }
                        if (LandingActors.Num()>=16) continue;
                    }
                    FVRLandingObservation W; W.Target=T;
                    Slot=LandingActors.Num(); LandingActors.Add(W);
                }
                LandingActors[Slot].Seen=Now;
            }
        }
        for (int I=LandingActors.Num()-1; I>=0; I--)
        {
            if (Now<LandingActors[I].NextSample) continue;
            auto T=LandingActors[I].Target;
            if (!IsValid(T) || T.IsActorBeingDestroyed() || !IsValid(T.Mesh) || !IsValid(T.CharacterState) || T.GetWorld()!=GetWorld() ||
                (Now-LandingActors[I].Seen>2.5f && Now>LandingActors[I].Until))
            { LandingActors.RemoveAt(I); continue; }
            LandingActors[I].NextSample=Now+(Now<LandingActors[I].Until?0.08f:0.24f);
            int State=T.IsDead()?2:(T.IsDefeated() || T.HasGameplayTag(GameplayTag::State_Ragdoll)?1:0);
            auto Mesh=T.Mesh;
            if (State!=LandingActors[I].State)
            {
                int Previous=LandingActors[I].State;
                LandingActors[I].State=State;
                LandingActors[I].Until=0.0f;
                if (State==0) continue;
                FName Driver=n"pelvis";
                if (Mesh.GetBoneIndex(Driver)<0)
                {
                    FVector P,N; float32 Distance;
                    if (!Mesh.GetClosestPointOnPhysicsAsset(T.GetActorLocation(),P,N,Driver,Distance)) continue;
                }
                if (Previous<0 && (!Mesh.IsSimulatingPhysics(Driver) || Mesh.GetPhysicsLinearVelocity(Driver).SizeSquared()<30.0f*30.0f)) continue;
                LandingActors[I].Driver=Driver;
                LandingActors[I].Until=Now+2.0f;
                LandingActors[I].NextSample=Now+0.06f;
                LandingActors[I].Releases=0;
                LandingActors[I].MomentumUntil=0.0f;
                LandingActors[I].Limbs.Empty();
                TArray<FName> Candidates;
                Candidates.Add(n"hand_l"); Candidates.Add(n"hand_r"); Candidates.Add(n"foot_l"); Candidates.Add(n"foot_r");
                Candidates.Add(n"lowerarm_l"); Candidates.Add(n"lowerarm_r"); Candidates.Add(n"calf_l"); Candidates.Add(n"calf_r");
                Candidates.Add(n"head"); Candidates.Add(n"upperarm_l"); Candidates.Add(n"upperarm_r");
                Candidates.Add(n"thigh_l"); Candidates.Add(n"thigh_r");
                for (auto B : Candidates)
                    if (Mesh.GetBoneIndex(B)>=0) LandingActors[I].Limbs.Add(B);
                LandingActors[I].Span.Empty(); LandingActors[I].Lag.Empty();
                LandingActors[I].ParentSpan.Empty(); LandingActors[I].ParentSpan.SetNum(LandingActors[I].Limbs.Num());
                LandingActors[I].Span.SetNum(LandingActors[I].Limbs.Num()); LandingActors[I].Lag.SetNum(LandingActors[I].Limbs.Num());
                LastBodyLanding=State==2?"death_observed":"fall_observed"; BodyLandingObserved++;
            }
            if (Now>=LandingActors[I].Until || LandingActors[I].Releases>=4 || State==0 || !Mesh.IsSimulatingPhysics(LandingActors[I].Driver) ||
                T.IsInConversation() || T.HasGameplayTag(GameplayTag::State_PartOfCinematic)) continue;
            if (Held.Contains(T)) { LandingActors[I].Until=0.0f; continue; }
            FVector Hip=Mesh.GetCenterOfMass(LandingActors[I].Driver);
            FVector DriverVelocity=Mesh.GetPhysicsLinearVelocity(LandingActors[I].Driver);
            if (DriverVelocity.SizeSquared()>18.0f*18.0f)
            { LandingActors[I].RecentVelocity=DriverVelocity; LandingActors[I].MomentumUntil=Now+0.22f; }
            for (int J=0; J<LandingActors[I].Limbs.Num() && LandingActors[I].Releases<4; J++)
            {
                FName B=LandingActors[I].Limbs[J];
                if (LandingActors[I].Lag[J]<0 || !Mesh.IsSimulatingPhysics(B)) continue;
                FVector Point=Mesh.GetCenterOfMass(B);
                FVector Reach=Hip-Point;
                float Previous=LandingActors[I].Span[J];
                float Dist=float(Reach.Size());
                LandingActors[I].Span[J]=Dist;
                FVector LimbV=Mesh.GetPhysicsLinearVelocity(B);
                // A grounded pelvis can support the torso while the adjacent
                // forearm or shin is still drawing a planted extremity away.
                FName Parent=Mesh.GetParentBone(B);
                bool LoadedJoint=false;
                FVector JointMotion=FVector::ZeroVector;
                if (Parent!=n"None" && Parent!=LandingActors[I].Driver && Mesh.IsSimulatingPhysics(Parent))
                {
                    FVector Link=Mesh.GetCenterOfMass(Parent)-Point;
                    float Was=LandingActors[I].ParentSpan[J];
                    LandingActors[I].ParentSpan[J]=float(Link.Size());
                    JointMotion=Mesh.GetPhysicsLinearVelocity(Parent);
                    LoadedJoint=Was>3.0f && Link.Size()-Was>0.45f && JointMotion.DotProduct(Link.GetSafeNormal())>18.0f;
                }
                // A torso may stop on an edge a sample before a planted hand
                // releases. Require prior observed extension on that same limb.
                bool Residual=LandingActors[I].Lag[J]>0 && Now<LandingActors[I].MomentumUntil &&
                    DriverVelocity.SizeSquared()<12.0f*12.0f && Dist>=Previous-0.15f;
                FVector Motion=LoadedJoint?JointMotion:(Residual?LandingActors[I].RecentVelocity:DriverVelocity);
                if (Previous<=0.0f || Dist<15.0f || LimbV.SizeSquared()>8.0f*8.0f ||
                    (!LoadedJoint && ((!Residual && Dist-Previous<0.5f) || Motion.DotProduct(Reach.GetSafeNormal())<18.0f)))
                { LandingActors[I].Lag[J]=0; continue; }
                LandingActors[I].Lag[J]+=1;
                if (LandingActors[I].Lag[J]<2) continue;
                FVector Normal;
                if (!LandingSurface(T,Point,Point-FVector(0,0,10.0f),Normal) &&
                    !LandingSurface(T,Point,Point-Reach.GetSafeNormal()*10.0f,Normal) &&
                    !LandingSurface(T,Point,Point+FVector(10,0,0),Normal) &&
                    !LandingSurface(T,Point,Point-FVector(10,0,0),Normal) &&
                    !LandingSurface(T,Point,Point+FVector(0,10,0),Normal) &&
                    !LandingSurface(T,Point,Point-FVector(0,10,0),Normal)) continue;
                FVector Free=Motion-Normal*Math::Min(0.0f,Motion.DotProduct(Normal));
                FVector Step=(Free-LimbV).GetClampedToMaxSize(40.0f);
                Step-=Normal*Math::Min(0.0f,Step.DotProduct(Normal));
                if (Step.SizeSquared()<6.0f*6.0f) continue;
                LandingActors[I].Lag[J]=-1;
                LandingActors[I].Releases+=1;
                Mesh.WakeRigidBody(B);
                Mesh.SetPhysicsLinearVelocity(Step,true,B);
                BodyLandingReleased++; LastBodyLandingBone=B;
                LastBodyLanding=State==2?"death_limb_released":"downed_limb_released";
            }
        }
    }

    void WakeCorpseContact(AGothicCharacter Target, FName ContactBone)
    {
        // Only a confirmed corpse, in an engine-owned Tick. Let Gothic own the
        // skeleton and its death state; never rebuild constraints or force a mesh
        // into simulation. Action_Ragdoll is the game's own restart event.
        if (!Target.IsDead() || !IsValid(Target.Mesh) || Target.IsPlayerControlled()) return;
        auto Mesh = Target.Mesh;
        float Now = GetGameTimeSinceCreation();
        int Index = -1;
        for (int I = 0; I < CorpseContacts.Num(); I++)
            if (CorpseContacts[I].Target == Target) { Index = I; break; }
        if (Index < 0)
        {
            if (CorpseContacts.Num() >= 8) CorpseContacts.RemoveAt(0);
            FGothicVRCorpseContact Entry; Entry.Target = Target;
            Index = CorpseContacts.Num(); CorpseContacts.Add(Entry);
        }
        auto C = CorpseContacts[Index];
        C.LastTouch = Now;
        CorpseTarget = Target.GetPathName();
        // Hair/secondary bodies can remain simulated after the actual corpse
        // froze. Test the contacted chain, not merely IsAnySimulatingPhysics.
        CorpseSimulating = SimulatedBone(Mesh, ContactBone) != n"None";
        CorpseAnySimulation = Mesh.IsAnySimulatingPhysics();
        CorpseAwake = Mesh.IsAnyRigidBodyAwake();
        CorpseCollision = int(Mesh.GetCollisionEnabled());
        CorpseRagdollTag = Target.HasGameplayTag(GameplayTag::State_Ragdoll);
        if (CorpseSimulating)
        {
            if (!C.ObservedSimulation && C.NextRagdoll > 0.0f) CorpseResumeCount += 1;
            C.ObservedSimulation = true;
            if (Now >= C.NextWake)
            {
                C.NextWake = Now + 0.25f;
                Mesh.WakeAllRigidBodies();
                CorpseWakeRequests += 1;
            }
            CorpseStatus = "native_body_active";
        }
        else if (Now >= C.NextRagdoll)
        {
            C.ObservedSimulation = false;
            C.NextRagdoll = Now + 2.0f;
            CorpseContacts[Index] = C;
            FGameplayEventData Event;
            GothicGAS::AddTargetRagdollData(Event, 3.0f);
            GothicGAS::SendGameplayEvent(Target, GameplayTag::Action_Ragdoll, Event);
            CorpseRagdollRequests += 1;
            CorpseStatus = "native_ragdoll_requested";
            // Observe on the next frame. Sending an event is not confirmation.
            return;
        }
        else CorpseStatus = "waiting_for_native_ragdoll";
        CorpseContacts[Index] = C;
    }

    FName ArmRoot(USkeletalMeshComponent Mesh, FName ContactBone)
    {
        FName Bone = ContactBone;
        for (int Depth = 0; Depth < 16 && Mesh.GetBoneIndex(Bone) >= 0; Depth++)
        {
            if (Bone == n"upperarm_l" || Bone == n"upperarm_r") return Bone;
            Bone = Mesh.GetParentBone(Bone);
        }
        return n"None";
    }

    void EndArm(int I, bool Restore)
    {
        auto Arm = ArmDrives[I];
        FGothicVRArmDrive Empty;
        ArmDrives[I] = Empty;
        if (GripModes[I] == 2 && Held[I] == Arm.Target) ReleaseHand(I);
        if (Restore && IsValid(Arm.Mesh))
        {
            Arm.Mesh.SetAllBodiesBelowPhysicsBlendWeight(Arm.Root, 0.0f, false, true);
            Arm.Mesh.SetAllBodiesBelowSimulatePhysics(Arm.Root, false, true);
        }
    }

    void ArmTick(float Delta)
    {
        float Now = GetGameTimeSinceCreation();
        for (int I = 0; I < ArmDrives.Num(); I++)
        {
            auto Arm = ArmDrives[I];
            if (!IsValid(Arm.Mesh)) continue;
            bool Native = !IsValid(Arm.Target) || !IsValid(Arm.Target.CharacterState) ||
                Arm.Target.GetWorld() != GetWorld() || Arm.Target.Mesh != Arm.Mesh || Arm.Target.IsDead() ||
                Arm.Target.IsDefeated() || Arm.Target.HasGameplayTag(GameplayTag::State_Ragdoll) || Arm.Mesh.IsSimulatingPhysics(n"pelvis");
            if (Native) { EndArm(I, false); continue; }
            bool Active = Ready() && Hands[I].Target == Arm.Target && Hands[I].Grip && Now - Hands[I].Time < 0.15f &&
                Now - Arm.LastTouch < 0.15f;
            float Want = Active ? 0.85f : 0.0f;
            float Weight = Arm.Weight + (Want - Arm.Weight) * (1.0f - Math::Exp(-12.0f * Delta));
            if (!Active && Weight < 0.025f) { EndArm(I, true); continue; }
            Arm.Mesh.SetAllBodiesBelowPhysicsBlendWeight(Arm.Root, Weight, false, true);
            ArmDrives[I].Weight = Weight;
        }
    }

    UPROPERTY() FString ArmGripStatus = "idle";
    UPROPERTY() FName ArmGripBone;
    UPROPERTY() int ArmGripStarts = 0;
    bool DriveArm(int I, FGothicVRBodyInput Input)
    {
        auto Target = Input.Target;
        if (!Input.Grip || !Target.IsHuman() || Target.IsDead() || Target.IsDefeated() || Target.IsInConversation() ||
            Target.HasGameplayTag(GameplayTag::State_Ragdoll) || Target.HasGameplayTag(GameplayTag::State_PartOfCinematic)) return false;
        auto Mesh = Target.Mesh;
        ArmGripBone = Input.Bone;
        FName RootBone = ArmRoot(Mesh, Input.Bone);
        if (RootBone == n"None") { ArmGripStatus = "outside_arm"; return false; }
        if (ArmDrives[I].Mesh == Mesh && ArmDrives[I].Root == RootBone)
        { ArmDrives[I].LastTouch = GetGameTimeSinceCreation(); return true; }
        if (IsValid(ArmDrives[I].Mesh) || (ArmDrives[1-I].Mesh == Mesh && ArmDrives[1-I].Root == RootBone)) return false;
        if (Mesh.IsSimulatingPhysics(n"pelvis") ||
            !(int(Mesh.GetCollisionEnabled()) == 2 || int(Mesh.GetCollisionEnabled()) == 3)) { ArmGripStatus = "mesh_collision_or_pelvis"; return false; }
        FVector Closest, Normal;
        FName ClosestBone;
        float32 Distance = 0.0f;
        if (!Mesh.GetClosestPointOnPhysicsAsset(Input.Point, Closest, Normal, ClosestBone, Distance)) { ArmGripStatus = "no_physics_surface"; return false; }
        // Only claim an entirely kinematic arm. The shoulder stays attached to the animated chest.
        for (int J = Mesh.GetBoneIndex(RootBone); J < Mesh.GetNumBones(); J++)
        {
            FName Bone = Mesh.GetBoneName(J);
            if (Mesh.IsSimulatingPhysics(Bone) && ArmRoot(Mesh, Bone) == RootBone) return false;
        }
        Mesh.SetAllBodiesBelowSimulatePhysics(RootBone, true, true);
        Mesh.SetAllBodiesBelowPhysicsBlendWeight(RootBone, 0.0f, false, true);
        ArmDrives[I].Target = Target; ArmDrives[I].Mesh = Mesh; ArmDrives[I].Root = RootBone;
        ArmDrives[I].StartAnchor = Input.Point - Target.GetActorLocation();
        ArmDrives[I].LastTouch = GetGameTimeSinceCreation();
        if (SimulatedBone(Mesh, Input.Bone) == n"None") { ArmGripStatus = "no_simulated_arm"; EndArm(I, true); GripRetry[I] = GetGameTimeSinceCreation() + 0.6f; return false; }
        ArmGripStarts += 1; ArmGripStatus = "arm_started";
        return true;
    }

    bool LiveContactRagdoll(AGothicCharacter Target, FGothicVRBodyInput Input, float Pressure, int Hand)
    {
        // Full native knockdown for a deliberate pull/shove. This is not a
        // balanced physical-animation puppet: the NPC can fall and get up.
        // Never touch the unsafe PhysicalAnimationComponent path from 220.
        if (!Target.IsHuman() || Target.IsDead() || Target.IsDefeated() ||
            Target.IsInConversation() || Target.IsClimbingLadderOrWall() ||
            Target.IsSwimming() || Target.IsDiving() ||
            Target.HasGameplayTag(GameplayTag::State_PartOfCinematic) ||
            Target.HasGameplayTag(GameplayTag::State_UnKillable) ||
            Target.HasGameplayTag(GameplayTag::State_Invulnerable)) return false;
        float Now = GetGameTimeSinceCreation();
        int Index = -1;
        for (int I = 0; I < LiveContacts.Num(); I++)
            if (LiveContacts[I].Target == Target) { Index = I; break; }
        bool Physical = SimulatedBone(Target.Mesh, Input.Bone) != n"None";
        bool DrivenArm = ArmDrives[Hand].Target == Target && ArmDrives[Hand].Root == ArmRoot(Target.Mesh, Input.Bone);
        if (Physical && !DrivenArm)
        {
            if (Index >= 0 && !LiveContacts[Index].ObservedSimulation)
            {
                LiveContacts[Index].ObservedSimulation = true;
                LiveRagdollResumes += 1;
            }
            LiveRagdollStatus = "native_body_active";
            return true;
        }
        float Approach = Math::Max(0.0f, -Input.Velocity.DotProduct(Input.Normal));
        FVector Pull = Input.Goal - Input.Point;
        if (DrivenArm) Pull = Input.Goal - Target.GetActorLocation() - ArmDrives[Hand].StartAnchor;
        float PullSpeed = Input.Velocity.DotProduct(Pull.GetSafeNormal());
        // Count inward travel from distinct controller samples on the same NPC.
        auto Prev = PushSamples[Hand];
        float Gap = Input.Time - Prev.Time;
        bool Fast = !Input.Grip && Approach >= 200.0f && Approach * StrengthScale >= 315.0f;
        if (!Fast || Prev.Target != Target || Prev.Grip || Gap > 0.065f) PushTravel[Hand] = 0.0f;
        else if (Gap > 0.0001f)
        {
            float Step = -(Input.Goal - Prev.Goal).DotProduct(Input.Normal);
            if (Step <= 0.0f || Step > 28.0f) PushTravel[Hand] = 0.0f;
            else PushTravel[Hand] += Math::Min(Step, 5.0f);
        }
        PushSamples[Hand] = Input;
        bool Strong = Input.Grip ? (Pull.Size() >= 38.0f && PullSpeed >= 155.0f && PullSpeed * StrengthScale >= 240.0f) :
            (Fast && Pressure >= 7.0f && PushTravel[Hand] >= 7.0f);
        if (Index >= 0 && Now < LiveContacts[Index].NextRagdoll)
        {
            LiveRagdollStatus = "awaiting_native_body";
            return true; // never compete with native knockdown using capsule motion
        }
        if (Target.HasGameplayTag(GameplayTag::State_Ragdoll)) return true;
        if (!Strong) return false;
        if (!Input.Grip && Hero.CharacterState.GetStrengthAttribute(10.0f) <= Target.CharacterState.GetStrengthAttribute(10.0f))
            return false;
        auto Movement = Target.GetGothicMovementComponent();
        if (!Target.IsSitting() && !Target.HasGameplayTag(GameplayTag::State_Ragdoll) &&
            (!IsValid(Movement) || !CanDisplaceBody(Target, Movement,true))) return false;
        if (Index < 0)
        {
            if (LiveContacts.Num() >= 8) LiveContacts.RemoveAt(0);
            FGothicVRCorpseContact Entry; Entry.Target = Target;
            Index = LiveContacts.Num(); LiveContacts.Add(Entry);
        }
        LiveContacts[Index].LastTouch = Now;
        LiveContacts[Index].NextRagdoll = Now + 2.0f;
        LiveContacts[Index].ObservedSimulation = false;
        LiveContacts[Index].SafeCapsule = Target.GetActorLocation();
        float FloorGap;
        LiveContacts[Index].HasSafeCapsule = IsValid(Movement) && CapsuleFloor(Target,Movement,Target.GetActorLocation(),FloorGap);
        LiveContacts[Index].RecoveryPending = true; LiveContacts[Index].WasDown = false;
        for (int I = 0; I < BodyMotions.Num(); I++)
            if (BodyMotions[I].Target == Target) ClearBodyMotion(I);
        for (int J = 0; J < ArmDrives.Num(); J++)
            if (ArmDrives[J].Target == Target) EndArm(J, true);
        LiveRagdollTarget = Target.GetPathName();
        LiveRagdollStatus = "native_ragdoll_requested";
        LiveRagdollRequests += 1;
        FGameplayEventData Event;
        GothicGAS::AddTargetRagdollData(Event, 3.0f);
        GothicGAS::SendGameplayEvent(Target, GameplayTag::Action_Ragdoll, Event);
        return true;
    }

    UFUNCTION(BlueprintCallable)
    bool IsBodyGripActive(int Hand, AActor Target) const
    {
        return Hand >= 0 && Hand < Held.Num() && Ready() && Held[Hand] == Target &&
            GripModes[Hand] > 0 && GetGameTimeSinceCreation() - GripTime[Hand] < 0.15f;
    }

    void ReleaseHand(int I)
    {
        if (GripModes[I] == 2) Handle(I).ReleaseComponent();
        Held[I] = nullptr;
        GripModes[I] = 0;
    }

    void ClearBodyMotion(int I)
    {
        for (int Hand = 0; Hand < Held.Num(); Hand++)
        {
            if (GripModes[Hand] == 1 && Held[Hand] == BodyMotions[I].Target) ReleaseHand(Hand);
        }
        if (IsValid(BodyMotions[I].Movement)) RemoveTickPrerequisiteComponent(BodyMotions[I].Movement);
        FGothicVRBodyMotion Empty;
        BodyMotions[I] = Empty;
    }

    UPROPERTY() int BodyRootMotionSkips = 0;
    UPROPERTY() int BodyUnsafeSteps = 0;
    UPROPERTY() int BodyFloorRecoveries = 0;
    UPROPERTY() int BodyGetupWatches = 0;
    UPROPERTY() int BodyGetupMoves = 0;
    UPROPERTY() FString LastBodyGetup = "idle";
    UPROPERTY() FString LastBodyGetupTarget;
    UPROPERTY() FVector LastBodyGetupAnchor;
    UPROPERTY() FVector LastBodyGetupRoot;
    UPROPERTY() FVector LastBodyGetupHip;
    UPROPERTY() TArray<FGothicVRGetupWatch> GetupWatches;

    bool CapsuleFloor(AGothicCharacter T, UGothicMovementComponent M, FVector At, float&out Gap)
    {
        Gap = -1000.0f;
        auto Cap = T.CapsuleComponent;
        if (!IsValid(Cap) || M.UpdatedComponent!=Cap || T.RootComponent!=Cap ||
            (int(Cap.GetCollisionEnabled())!=1 && int(Cap.GetCollisionEnabled())!=3) ||
            Cap.GetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic)!=ECollisionResponse::ECR_Block) return false;
        FFindFloorResult Floor;
        M.FindFloor(At,Floor);
        Gap = Floor.bLineTrace ? Floor.LineDist : Floor.FloorDist;
        return Floor.bBlockingHit && Floor.bWalkableFloor && !Floor.HitResult.bStartPenetrating && Gap>=-1.0f && Gap<=8.0f;
    }

    bool CapsulePathClear(AGothicCharacter T,FVector Start,FVector End,bool IncludePawns=false)
    {
        TArray<EObjectTypeQuery> Types;
        Types.Add(EObjectTypeQuery::WorldStatic); Types.Add(EObjectTypeQuery::WorldDynamic);
        if (IncludePawns) Types.Add(EObjectTypeQuery::Pawn);
        TArray<AActor> Ignore; Ignore.Add(T);
        auto Cap=T.CapsuleComponent;
        FHitResult Hit;
        // Clearance for ground skin and uneven floors. The actual move still sweeps the full capsule.
        return !System::CapsuleTraceSingleForObjects(Start,End,Cap.GetScaledCapsuleRadius(),
            Math::Max(float(Cap.GetScaledCapsuleRadius()),float(Cap.GetScaledCapsuleHalfHeight())-1.0f),
            Types,false,Ignore,EDrawDebugTrace::None,Hit,true);
    }

    bool SupportedBodyStep(AGothicCharacter T,UGothicMovementComponent M,FVector& Step)
    {
        FVector Start=T.GetActorLocation();
        float A,B;
        if (!CapsuleFloor(T,M,Start,A) || !CapsuleFloor(T,M,Start+Step,B) || Math::Abs(A-B)>4.0f)
        { BodyUnsafeSteps+=1; return false; }
        Step.Z += A-B;
        if (!CapsulePathClear(T,Start,Start+Step))
        { BodyUnsafeSteps+=1; return false; }
        return true;
    }

    bool HipFloorCenter(AGothicCharacter T,FVector Hip,FVector&out Center,bool ForSimulation=false)
    {
        TArray<EObjectTypeQuery> Types; Types.Add(EObjectTypeQuery::WorldStatic); Types.Add(EObjectTypeQuery::WorldDynamic);
        Types.Add(UCollisionProfile::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
        TArray<AActor> Ignore; Ignore.Add(T); Ignore.Add(Hero);
        TArray<FHitResult> Hits;
        System::LineTraceMultiForObjects(Hip+FVector(0,0,10),Hip-FVector(0,0,95),Types,false,Ignore,EDrawDebugTrace::None,Hits,true);
        float Best=-1000000000.0f;
        for (auto Hit : Hits)
        {
            auto Ground=Hit.Component;
            if (!IsValid(Ground) || Hit.bStartPenetrating || Hit.ImpactNormal.Z<(ForSimulation?0.2f:0.65f) ||
                (int(Ground.GetCollisionEnabled())!=2 && int(Ground.GetCollisionEnabled())!=3) ||
                Hit.ImpactPoint.Z>Hip.Z+1.0f ||
                (!ForSimulation && Ground.GetCollisionResponseToChannel(T.CapsuleComponent.GetCollisionObjectType())!=ECollisionResponse::ECR_Block) ||
                Ground.GetCollisionResponseToChannel(T.Mesh.GetCollisionObjectType())!=ECollisionResponse::ECR_Block ||
                T.Mesh.GetCollisionResponseToChannel(Ground.GetCollisionObjectType())!=ECollisionResponse::ECR_Block ||
                Hit.ImpactPoint.Z<=Best) continue;
            Best=Hit.ImpactPoint.Z;
            float Radius=T.CapsuleComponent.GetScaledCapsuleRadius();
            Center=Hit.ImpactPoint+FVector(0,0,T.CapsuleComponent.GetScaledCapsuleHalfHeight()+Radius*(1.0f/Hit.ImpactNormal.Z-1.0f)+2.0f);
        }
        return Best>-1000000000.0f;
    }

    UPROPERTY() int BodyGetupAlignments = 0;
    UPROPERTY() int DownedSupportMisses = 0;
    UPROPERTY() int DownedPlaneCorrections = 0;
    UPROPERTY() int DownedGripRemaps = 0;
    UPROPERTY() int DownedRestReleases = 0;
    UPROPERTY() float LastGetupFootGap = -1.0f;
    UPROPERTY() float LastGetupMeshOffset = -1.0f;

    void RegisterBodyGetup(FGothicVRDownedBody P)
    {
        if (!Ready() || !IsValid(P.Target.CapsuleComponent) || P.Target.IsDead()) return;
        int Slot=-1;
        for (int J=0; J<GetupWatches.Num(); J++)
            if (GetupWatches[J].Target==P.Target && GetupWatches[J].Mesh==P.Mesh) { Slot=J; break; }
        if (Slot<0)
        {
            if (GetupWatches.Num()>=12) return;
            FGothicVRGetupWatch W;
            W.Target=P.Target; W.Mesh=P.Mesh;
            W.Anchor=P.Target.CapsuleComponent.GetWorldLocation();
            W.HalfHeight=P.Target.CapsuleComponent.GetScaledCapsuleHalfHeight();
            Slot=GetupWatches.Num(); GetupWatches.Add(W); BodyGetupWatches+=1;
            LastBodyGetup="downed_contact"; LastBodyGetupTarget=P.Target.GetPathName();
        }
        if (P.HasSafeCapsule)
        {
            GetupWatches[Slot].Anchor=P.SafeCapsule; GetupWatches[Slot].HalfHeight=P.AnchorHalfHeight;
            GetupWatches[Slot].Entry=P.EntryCapsule; GetupWatches[Slot].EntryHalfHeight=P.EntryHalfHeight;
        }
    }

    void AlignStandingBody(AGothicCharacter T,UGothicMovementComponent M,int Slot)
    {
        auto Mesh=T.Mesh; auto Cap=T.CapsuleComponent;
        bool Falling=M.MovementMode==EMovementMode::MOVE_Falling;
        if ((!M.IsMovingOnGround() && !Falling) || (T.IsPlayingRootMotion() && (Falling || M.Velocity.SizeSquared()>9.0f)) || T.IsSitting() ||
            T.CharacterState.IsDoingAnyInteraction() || Mesh.GetAttachParent()!=Cap)
        { GetupWatches[Slot].HoverStart=-1.0f; return; }
        auto Clip=T.GetCurrentMontage();
        if (IsValid(Clip) && (Clip.GetName().ToString().Contains("GetUp") || Clip.GetName().ToString().Contains("Defeated")))
        { GetupWatches[Slot].HoverStart=-1.0f; return; }
        FVector Center=Cap.GetWorldLocation();
        if (Falling)
        {
            if (GetupWatches[Slot].HoverSettled || !M.IsComponentTickEnabled() || T.IsJumpProvidingForce() ||
                T.IsSwimming() || T.IsDiving() || T.IsClimbingLadderOrWall() || M.Velocity.SizeSquared()>4.0f)
            { GetupWatches[Slot].HoverStart=-1.0f; return; }
            float Now=GetGameTimeSinceCreation();
            if (GetupWatches[Slot].HoverStart<0.0f || (Center-GetupWatches[Slot].HoverOrigin).SizeSquared()>1.0f)
            { GetupWatches[Slot].HoverStart=Now; GetupWatches[Slot].HoverOrigin=Center; return; }
            if (Now-GetupWatches[Slot].HoverStart<0.75f) return;
        }
        else GetupWatches[Slot].HoverStart=-1.0f;
        GetupWatches[Slot].StandingSamples+=1;
        if (GetupWatches[Slot].StandingSamples<2) return;
        float Half=Cap.GetScaledCapsuleHalfHeight();
        TArray<EObjectTypeQuery> Types; Types.Add(EObjectTypeQuery::WorldStatic); Types.Add(EObjectTypeQuery::WorldDynamic);
        TArray<AActor> Ignore; Ignore.Add(T); Ignore.Add(Hero);
        TArray<FHitResult> Hits;
        System::LineTraceMultiForObjects(Center,Center-FVector(0,0,Half+110.0f),Types,false,Ignore,EDrawDebugTrace::None,Hits,true);
        for (auto Hit : Hits)
        {
            auto Ground=Hit.Component;
            if (!IsValid(Ground) || Hit.bStartPenetrating || Hit.ImpactNormal.Z<0.2f ||
                Ground.GetCollisionResponseToChannel(Cap.GetCollisionObjectType())!=ECollisionResponse::ECR_Block ||
                Cap.GetCollisionResponseToChannel(Ground.GetCollisionObjectType())!=ECollisionResponse::ECR_Block) continue;
            float WantZ=Hit.ImpactPoint.Z+Half+Cap.GetScaledCapsuleRadius()*(1.0f/Hit.ImpactNormal.Z-1.0f)+2.0f;
            float Gap=float(Center.Z-WantZ);
            LastGetupFootGap=Gap;
            if (Falling)
            {
                if (Gap<6.0f || Gap>80.0f || !CapsulePathClear(T,Center,Center-FVector(0,0,Gap-0.1f))) return;
                FHitResult Stop;
                GetupWatches[Slot].HoverSettled=true;
                M.MoveUpdatedComponent(FVector(0,0,-Gap),T.GetActorRotation(),Stop,true,false);
                M.bForceNextFloorCheck=true;
                LastBodyGetup=Stop.bStartPenetrating?"hover_step_blocked":"hover_step_swept";
                return;
            }
            FRotator Upright=T.GetActorRotation();
            bool Tilt=Math::Abs(Upright.Pitch)>1.5f || Math::Abs(Upright.Roll)>1.5f;
            Upright.Pitch=0.0f; Upright.Roll=0.0f;
            if (Gap< -4.0f || Gap>105.0f) return;
            FVector Desired=Gap>3.0f?Center-FVector(0,0,Gap):Center;
            if (Tilt || Gap>3.0f)
            {
                if (!CapsulePathClear(T,Center,Desired+FVector(0,0,0.1f))) return;
                FHitResult Stop;
                M.MoveUpdatedComponent(Desired-Center,Upright,Stop,true,false);
                if (Stop.bStartPenetrating) return;
                M.bForceNextFloorCheck=true;
            }
            FVector Base=T.GetBaseTranslationOffset();
            FRotator Rotation=T.GetBaseRotationOffset();
            LastGetupMeshOffset=float((Mesh.RelativeLocation-Base).Size());
            // Only the component's standing attachment offsets; keep animated
            // bones, authored mesh yaw and the character's facing direction.
            if (LastGetupMeshOffset<=180.0f && LastGetupMeshOffset>3.0f) Mesh.SetRelativeLocation(Base);
            bool MeshTilt=!Mesh.RelativeRotation.Equals(Rotation,1.0f);
            if (MeshTilt) Mesh.SetRelativeRotation(Rotation);
            GetupWatches[Slot].Aligned=true;
            if (Tilt || MeshTilt || Gap>3.0f || LastGetupMeshOffset>3.0f) BodyGetupAlignments+=1;
            LastBodyGetup="standing_attachment_checked";
            return;
        }
    }

    void GetupWatchTick()
    {
        float Now=GetGameTimeSinceCreation();
        for (int I=GetupWatches.Num()-1; I>=0; I--)
        {
            auto W=GetupWatches[I];
            auto T=W.Target;
            if (!Ready() || !IsValid(T) || T.IsActorBeingDestroyed() || T.GetWorld()!=GetWorld() || !IsValid(T.CharacterState) ||
                !IsValid(W.Mesh) || T.Mesh!=W.Mesh || !IsValid(T.CapsuleComponent) ||
                (T.GetActorLocation()-Hero.GetActorLocation()).SizeSquared()>3000.0f*3000.0f || T.IsDead() ||
                T.HasGameplayTag(GameplayTag::State_PartOfCinematic) || T.HasGameplayTag(GameplayTag::Ability_Action_Teleport_Scripted) ||
                T.IsInConversation() ||
                (W.Until>0.0f && Now>W.Until))
            { GetupWatches.RemoveAt(I); continue; }
            if (Now<W.NextCheck) continue;
            GetupWatches[I].NextCheck=Now+0.12f;
            LastBodyGetupTarget=T.GetPathName();
            LastBodyGetupRoot=T.CapsuleComponent.GetWorldLocation();
            LastBodyGetupAnchor=W.Anchor;
            LastBodyGetupHip=W.Mesh.GetBoneIndex(n"pelvis")>=0?W.Mesh.GetSocketLocation(n"pelvis"):W.Mesh.GetWorldLocation();
            if (T.IsDefeated() || T.HasGameplayTag(GameplayTag::State_Ragdoll) || W.Mesh.IsSimulatingPhysics(n"pelvis"))
            {
                LastBodyGetup=T.IsDefeated()?"waiting_defeat_exit":"waiting_stock_physics";
                GetupWatches[I].Until=0.0f; GetupWatches[I].StandingSamples=0;
                GetupWatches[I].HoverStart=-1.0f; GetupWatches[I].HoverSettled=false;
                GetupWatches[I].Aligned=false; GetupWatches[I].Placed=false; continue;
            }
            if (W.Until<=0.0f) GetupWatches[I].Until=Now+5.0f;
            auto M=T.GetGothicMovementComponent();
            if (!IsValid(M) || W.Mesh.IsSimulatingPhysics(n"pelvis") || T.HasGameplayTag(GameplayTag::State_Ragdoll) ||
                M.UpdatedComponent!=T.CapsuleComponent || T.RootComponent!=T.CapsuleComponent) continue;
            FVector At=T.CapsuleComponent.GetWorldLocation();
            FVector Anchor=W.Anchor+FVector(0,0,T.CapsuleComponent.GetScaledCapsuleHalfHeight()-W.HalfHeight);
            LastBodyGetupRoot=At; LastBodyGetupAnchor=Anchor; LastBodyGetupHip=W.Mesh.GetSocketLocation(n"pelvis");
            if (!W.Aligned) AlignStandingBody(T,M,I);
            if (M.MovementMode==EMovementMode::MOVE_Falling) continue;
            if (GetupWatches[I].Aligned) { GetupWatches[I].Placed=true; continue; }
            float Gap;
            if (W.Placed && CapsuleFloor(T,M,At,Gap)) continue;
            if (!W.Placed && W.EntryHalfHeight>0.0f && !CapsuleFloor(T,M,At,Gap))
            {
                // A long sideways drag can leave the native capsule buried
                // under its entry point, too far from the proposed get-up foot.
                FVector Entry=W.Entry+FVector(0,0,T.CapsuleComponent.GetScaledCapsuleHalfHeight()-W.EntryHalfHeight);
                RestoreBuriedCapsule(T,Entry,true);
                At=T.CapsuleComponent.GetWorldLocation();
            }
            if (!CapsuleFloor(T,M,Anchor,Gap)) { LastBodyGetup="waiting_floor"; continue; }
            if (!CapsulePathClear(T,Anchor,Anchor+FVector(0,0,0.1f),true)) { LastBodyGetup="anchor_occupied"; continue; }
            int Before=BodyFloorRecoveries;
            RestoreBuriedCapsule(T,Anchor,true);
            if (BodyFloorRecoveries!=Before)
            { GetupWatches[I].Placed=true; LastBodyGetup="recovered_after_settle"; continue; }
            if (W.Placed || !CapsuleFloor(T,M,At,Gap)) continue;
            FVector Delta=Anchor-At;
            if (Delta.SizeSquared()<9.0f) { GetupWatches[I].Placed=true; LastBodyGetup="supported"; continue; }
            if (Delta.SizeSquared()>220.0f*220.0f || Math::Abs(Delta.Z)>24.0f || !CapsulePathClear(T,At,Anchor))
            { LastBodyGetup="path_blocked"; continue; }
            FHitResult Hit;
            GetupWatches[I].Placed=true;
            M.MoveUpdatedComponent(Delta,T.GetActorRotation(),Hit,true,false);
            M.bForceNextFloorCheck=true;
            BodyGetupMoves+=1; LastBodyGetup=Hit.bBlockingHit?"settle_blocked":"settled";
        }
    }

    void RestoreBuriedCapsule(AGothicCharacter T,FVector Anchor,bool Settling=false)
    {
        auto M=T.GetGothicMovementComponent();
        if (!IsValid(M) || !IsValid(T.CapsuleComponent) || T.IsDead() || T.IsInConversation() ||
            T.HasGameplayTag(GameplayTag::State_PartOfCinematic) || T.HasGameplayTag(GameplayTag::Ability_Action_Teleport_Scripted)) return;
        FVector Now=T.GetActorLocation();
        FVector Delta=Anchor-Now;
        float OldGap,CurrentGap;
        float MinDrop=Settling?22.0f:float(T.CapsuleComponent.GetScaledCapsuleHalfHeight());
        if (Delta.Z < MinDrop || Delta.Z>350.0f ||
            Delta.X*Delta.X+Delta.Y*Delta.Y>55.0f*55.0f || CapsuleFloor(T,M,Now,CurrentGap) ||
            !CapsuleFloor(T,M,Anchor,OldGap) || !CapsulePathClear(T,Anchor,Anchor+FVector(0,0,0.1f),true)) return;
        FHitResult Result;
        if (!T.SetActorLocation(Anchor,false,Result,true)) return;
        M.bForceNextFloorCheck = true;
        BodyFloorRecoveries+=1;
    }

    bool CanDisplaceBody(AGothicCharacter Target, UGothicMovementComponent Movement,bool ForRagdoll=false)
    {
        if (Target.HasGameplayTag(GameplayTag::State_Ragdoll))
        { BodyEligibility = "native_ragdoll"; return false; }
        BodyMovementMode = int(Movement.MovementMode);
        BodyCustomMode = int(Movement.CustomMovementMode);
        BodyFloorDistance = -1.0f;
        BodyPose = "";
        if (Movement.UpdatedComponent != Target.RootComponent)
        {
            BodyEligibility = "different_updated_component"; return false;
        }
        if (!ForRagdoll && Target.IsPlayingRootMotion())
        { BodyRootMotionSkips+=1; BodyEligibility="native_root_motion"; return false; }
        if (Movement.IsMovingOnGround())
        {
            if (!CapsuleFloor(Target,Movement,Target.GetActorLocation(),BodyFloorDistance))
            { BodyEligibility="ground_capsule_unsupported"; return false; }
            BodyEligibility = "ground_movement"; return true;
        }
        if (Movement.MovementMode != EMovementMode::MOVE_Custom)
        {
            BodyEligibility = "not_ground_or_custom"; return false;
        }
        // Some standing Gothic NPCs use MOVE_Custom. Preserve that mode; never
        // force Walking or cancel their animation just to apply the hand offset.
        if (!Target.IsHuman() || Target.IsSitting() || Target.IsClimbingLadderOrWall() ||
            Target.IsSwimming() || Target.IsDiving() ||
            Target.HasGameplayTag(GameplayTag::State_PartOfCinematic) ||
            Target.HasGameplayTag(GameplayTag::State_Ragdoll) ||
            Target.HasGameplayTag(GameplayTag::Ability_Action_Teleport_Scripted))
        {
            BodyEligibility = "custom_active_action"; return false;
        }
        if (Target.CharacterState.IsDoingAnyInteraction())
        {
            // Guarding is itself an interaction in Gothic. The stock guard tasks
            // use these standing idle montages, without furniture or an attached prop.
            auto Montage = Target.GetCurrentMontage();
            if (IsValid(Montage)) BodyPose = Montage.GetPathName();
            bool StandingIdle = BodyPose.StartsWith("/Game/AnimLibrary/Humanoid/Man/Living/Idle/") ||
                BodyPose.StartsWith("/Game/AnimLibrary/Humanoid/Man/Living/Guard/") ||
                Target.HasGameplayTag(GameplayTag::Action_Ambient_GuardPassage) ||
                Target.HasGameplayTag(GameplayTag::Action_Ambient_ThorusGuardPassage) ||
                Target.HasGameplayTag(GameplayTag::Action_Ambient_GuardWatch);
            if (!StandingIdle) { BodyEligibility = "custom_object_interaction"; return false; }
        }
        FFindFloorResult Floor;
        Movement.FindFloor(Target.GetActorLocation(), Floor);
        BodyFloorDistance = Floor.bLineTrace ? Floor.LineDist : Floor.FloorDist;
        if (!Floor.bBlockingHit || !Floor.bWalkableFloor || BodyFloorDistance < -1.0f || BodyFloorDistance > 8.0f)
        {
            BodyEligibility = "custom_no_ground_support"; return false;
        }
        if (!IsValid(Target.Mesh) || Target.Mesh.GetBoneIndex(n"head") < 0 || Target.Mesh.GetBoneIndex(n"pelvis") < 0)
        {
            BodyEligibility = "custom_unknown_pose"; return false;
        }
        float GroundZ = Floor.HitResult.ImpactPoint.Z;
        if (Target.Mesh.GetSocketLocation(n"head").Z - GroundZ < 110.0f ||
            Target.Mesh.GetSocketLocation(n"pelvis").Z - GroundZ < 45.0f)
        {
            BodyEligibility = "custom_low_pose"; return false;
        }
        BodyEligibility = "custom_standing_supported";
        return true;
    }

    bool QueueBodyMotion(AGothicCharacter Target, UGothicMovementComponent Movement, FGothicVRBodyInput Input, float Pressure)
    {
        BodyMovementMode = int(Movement.MovementMode);
        BodyMovementTick = Movement.IsComponentTickEnabled();
        BodyRootMotion = Target.IsPlayingRootMotion();
        if (!CanDisplaceBody(Target, Movement))
        {
            BodyStatus = "unsupported_movement_mode"; BodyRejected += 1; return false;
        }
        int Slot = -1;
        for (int J = 0; J < BodyMotions.Num(); J++)
        {
            if (BodyMotions[J].Target == Target) { Slot = J; break; }
        }
        if (Slot < 0)
        {
            for (int J = 0; J < BodyMotions.Num(); J++)
            {
                if (!IsValid(BodyMotions[J].Target)) { Slot = J; break; }
            }
            if (Slot < 0) { BodyStatus = "movement_slots_full"; return false; }
            ClearBodyMotion(Slot);
            BodyMotions[Slot].Target = Target;
            BodyMotions[Slot].Movement = Movement;
            BodyMotions[Slot].PreviousPosition = Target.GetActorLocation();
            // Apply our swept offset after the character's ordinary movement tick.
            AddTickPrerequisiteComponent(Movement);
        }
        FVector Desired;
        if (Input.Grip)
        {
            FVector Error = Input.Goal - Input.Point;
            Error.Z = 0.0f;
            float Length = Error.Size();
            if (Length > 7.0f) Desired = Error.GetSafeNormal() * Math::Min(46.0f, (Length - 7.0f) * 2.2f);
        }
        else
        {
            float Approach = Math::Max(0.0f, -Input.Velocity.GetClampedToMaxSize(160.0f).DotProduct(Input.Normal));
            Desired = -Input.Normal * Math::Min(26.0f, Math::Max(0.0f, Approach - 40.0f) * 0.16f + Math::Max(0.0f, Pressure - 4.0f) * 1.3f);
            Desired.Z = 0.0f;
        }
        BodyMotions[Slot].RequestedSpeed += Desired * StrengthScale;
        BodyMotions[Slot].Inputs += 1;
        BodyMotions[Slot].LastInput = GetGameTimeSinceCreation();
        return true;
    }

    void BodyMotionTick(float Delta)
    {
        float Now = GetGameTimeSinceCreation();
        for (int I = 0; I < BodyMotions.Num(); I++)
        {
            auto Motion = BodyMotions[I]; // do not retain array references across movement callbacks
            auto Target = Motion.Target;
            auto Movement = Motion.Movement;
            if (!IsValid(Target)) { ClearBodyMotion(I); continue; }
            if (!Ready() || !IsValid(Target.CharacterState) || Target.IsDead() || Target.IsDefeated() ||
                !IsValid(Movement) || Target.GetWorld() != GetWorld() || Now - Motion.LastInput > 0.12f ||
                !CanDisplaceBody(Target, Movement))
            {
                ClearBodyMotion(I); continue;
            }
            // Two hands on the same NPC feed one motor, not two independent moves.
            FVector Desired = Motion.Inputs > 0 ? Motion.RequestedSpeed / float(Motion.Inputs) : FVector::ZeroVector;
            float MassRatio = Math::Clamp(80.0f / Math::Max(40.0f, Movement.Mass), 0.25f, 1.5f);
            Desired *= Math::Sqrt(MassRatio);
            float Blend = 1.0f - Math::Exp(-16.0f * Delta);
            FVector Change = ((Desired - Motion.Speed) * Blend).GetClampedToMaxSize(850.0f * MassRatio * Delta);
            Motion.Speed = (Motion.Speed + Change).GetClampedToMaxSize(120.0f);
            Motion.Speed.Z = 0.0f;
            FVector Step = Motion.Speed * Delta;
            if (Movement.MovementMode == EMovementMode::MOVE_Custom && Step.Size() > 0.001f)
            {
                // Custom mode may have no native floor-following. Validate the
                // destination before each move and follow only small ground slopes.
                FFindFloorResult DestinationFloor;
                Movement.FindFloor(Target.GetActorLocation() + Step, DestinationFloor);
                float Distance = DestinationFloor.bLineTrace ? DestinationFloor.LineDist : DestinationFloor.FloorDist;
                float Rise = BodyFloorDistance - Distance;
                if (!DestinationFloor.bBlockingHit || !DestinationFloor.bWalkableFloor ||
                    Distance < -1.0f || Distance > 8.0f || Math::Abs(Rise) > 4.0f)
                {
                    Step = FVector::ZeroVector; Motion.Speed = FVector::ZeroVector;
                    BodyEligibility = "custom_destination_unsupported"; BodyBlockedFrames += 1;
                }
                else Step.Z = Rise;
            }
            BodyTarget = Target.GetPathName();
            BodyBone = n"None";
            BodyRootMotion = Target.IsPlayingRootMotion();
            BodyMovementTick = Movement.IsComponentTickEnabled();
            BodyMovementMode = int(Movement.MovementMode);
            BodyRequestedStep = Step;
            BodyBlocker = "";
            FVector Before = Target.GetActorLocation();
            BodyBetweenTicks = Before - Motion.PreviousPosition;
            FHitResult Hit;
            if (Step.Size() > 0.001f && SupportedBodyStep(Target,Movement,Step))
            {
                Movement.MoveUpdatedComponent(Step, Target.GetActorRotation(), Hit, true, false);
                if (!IsValid(Target) || !IsValid(Movement)) { ClearBodyMotion(I); continue; }
                if (Hit.bBlockingHit)
                {
                    BodyBlockedFrames += 1;
                    auto Blocker = Hit.GetActor();
                    if (IsValid(Blocker)) BodyBlocker = Blocker.GetPathName();
                    FVector Normal = Hit.Normal.GetSafeNormal();
                    FVector Remaining = Step * (1.0f - Math::Clamp(Hit.Time, 0.0f, 1.0f));
                    FVector Slide = Remaining - Normal * Math::Min(0.0f, Remaining.DotProduct(Normal));
                    Slide.Z = 0.0f;
                    if (!Hit.bStartPenetrating && Slide.Size() > 0.001f && !Target.IsDead() && Movement.MovementMode != EMovementMode::MOVE_Custom && SupportedBodyStep(Target,Movement,Slide))
                    {
                        FHitResult SlideHit;
                        Movement.MoveUpdatedComponent(Slide, Target.GetActorRotation(), SlideHit, true, false);
                    }
                    Motion.Speed -= Normal * Math::Min(0.0f, Motion.Speed.DotProduct(Normal));
                    Motion.Speed.Z = 0.0f;
                }
            }
            if (!IsValid(Target) || !IsValid(Movement)) { ClearBodyMotion(I); continue; }
            FVector After = Target.GetActorLocation();
            BodyActualStep = After - Before;
            float Moved = BodyActualStep.Size();
            BodyMovedCm += Moved;
            if (Moved > 0.001f) BodyMoveFrames += 1;
            BodyStatus = Moved > 0.001f ? "swept_character_moved" : (Step.Size() > 0.01f ? "swept_character_blocked" : "swept_character_rest");
            Movement.bForceNextFloorCheck = true;
            Motion.PreviousPosition = After;
            Motion.RequestedSpeed = FVector::ZeroVector;
            Motion.Inputs = 0;
            BodyMotions[I] = Motion;
        }
    }

    void Provoke(AGothicCharacter Target, int Hand, int GripSerial)
    {
        if (!IsValid(Target.CharacterState) || !Target.IsHuman() || Target.IsDead() || Target.IsDefeated()) return;
        if (Target.GetPathName().Contains("GothicVR_Training")) return;
        if (Target.HasGameplayTag(GameplayTag::State_Invulnerable)) return;
        if (Target.IsInCombat() || Target.IsInConversation() || Hero.IsInConversation()) return;
        auto AI = Cast<UGameplayAbility_CharacterAI_Gothic>(Target.CharacterState.AI);
        if (!IsValid(AI)) return;
        float Now = GetGameTimeSinceCreation();
        int Index = -1;
        for (int I = 0; I < Provocations.Num(); I++)
        {
            if (Provocations[I].Target == Target) { Index = I; break; }
        }
        if (Index < 0)
        {
            if (Provocations.Num() >= 32) Provocations.RemoveAt(0);
            FGothicVRProvocation Entry; Entry.Target = Target;
            Index = Provocations.Num(); Provocations.Add(Entry);
        }
        auto P = Provocations[Index];
        if (Now - P.LastTouch > 60.0f)
        {
            FGothicVRProvocation Fresh; Fresh.Target = Target; P = Fresh;
        }
        bool Episode = Now - P.LastTouch > 0.8f && Now - P.LastEpisode > 1.5f;
        if (GripSerial > 0)
        {
            bool FreshGrip = GripSerial != (Hand == 0 ? P.LeftGrip : P.RightGrip);
            // The palm commonly touches just before the grip edge. Treat that
            // approach as part of the same action, even at high input rates.
            bool Approach = !P.LastWasGrip && P.Count > 0 && Now - P.LastTouch <= 0.8f && Now - P.LastEpisode < 0.8f;
            Episode = FreshGrip && !Approach;
            if (Hand == 0) P.LeftGrip = GripSerial;
            else P.RightGrip = GripSerial;
            if (FreshGrip) { P.LastWasGrip = true; P.NextComplaint = Now + 7.0f; }
            P.GripSample = Now;
        }
        else if (Episode) P.LastWasGrip = false;
        Episode = Episode && P.Count < 3;
        P.LastTouch = Now;
        if (Episode && P.Count < 3)
        {
            P.Count += 1; P.LastEpisode = Now;
            if (P.Count == 3) { P.VoiceStage = 2; P.NextVoiceTime = Now; P.VoiceWaitStart = Now; }
        }
        Provocations[Index] = P;
        if (!Episode) return;
        if (P.Count < 3) Warnings += 1;
        // Speech and escalation are dispatched by the world actor, once per
        // episode. Do not queue latent AI.Say tasks from an external callback.
    }

    bool SayProvocation(AGothicCharacter Target, int Stage)
    {
        ProvocationVoiceTarget = Target.GetPathName();
        ProvocationVoiceStage = Stage;
        auto Voice = Target.CharacterState.Voiceline;
        if (!IsValid(Voice)) { ProvocationVoiceStatus = "no_voice_component"; return false; }
        TArray<FGameplayTag> Choices;
        if (Stage == 1) Choices.Add(GameplayTag::Sound_Voice_Reaction_Blocking_OutOfMyWay);
        if (Stage == 2) Choices.Add(GameplayTag::Sound_Voice_Reaction_Blocking_InsistOutOfMyWay);
        if (Stage == 3)
        {
            Choices.Add(GameplayTag::Sound_Voice_Reaction_Combat_Start);
            Choices.Add(GameplayTag::Sound_Voice_Reaction_Combat_Start_YouAskedForIt);
        }
        if (Stage < 3) Choices.Add(GameplayTag::Sound_Voice_Reaction_Blocking_MakeWay);
        Choices.Add(GameplayTag::Sound_Voice_Reaction_Interjection_Angry);
        ProvocationVoiceTag = "";
        for (auto Tag : Choices)
        {
            FGenericVoicelineRequestContext Context;
            // Stock blocked-path escalation queries Combat.Start with this context.
            // Explicit fallback lines have their own tag and need no extra qualifier.
            if (Tag == GameplayTag::Sound_Voice_Reaction_Combat_Start)
                Context.TagsOther.AddLeafTag(GameplayTag::VoicelineContext_AskedForIt);
            if (!Voice.HasVoicelineForWithContext(Tag, Hero.CharacterState, Context)) continue;
            ProvocationVoiceTag = Tag.ToString();
            // Same native route as the game's blocked-path warning. It selects
            // this NPC's voice/language and returns whether speech was accepted.
            if (Voice.SayVoicelineWithContext(Tag, Hero.CharacterState, Context, EPerceptionNoiseLoudness::Loud))
            {
                ProvocationVoices += 1;
                ProvocationVoiceStatus = Stage == 3 ? "threat_accepted" : "warning_accepted";
                return true;
            }
            ProvocationVoiceFailures += 1;
            ProvocationVoiceStatus = "voice_busy_or_rejected";
            return false;
        }
        ProvocationVoiceStatus = "no_matching_voiceline";
        return false;
    }

    void ProvocationTick()
    {
        float Now = GetGameTimeSinceCreation();
        if (Now < NextProvocationTick) return;
        NextProvocationTick = Now + 0.1f;
        for (int I = Provocations.Num()-1; I >= 0; I--)
        {
            auto P = Provocations[I];
            auto Target = P.Target;
            if (!IsValid(Target) || Target.IsActorBeingDestroyed() || !IsValid(Target.RootComponent) ||
                Target.GetWorld() != GetWorld() || !IsValid(Target.CharacterState))
            { Provocations.RemoveAt(I); continue; }
            if (P.VoiceStage>=P.Count && P.AttackAt<0.0f && Now-P.GripSample>=0.15f) continue;
            bool Eligible = Ready() && (Target.GetActorLocation() - Hero.GetActorLocation()).SizeSquared() < 650.0f*650.0f &&
                !Target.IsDead() && !Target.IsDefeated() &&
                !Target.IsInCombat() && !Target.IsInConversation() && !Hero.IsInConversation() &&
                !Target.HasGameplayTag(GameplayTag::State_Invulnerable) &&
                !Target.HasGameplayTag(GameplayTag::State_PartOfCinematic);
            if (!Eligible)
            {
                // Menu/VR shutdown, death, conversation or departure cancel
                // queued speech/attacks; never start a delayed fight on return.
                P.VoiceStage = P.Count; P.AttackAt = -1.0f; P.VoiceWaitStart = -1.0f;
                Provocations[I] = P; continue;
            }
            if (P.AttackAt >= 0.0f)
            {
                if (Now < P.AttackAt || (Target.CharacterState.IsSpeaking() && Now < P.AttackDeadline)) continue;
                P.AttackAt = -1.0f;
                Provocations[I] = P; // commit before AI callbacks
                auto AI = Cast<UGameplayAbility_CharacterAI_Gothic>(Target.CharacterState.AI);
                if (IsValid(AI))
                {
                    Fights += 1;
                    AI.StartFistFightImmediatelyNoLooting(Hero.CharacterState);
                }
                continue;
            }
            if (P.VoiceStage >= P.Count)
            {
                if (P.Count > 0 && P.Count < 3 && Now - P.GripSample < 0.15f && Now >= P.NextComplaint &&
                    !Target.CharacterState.IsSpeaking())
                {
                    P.NextComplaint = Now + 8.0f;
                    Provocations[I] = P;
                    SayProvocation(Target, P.Count);
                }
                continue;
            }
            if (Now < P.NextVoiceTime) continue;
            bool Speaking = Target.CharacterState.IsSpeaking();
            if (Speaking && !(P.Count == 3 && Now - P.VoiceWaitStart >= 4.0f)) continue;
            if (P.VoiceWaitStart < 0.0f) P.VoiceWaitStart = Now;
            bool Spoken = !Speaking && SayProvocation(Target, P.VoiceStage + 1);
            P.NextVoiceTime = Now + (Spoken ? 2.0f : 0.75f);
            if (Spoken || Now - P.VoiceWaitStart >= 4.0f)
            {
                P.VoiceStage += 1; P.VoiceWaitStart = -1.0f;
                if (P.VoiceStage == 3)
                {
                    P.AttackAt = Now + 1.2f;
                    P.AttackDeadline = Now + 5.0f;
                }
            }
            Provocations[I] = P;
        }
    }

    void ObserveCombatVoices()
    {
        float Now = GetGameTimeSinceCreation();
        if (Now < NextVoiceObservation) return;
        NextVoiceObservation = Now + 0.4f;
        CombatVoiceWindow = Hero.IsInCombat() || Now < VoiceContactUntil;
        NearbySpeaking = 0;
        if (!CombatVoiceWindow) return;
        auto Nearby = UNearbyActorsSubsystem::Get();
        if (!IsValid(Nearby)) return;
        auto Actors = Nearby.FindActorsOfClassInRadius2D(AGothicCharacter::StaticClass(), Hero.GetActorLocation(), 1000.0f);
        for (auto Actor : Actors)
        {
            auto NPC = Cast<AGothicCharacter>(Actor);
            if (!IsValid(NPC) || NPC == Hero || !IsValid(NPC.CharacterState) ||
                NPC.IsDead() || !NPC.CharacterState.IsSpeaking()) continue;
            NearbySpeaking += 1;
            VoiceObservations += 1;
            LastNearbySpeaker = NPC.GetPathName();
            LastSpeakerPosition = NPC.GetActorLocation();
        }
    }

    UPROPERTY() TArray<FGothicVRDownedBody> DownedBodies;
    UPROPERTY() TArray<FGothicVRRecoveryHold> DownedRecovery;

    void RefreshDownedRecovery(AGothicCharacter Target)
    {
        if (!Ready() || !IsValid(Target) || Target == Hero || !OwnDownedPose(Target,Target.Mesh)) return;
        float Now = GetGameTimeSinceCreation();
        for (int I = 0; I < DownedRecovery.Num(); I++)
            if (DownedRecovery[I].Target == Target)
            { DownedRecovery[I].Until = Now + DownedRecovery[I].Interval; return; }
        auto ASC = Target.GetGothicAbilitySystemComponent();
        if (!IsValid(ASC) || Target.HasGameplayTag(GameplayTag::Character_StayDefeated)) return;
        // Query the target's actual granted defeat class, including altered
        // timings on a derived class. An indefinite defeat remains untouched.
        TArray<FGameplayAbilitySpecHandle> Abilities;
        ASC.GetAllAbilities(Abilities);
        for (auto Ability : Abilities)
        {
            bool Instance = false;
            const auto Defeat = Cast<UGameplayAbilityDefeated>(AbilitySystem::GetGameplayAbilityFromSpecHandle(ASC, Ability, Instance));
            if (!IsValid(Defeat)) continue;
            float Interval = Defeat.m_TimeToStandUp;
            if (Interval <= 0.0f) return;
            FGothicVRRecoveryHold Hold;
            Hold.Target = Target; Hold.ASC = ASC; Hold.Interval = Interval; Hold.Until = Now+Interval;
            Hold.Effect = ASC.ApplyGameplayEffectSpecToSelf(ASC.MakeOutgoingSpec(UGE_VRManipulatedDowned::StaticClass(),0.0f,ASC.MakeEffectContext()));
            if (GothicGAS::IsActiveGameplayEffectHandleValid(Hold.Effect)) DownedRecovery.Add(Hold);
            return;
        }
    }

    void DownedRecoveryTick(bool Cancel)
    {
        if (DownedRecovery.IsEmpty()) return;
        float Now = GetGameTimeSinceCreation();
        for (int I = DownedRecovery.Num()-1; I >= 0; I--)
        {
            if (!DownedRecovery.IsValidIndex(I)) continue;
            auto Hold = DownedRecovery[I];
            if (!Cancel && Ready() && IsValid(Hold.Target) && Hold.Target.GetWorld()==GetWorld() &&
                IsValid(Hold.Target.CharacterState) && !Hold.Target.IsDead() && Hold.Target.IsDefeated() && Now<Hold.Until) continue;
            DownedRecovery.RemoveAt(I);
            // Give the finite native get-up ability its kinematic mesh before
            // removing our own stay-down tag. Stock and quest holds keep theirs.
            if (!Cancel && Now>=Hold.Until && IsValid(Hold.Target) && !Hold.Target.IsActorBeingDestroyed() &&
                Hold.Target.GetWorld()==GetWorld() && IsValid(Hold.Target.CharacterState) && !Hold.Target.IsDead())
                for (int J=DownedBodies.Num()-1; J>=0; J--)
                    if (DownedBodies[J].Target==Hold.Target) { EndDowned(J,true); DownedRestReleases+=1; }
            if (IsValid(Hold.ASC) && Hold.ASC.GetWorld()==GetWorld()) Hold.ASC.RemoveActiveGameplayEffect(Hold.Effect);
        }
    }

    bool OwnDownedPose(AGothicCharacter T, USkeletalMeshComponent Mesh) const
    {
        if (!IsValid(T) || T.IsActorBeingDestroyed() || !IsValid(Mesh) || !IsValid(T.CharacterState) || T.GetWorld() != GetWorld() ||
            T.Mesh != Mesh || T.IsDead() || !T.IsDefeated() || T.IsInConversation() ||
            T.HasGameplayTag(GameplayTag::State_PartOfCinematic)) return false;
        auto Clip = T.GetCurrentMontage();
        if (!IsValid(Clip)) return true;
        FString DownedClip = Clip.GetName().ToString();
        return !DownedClip.Contains("_GetUp_") && !(DownedClip.Contains("_Defeated_") && DownedClip.Contains("_Out_"));
    }

    void EndDowned(int Slot,bool PreparingGetup=false)
    {
        auto P = DownedBodies[Slot];
        DownedBodies.RemoveAt(Slot);
        for (int H = 0; H < Held.Num(); H++)
            if (Held[H] == P.Target) ReleaseHand(H);
        if (!IsValid(P.Target) || P.Target.IsActorBeingDestroyed() || P.Target.GetWorld() != GetWorld() || !IsValid(P.Target.CharacterState) ||
            !IsValid(P.Mesh) || P.Mesh != P.Target.Mesh) return;
        if (P.OwnFloorResponse && P.Mesh.GetCollisionProfileName()==P.FloorProfile &&
            P.Mesh.GetCollisionObjectType()==P.FloorObjectType && P.Mesh.GetCollisionEnabled()==P.FloorMode &&
            P.Mesh.GetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic)==ECollisionResponse::ECR_Block)
            P.Mesh.SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic,P.OldFloorResponse);
        RegisterBodyGetup(P);
        if (P.Target.IsDead() || (!P.OwnPelvis && P.Mesh.IsSimulatingPhysics(n"pelvis")) ||
            P.Target.HasGameplayTag(GameplayTag::State_Ragdoll)) return;
        for (FName ChainBone : P.OwnedRoots)
        {
            P.Mesh.SetAllBodiesBelowPhysicsBlendWeight(ChainBone, 0.0f, false, true);
            P.Mesh.SetAllBodiesBelowSimulatePhysics(ChainBone, false, true);
        }
        for (int J = P.OwnedSpine.Num()-1; J >= 0; J--)
            if (P.Mesh.IsSimulatingPhysics(P.OwnedSpine[J])) P.Mesh.SetBodySimulatePhysics(P.OwnedSpine[J], false);
        if (PreparingGetup && P.HasSafeCapsule && IsValid(P.Target.CapsuleComponent) && !P.Mesh.IsSimulatingPhysics(P.DriverBone))
        {
            auto Cap=P.Target.CapsuleComponent;
            auto Move=P.Target.GetGothicMovementComponent();
            FVector Anchor=P.SafeCapsule+FVector(0,0,Cap.GetScaledCapsuleHalfHeight()-P.AnchorHalfHeight);
            float Gap;
            if (IsValid(Move) && CapsuleFloor(P.Target,Move,Anchor,Gap))
            {
                RestoreBuriedCapsule(P.Target,Anchor,true);
                FVector Center=Cap.GetWorldLocation();
                FVector Step=Anchor-Center;
                if (Step.SizeSquared()>4.0f && Step.SizeSquared()<220.0f*220.0f &&
                    CapsulePathClear(P.Target,Center,Anchor,true))
                {
                    FHitResult Stop;
                    Move.MoveUpdatedComponent(Step,P.Target.GetActorRotation(),Stop,true,false);
                    Move.bForceNextFloorCheck=true;
                }
            }
        }
    }

    int BeginDowned(AGothicCharacter T, float Now)
    {
        for (int I = 0; I < DownedBodies.Num(); I++)
            if (DownedBodies[I].Target == T && DownedBodies[I].Mesh == T.Mesh) return I;
        if (DownedBodies.Num() >= 4) return -1;
        FGothicVRDownedBody P;
        P.Target = T; P.Mesh = T.Mesh; P.LastTouch = Now; P.NextVoice = Now + 0.35f;
        if (P.Mesh.GetBoneIndex(n"pelvis")<0 && P.Mesh.GetNumBones()>0)
        {
            FVector Closest,Normal;
            FName Near; float32 Distance;
            P.DriverBone=P.Mesh.GetBoneName(0);
            if (P.Mesh.GetClosestPointOnPhysicsAsset(T.GetActorLocation(),Closest,Normal,Near,Distance) &&
                P.Mesh.GetBoneIndex(Near)>=0) P.DriverBone=Near;
        }
        auto Movement = T.GetGothicMovementComponent();
        float FloorGap;
        P.SafeCapsule=T.GetActorLocation();
        P.HasSafeCapsule=IsValid(Movement) && CapsuleFloor(T,Movement,P.SafeCapsule,FloorGap);
        if (P.HasSafeCapsule)
        {
            P.EntryCapsule=P.SafeCapsule;
            P.EntryHalfHeight=T.CapsuleComponent.GetScaledCapsuleHalfHeight();
            P.AnchorHalfHeight=P.EntryHalfHeight;
        }
        if (!P.Mesh.IsSimulatingPhysics(n"pelvis") && !T.HasGameplayTag(GameplayTag::State_Ragdoll) &&
            (int(P.Mesh.GetCollisionEnabled()) == 2 || int(P.Mesh.GetCollisionEnabled()) == 3))
        {
            TArray<FName> Roots;
            P.OldFloorResponse = P.Mesh.GetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic);
            if (P.OldFloorResponse != ECollisionResponse::ECR_Block)
            {
                P.Mesh.SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic,ECollisionResponse::ECR_Block);
                P.OwnFloorResponse = true;
                P.FloorProfile = P.Mesh.GetCollisionProfileName();
                P.FloorObjectType = P.Mesh.GetCollisionObjectType();
                P.FloorMode = P.Mesh.GetCollisionEnabled();
            }
            Roots.Add(n"upperarm_l"); Roots.Add(n"upperarm_r");
            Roots.Add(n"thigh_l"); Roots.Add(n"thigh_r");
            for (FName ChainBone : Roots)
            {
                if (P.Mesh.GetBoneIndex(n"pelvis")<0 || P.Mesh.GetBoneIndex(n"hand_l")<0) break;
                if (P.Mesh.GetBoneIndex(ChainBone) < 0) continue;
                bool InUse = false;
                for (int J = 0; J < P.Mesh.GetNumBones(); J++)
                {
                    FName B = P.Mesh.GetBoneName(J);
                    if ((B == ChainBone || P.Mesh.BoneIsChildOf(B, ChainBone)) && P.Mesh.IsSimulatingPhysics(B)) { InUse = true; break; }
                }
                if (InUse) continue;
                P.Mesh.SetAllBodiesBelowSimulatePhysics(ChainBone, true, true);
                P.Mesh.SetAllBodiesBelowPhysicsBlendWeight(ChainBone, 0.0f, false, true);
                P.OwnedRoots.Add(ChainBone);
            }
        }
        int Slot = DownedBodies.Num(); DownedBodies.Add(P);
        RegisterBodyGetup(P);
        return Slot;
    }

    void EnableDownedTorso(AGothicCharacter Target, int Slot)
    {
        if (!DownedBodies[Slot].SpineChecked && !Target.Mesh.IsSimulatingPhysics(n"pelvis") &&
            !Target.HasGameplayTag(GameplayTag::State_Ragdoll) &&
            (int(Target.Mesh.GetCollisionEnabled()) == 2 || int(Target.Mesh.GetCollisionEnabled()) == 3))
        {
            float Now=GetGameTimeSinceCreation();
            if (Now<DownedBodies[Slot].NextSupportCheck || !IsValid(Target.CapsuleComponent)) return;
            DownedBodies[Slot].NextSupportCheck=Now+0.2f;
            FName Driver=DownedBodies[Slot].DriverBone;
            FVector Center;
            if (!HipFloorCenter(Target,Target.Mesh.GetSocketLocation(Driver),Center,true)) { DownedSupportMisses+=1; return; }
            DownedBodies[Slot].SpineChecked = true;
            if ((Target.Mesh.GetBoneIndex(n"pelvis")<0 || Target.Mesh.GetBoneIndex(n"hand_l")<0) && Target.Mesh.GetNumBones()>0)
            {
                auto Mesh=Target.Mesh;
                for (int J=0; J<Mesh.GetNumBones(); J++)
                    if (Mesh.IsSimulatingPhysics(Mesh.GetBoneName(J))) return;
                FName SkeletonRoot=Mesh.GetBoneName(0);
                Mesh.SetAllBodiesBelowSimulatePhysics(SkeletonRoot,true,true);
                DownedBodies[Slot].OwnedRoots.Add(SkeletonRoot);
                DownedBodies[Slot].OwnPelvis=Mesh.IsSimulatingPhysics(Driver);
                DownedBodies[Slot].LastSafeHip=Mesh.GetSocketLocation(Driver);
                return;
            }
            // Record each newly enabled torso and head body separately.
            TArray<FName> Spine;
            Spine.Add(n"pelvis"); Spine.Add(n"spine_01"); Spine.Add(n"spine_02"); Spine.Add(n"spine_03");
            Spine.Add(n"spine_04"); Spine.Add(n"spine_05"); Spine.Add(n"clavicle_l"); Spine.Add(n"clavicle_r");
            Spine.Add(n"neck_01"); Spine.Add(n"neck_02"); Spine.Add(n"head");
            for (FName Vertebra : Spine)
            {
                if (Target.Mesh.GetBoneIndex(Vertebra) < 0 || Target.Mesh.IsSimulatingPhysics(Vertebra)) continue;
                Target.Mesh.SetBodySimulatePhysics(Vertebra,true);
                if (Target.Mesh.IsSimulatingPhysics(Vertebra))
                {
                    DownedBodies[Slot].OwnedSpine.Add(Vertebra);
                    if (Vertebra == n"pelvis")
                    {
                        DownedBodies[Slot].OwnPelvis=true;
                        DownedBodies[Slot].LastSafeHip=Target.Mesh.GetSocketLocation(n"pelvis");
                        if (IsValid(Target.CapsuleComponent) && HipFloorCenter(Target,DownedBodies[Slot].LastSafeHip,Center) &&
                            (Center-Target.GetActorLocation()).SizeSquared()<100.0f*100.0f &&
                            CapsulePathClear(Target,Center,Center+FVector(0,0,0.1f)))
                        {
                            DownedBodies[Slot].SafeCapsule=Center;
                            DownedBodies[Slot].HasSafeCapsule=true;
                            DownedBodies[Slot].AnchorHalfHeight=Target.CapsuleComponent.GetScaledCapsuleHalfHeight();
                        }
                    }
                }
            }
        }
    }

    bool HipCrossedSupport(AGothicCharacter T,FVector Last,FVector Hip,FHitResult&out Surface)
    {
        TArray<EObjectTypeQuery> Types;
        Types.Add(EObjectTypeQuery::WorldStatic); Types.Add(EObjectTypeQuery::WorldDynamic);
        Types.Add(UCollisionProfile::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
        TArray<AActor> Ignore; Ignore.Add(T); Ignore.Add(Hero);
        TArray<FHitResult> Hits;
        System::LineTraceMultiForObjects(Last+FVector(0,0,0.3f),Hip,Types,false,Ignore,EDrawDebugTrace::None,Hits,true);
        for (auto Hit : Hits)
        {
            auto Ground=Hit.Component;
            if (!IsValid(Ground) || Hit.bStartPenetrating || Hit.ImpactNormal.Z<0.65f ||
                (int(Ground.GetCollisionEnabled())!=2 && int(Ground.GetCollisionEnabled())!=3) ||
                Ground.GetCollisionResponseToChannel(T.Mesh.GetCollisionObjectType())!=ECollisionResponse::ECR_Block ||
                T.Mesh.GetCollisionResponseToChannel(Ground.GetCollisionObjectType())!=ECollisionResponse::ECR_Block) continue;
            if ((Hip-Hit.ImpactPoint).DotProduct(Hit.ImpactNormal)<0.0f &&
                (Hip-Last).DotProduct(Hit.ImpactNormal)<0.0f) { Surface=Hit; return true; }
        }
        return false;
    }

    void DownedTick(float Delta)
    {
        if (DownedBodies.IsEmpty()) return;
        float Now = GetGameTimeSinceCreation();
        for (int I = DownedBodies.Num()-1; I >= 0; I--)
        {
            auto P = DownedBodies[I];
            if (!Ready() || !OwnDownedPose(P.Target, P.Mesh)) { EndDowned(I); continue; }
            bool Touching = Now-P.LastTouch < 0.18f;
            bool OwnsBodies = P.OwnPelvis || !P.OwnedRoots.IsEmpty() || !P.OwnedSpine.IsEmpty();
            float Goal = OwnsBodies || Touching ? 1.0f : 0.0f;
            float Weight = P.Weight + (Goal-P.Weight)*(1.0f-Math::Exp(-12.0f*Delta));
            if (Math::Abs(Goal-Weight)<0.001f) Weight=Goal;
            if (Goal == 0.0f && Weight < 0.025f) { EndDowned(I); continue; }
            DownedBodies[I].Weight = Weight;
            bool FullPhysics = P.Mesh.IsSimulatingPhysics(P.DriverBone) || P.Target.HasGameplayTag(GameplayTag::State_Ragdoll);
            if (FullPhysics && (!P.OwnPelvis || P.Target.HasGameplayTag(GameplayTag::State_Ragdoll)))
            {
                DownedBodies[I].OwnedRoots.Empty();
                DownedBodies[I].OwnedSpine.Empty();
                DownedBodies[I].OwnPelvis=false;
            }
            else if (Weight != P.Weight) for (FName ChainBone : P.OwnedRoots)
                P.Mesh.SetAllBodiesBelowPhysicsBlendWeight(ChainBone, Weight, false, true);
            FVector Pull = FVector::ZeroVector;
            float Turn = 0.0f;
            int Grips = 0;
            for (int H = 0; H < 2; H++)
            {
                if (Hands[H].Target != P.Target || !Hands[H].Grip || Now-Hands[H].Time >= 0.15f) continue;
                FVector Error = Hands[H].Goal - Hands[H].Point;
                Pull += Error; Grips += 1;
                FVector Lever = Hands[H].Point - P.Target.GetActorLocation();
                Turn += (Lever.X*Error.Y-Lever.Y*Error.X)/Math::Max(900.0f, float(Lever.X*Lever.X+Lever.Y*Lever.Y));
            }
            auto Move = P.Target.GetGothicMovementComponent();
            if (P.OwnPelvis && !P.Target.HasGameplayTag(GameplayTag::State_Ragdoll) && IsValid(P.Target.CapsuleComponent))
            {
                // Moving the mesh parent while a Chaos handle still owns its
                // pelvis feeds parent displacement back into the grab. Track a
                // supported future capsule centre independently until handoff.
                FVector Hip = P.Mesh.GetSocketLocation(P.DriverBone);
                FHitResult Surface;
                // Accumulate sub-millimetre movement until a sweep is worthwhile.
                // Test the travelled segment, independent of capsule lag in XY.
                if ((Hip-P.LastSafeHip).SizeSquared()>0.0625f)
                {
                    // Include the next physics step while dragging, so a thin
                    // bench can oppose the pull before the pelvis crosses it.
                    FVector End=Hip;
                    if (Grips>0) End+= (P.Mesh.GetPhysicsLinearVelocity(P.DriverBone)*Math::Clamp(Delta,0.0f,0.04f)).GetClampedToMaxSize(24.0f);
                    if (HipCrossedSupport(P.Target,P.LastSafeHip,End,Surface))
                    {
                        BodyUnsafeSteps+=1;
                        DownedBodies[I].CrossedFloor=Surface.Component;
                        DownedBodies[I].FloorPoint=Surface.ImpactPoint;
                        DownedBodies[I].FloorNormal=Surface.ImpactNormal.GetSafeNormal();
                        DownedBodies[I].FloorUntil=Now+0.4f;
                    }
                    DownedBodies[I].LastSafeHip=Hip;
                    if (!P.FollowBlocked || (Hip-P.BlockedFollowHip).SizeSquared()>1.0f)
                    {
                        FVector Anchor;
                        bool Clear=HipFloorCenter(P.Target,Hip,Anchor) &&
                            (!P.HasSafeCapsule || (Anchor-P.SafeCapsule).SizeSquared()<80.0f*80.0f) &&
                            CapsulePathClear(P.Target,P.HasSafeCapsule?P.SafeCapsule:Anchor,Anchor);
                        DownedBodies[I].FollowBlocked=!Clear;
                        DownedBodies[I].BlockedFollowHip=Hip;
                        if (Clear)
                        {
                            DownedBodies[I].SafeCapsule=Anchor;
                            DownedBodies[I].AnchorHalfHeight=P.Target.CapsuleComponent.GetScaledCapsuleHalfHeight();
                            DownedBodies[I].HasSafeCapsule=true;
                        }
                    }
                }
                if (Now<DownedBodies[I].FloorUntil && IsValid(DownedBodies[I].CrossedFloor))
                {
                    FVector N=DownedBodies[I].FloorNormal;
                    FVector D=Hip-DownedBodies[I].FloorPoint;
                    float Depth=float(-D.DotProduct(N));
                    if (Depth>-3.0f && Depth<80.0f && (D+N*Depth).SizeSquared()<40.0f*40.0f)
                    {
                        FVector V=P.Mesh.GetPhysicsLinearVelocity(P.DriverBone);
                        float Outward=Depth>0.0f ? Math::Clamp(Depth*14.0f+8.0f,10.0f,200.0f) :
                            Math::Min(0.0f,(Depth+2.0f)/Math::Max(Delta,0.008f));
                        if (V.DotProduct(N)<Outward)
                        {
                            P.Mesh.SetPhysicsLinearVelocity(V+N*(Outward-V.DotProduct(N)),false,P.DriverBone);
                            DownedPlaneCorrections+=1;
                        }
                    }
                }
            }
            if (Grips > 0 && !FullPhysics && IsValid(Move) && Move.UpdatedComponent == P.Target.RootComponent)
            {
                Pull /= float(Grips); Pull.Z = 0.0f;
                float Distance = Pull.Size();
                FVector Want = Pull.GetSafeNormal()*Math::Clamp((Distance-4.0f)*2.2f, 0.0f, 55.0f);
                FVector Speed = P.DragVelocity + (Want-P.DragVelocity)*(1.0f-Math::Exp(-6.0f*Delta));
                DownedBodies[I].DragVelocity = Speed;
                if (Speed.SizeSquared() > 0.04f || Math::Abs(Turn) > 0.01f)
                {
                    FFindFloorResult Floor;
                    Move.FindFloor(P.Target.GetActorLocation(), Floor);
                    if (Floor.bBlockingHit && Floor.bWalkableFloor)
                    {
                        FVector N = Floor.HitResult.ImpactNormal.GetSafeNormal();
                        FVector Step = (Speed - N * Speed.DotProduct(N))*Delta;
                        // Probe the destination floor as well, so a low ledge
                        // cannot leave a kinematic, unconscious actor suspended.
                        FFindFloorResult Next;
                        Move.FindFloor(P.Target.GetActorLocation()+Step, Next);
                        if (Next.bBlockingHit && Next.bWalkableFloor && Math::Abs(Next.FloorDist-Floor.FloorDist)<4.0f)
                        {
                            FHitResult Hit;
                            FRotator Rotation = P.Target.GetActorRotation();
                            Rotation.Yaw += Math::Clamp(Turn/float(Grips), -1.0f, 1.0f)*22.0f*Delta;
                            if (SupportedBodyStep(P.Target,Move,Step))
                            {
                                DownedBodies[I].SafeCapsule=P.Target.GetActorLocation();
                                DownedBodies[I].AnchorHalfHeight=P.Target.CapsuleComponent.GetScaledCapsuleHalfHeight();
                                DownedBodies[I].HasSafeCapsule=true;
                                Move.MoveUpdatedComponent(Step, Rotation, Hit, true, false);
                            }
                        }
                    }
                }
            }
            else DownedBodies[I].DragVelocity = FVector::ZeroVector;
            if (!DownedBodies.IsValidIndex(I) || DownedBodies[I].Target != P.Target || !OwnDownedPose(P.Target,P.Mesh)) continue;
            if (Touching && Now >= P.NextVoice && !P.Target.CharacterState.IsSpeaking())
            {
                DownedBodies[I].NextVoice = Now+8.0f;
                auto Voice = P.Target.CharacterState.Voiceline;
                if (!IsValid(Voice)) continue;
                FGenericVoicelineRequestContext Context;
                FGameplayTag Line = GameplayTag::Sound_Voice_Reaction_Flee_Human;
                if (Voice.HasVoicelineForWithContext(Line, Hero.CharacterState, Context))
                    Voice.SayVoicelineWithContext(Line, Hero.CharacterState, Context, EPerceptionNoiseLoudness::Loud);
            }
        }
    }

    void BodyTick(float Delta)
    {
        float Now = GetGameTimeSinceCreation();
        for (int I = 0; I < Hands.Num(); I++)
        {
            auto Input = Hands[I];
            auto Target = Input.Target;
            bool Active = Ready() && Now - Input.Time < 0.15f && IsValid(Target) &&
                IsValid(Target.CharacterState) && IsValid(Target.Mesh) && Target != Hero &&
                Target.GetWorld() == GetWorld() && !Target.IsPlayerControlled();
            if (Active && ((Input.Goal - Input.Point).Size() > 110.0f ||
                (((Target.IsDead() || Target.IsDefeated()) ? Input.Point : Target.GetActorLocation()) - Hero.GetActorLocation()).Size() > 350.0f)) Active = false;
            if (I < 2 && (!Active || !Input.Grip || Held[I] != Target)) ReleaseHand(I);
            if (!Active) continue;
            bool Corpse = Target.IsDead();
            bool Down = !Corpse && Target.IsDefeated();
            if (Down && (I == 2 || !OwnDownedPose(Target,Target.Mesh))) { if (I<2) ReleaseHand(I); continue; }
            bool Recovering = false;
            for (int J = 0; !Corpse && J < LiveContacts.Num(); J++)
                if (LiveContacts[J].Target == Target && LiveContacts[J].RecoverUntil > Now) Recovering = true;
            if (Recovering && !Down) { if (I < 2) ReleaseHand(I); continue; }
            if (!Corpse && !Down && I < 2 && ((RecentPunch[0].Target == Target && Now - RecentPunch[0].Time < 0.65f) ||
                (RecentPunch[1].Target == Target && Now - RecentPunch[1].Time < 0.65f)))
            { ReleaseHand(I); continue; }
            BodyDead = Corpse; BodyDefeated = Target.IsDefeated(); BodyInputBone = Input.Bone;
            if (I == 2 && !Corpse) continue;
            float Pressure = Math::Clamp(-(Input.Goal - Input.Point).DotProduct(Input.Normal), 0.0f, 15.0f);
            if (I == 2) Pressure = 0.0f;
            bool Moving = Input.Velocity.Size() > 8.0f || Pressure > 0.5f;
            if (!Moving && !Input.Grip && !Down) continue;
            if (Down)
            {
                // Cached Lua contact can survive a stationary hand near the
                // surface. Only a grip or genuine movement renews a defeat.
                bool Acting=Input.Grip || Input.Velocity.SizeSquared()>64.0f;
                if (!Acting) continue;
                int Slot = BeginDowned(Target, Now);
                if (Slot < 0) continue;
                DownedBodies[Slot].LastTouch = Now;
                RefreshDownedRecovery(Target);
                if (Input.Grip) EnableDownedTorso(Target, Slot);
            }
            if (!Corpse && !Down && I < 2)
            {
                VoiceContactUntil = Now + 5.0f;
                Provoke(Target, I, Input.GripSerial);
            }
            auto Mesh = Target.Mesh;
            if (Corpse) WakeCorpseContact(Target, Input.Bone);
            bool NativeContact = !Corpse && !Down && I < 2 && LiveContactRagdoll(Target, Input, Pressure, I);
            bool Arm = !Corpse && !Down && !NativeContact && I < 2 && Now >= GripRetry[I] && DriveArm(I, Input);
            if (!Corpse && !Down && !NativeContact && I < 2) ReactToBodyContact(Target, Input, Pressure);
            if (Arm && !Target.IsSitting())
            {
                auto Move = Target.GetGothicMovementComponent();
                if (IsValid(Move))
                {
                    auto Traction = Input;
                    Traction.Point = Target.GetActorLocation() + ArmDrives[I].StartAnchor;
                    QueueBodyMotion(Target, Move, Traction, Pressure);
                }
            }
            if (!IsValid(Target) || !IsValid(Mesh)) continue;
            FName Bone = SimulatedBone(Mesh, Input.Bone);
            bool Equipment=Down && Input.Bone.ToString().StartsWith("weapon_holder");
            if (Down && I<2 && Input.Grip && Held[I]==Target && GripModes[I]==2)
                Bone=ArmDrives[I].DownedGripBone;
            else if (Down && I<2 && Input.Grip && Equipment && Target.IsHuman())
            {
                // Decorative sockets on an equipped back weapon can be closer
                // to the palm than the NPC's back. Test real torso bodies.
                Bone=n"None";
                TArray<FName> Back;
                Back.Add(n"pelvis"); Back.Add(n"spine_01"); Back.Add(n"spine_02"); Back.Add(n"spine_03");
                float Best=16.0f;
                for (FName Part : Back)
                {
                    if (Mesh.GetBoneIndex(Part)<0 || !Mesh.IsSimulatingPhysics(Part)) continue;
                    FVector OnBody;
                    float Distance=Mesh.GetClosestPointOnCollision(Input.Point,OnBody,Part);
                    if (Distance>=0.0f && Distance<Best) { Best=Distance; Bone=Part; }
                }
                if (Bone!=n"None") DownedGripRemaps+=1;
            }
            else if (Down && I<2 && Input.Grip && Bone==n"None")
            {
                FVector Closest,Normal; FName Near; float32 Distance;
                if (Mesh.GetClosestPointOnPhysicsAsset(Input.Point,Closest,Normal,Near,Distance) &&
                    (Closest-Input.Point).SizeSquared()<16.0f*16.0f && Mesh.IsSimulatingPhysics(Near))
                { Bone=Near; if (Held[I]!=Target) DownedGripRemaps+=1; }
            }
            bool Physical = Bone != n"None";
            BodyTarget = Target.GetPathName();
            BodyBone = Bone;
            if (I < 2 && Held[I] == Target && GripModes[I] != (Physical ? 2 : 1)) ReleaseHand(I);

            if (Physical)
            {
                if (Input.Grip && I < 2)
                {
                    auto H = Handle(I);
                    if (Held[I] == Target && H.GetGrabbedComponent() != Mesh) ReleaseHand(I);
                    if (Held[I] != Target)
                    {
                        if (Now < GripRetry[I]) { BodyStatus = "rigid_body_retry_wait"; continue; }
                        FVector GripPoint=Input.Point;
                        ArmDrives[I].DownedGripOffset=FVector::ZeroVector;
                        if (Down)
                        {
                            FVector Surface,SurfaceNormal;
                            FName NearBone;
                            float32 Distance;
                            if (Equipment)
                            {
                                if (Mesh.GetClosestPointOnCollision(Input.Point,Surface,Bone)>0.0f) GripPoint=Surface;
                            }
                            else if (Mesh.GetClosestPointOnPhysicsAsset(Input.Point,Surface,SurfaceNormal,NearBone,Distance) &&
                                (Surface-Input.Point).SizeSquared()<=16.0f*16.0f && Mesh.IsSimulatingPhysics(NearBone))
                            { Bone=NearBone; GripPoint=Surface; }
                            if ((Mesh.GetCenterOfMass(Bone)-GripPoint).SizeSquared()>32.0f*32.0f)
                            { BodyRejected+=1; BodyStatus="downed_grip_outside_body"; GripRetry[I]=Now+0.15f; continue; }
                            ArmDrives[I].DownedGripOffset=GripPoint-Input.Point;
                            ArmDrives[I].DownedGripBone=Bone;
                        }
                        H.GrabComponentAtLocation(Mesh, Bone, GripPoint);
                        // A request is not proof that Chaos created a grab constraint.
                        if (H.GetGrabbedComponent() != Mesh)
                        {
                            H.ReleaseComponent(); BodyStatus = "rigid_body_grab_rejected";
                            GripRetry[I] = Now + 0.5f; BodyRejected += 1; continue;
                        }
                        Held[I] = Target; GripModes[I] = 2; Grabs += 1; PhysicalGrabs += 1;
                        if (Arm || Down || Corpse) ArmDrives[I].HasHandleGoal = false;
                    }
                    // Clamp relative to the contact anchor, not the bone centre.
                    FVector Goal = Input.Point + (Input.Goal - Input.Point).GetClampedToMaxSize(35.0f);
                    if (Down) Goal+=ArmDrives[I].DownedGripOffset;
                    if (Arm || Down || Corpse)
                    {
                        FVector Last = ArmDrives[I].HasHandleGoal ? ArmDrives[I].HandleGoal : Input.Point;
                        FVector Step = Goal - Last;
                        float Rate = Step.SizeSquared() > 16.0f ? 48.0f : 22.0f;
                        if (Down || Corpse) { Rate = 22.0f; Step = Step.GetClampedToMaxSize(18.0f); }
                        Goal = Last;
                        if (Step.SizeSquared() > 0.0225f) Goal += Step * (1.0f - Math::Exp(-Rate * Delta));
                        ArmDrives[I].HandleGoal = Goal; ArmDrives[I].HasHandleGoal = true;
                    }
                    if ((Down || Corpse || NativeContact) && (Goal-Input.Point).SizeSquared()>0.25f)
                    {
                        if (Down)
                            for (int J=0; J<DownedBodies.Num(); J++)
                            {
                                auto Body=DownedBodies[J];
                                if (Body.Target!=Target || !IsValid(Body.CrossedFloor) || Now>=Body.FloorUntil) continue;
                                FVector Offset=Goal-Body.FloorPoint;
                                float NormalGap=float(Offset.DotProduct(Body.FloorNormal));
                                if (NormalGap<2.5f && (Offset-Body.FloorNormal*NormalGap).SizeSquared()<40.0f*40.0f)
                                    Goal+=Body.FloorNormal*(2.5f-NormalGap);
                            }
                        TArray<EObjectTypeQuery> Types;
                        Types.Add(EObjectTypeQuery::WorldStatic); Types.Add(EObjectTypeQuery::WorldDynamic);
                        if (Down) Types.Add(UCollisionProfile::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));
                        TArray<AActor> Ignore; Ignore.Add(Target); Ignore.Add(Hero);
                        FHitResult Wall;
                        if (System::SphereTraceSingleForObjects(Input.Point,Goal,2.5f,Types,false,Ignore,EDrawDebugTrace::None,Wall,true))
                        {
                            FVector Normal=Wall.Normal.GetSafeNormal();
                            if (Wall.bStartPenetrating)
                            {
                                FVector Offset=Goal-Input.Point;
                                Goal-=Normal*Math::Min(0.0f,Offset.DotProduct(Normal));
                            }
                            else Goal=Wall.Location+Normal*0.25f;
                            ArmDrives[I].HandleGoal=Goal;
                        }
                    }
                    H.SetTargetLocation(Goal);
                    BodyStatus = "native_rigid_body_grab";
                }
                else
                {
                    FVector ContactVelocity = Input.Velocity.GetClampedToMaxSize(160.0f);
                    float Approach = Math::Max(0.0f, -ContactVelocity.DotProduct(Input.Normal));
                    FVector Force = -Input.Normal * (Approach * 260.0f + Pressure * 1200.0f);
                    Mesh.AddForceAtLocation((Force * StrengthScale).GetClampedToMaxSize(95000.0f), Input.Point, Bone);
                    PushFrames += 1; BodyStatus = "native_rigid_body_push";
                }
            }
            else
            {
                if (Down)
                {
                    if (Input.Grip) { Held[I]=Target; GripModes[I]=1; GripTime[I]=Now; }
                    BodyStatus = "downed_ground_contact"; continue;
                }
                if (NativeContact || Target.HasGameplayTag(GameplayTag::State_Ragdoll))
                {
                    if (I < 2) ReleaseHand(I);
                    BodyStatus = "awaiting_native_physics"; continue;
                }
                auto Movement = Target.GetGothicMovementComponent();
                // No synthetic ragdoll on corpses without active native bodies.
                if (Corpse || Target.IsDefeated() || !IsValid(Movement))
                {
                    if (I < 2) ReleaseHand(I);
                    BodyStatus = "no_active_physics_body"; BodyRejected += 1; continue;
                }

                if (Input.Grip && !Target.IsSitting() && !QueueBodyMotion(Target, Movement, Input, Pressure))
                {
                    if (I < 2) ReleaseHand(I);
                    continue;
                }
                if (Input.Grip && Held[I] != Target) { Held[I] = Target; GripModes[I] = 1; Grabs += 1; }
                if (!Input.Grip) PushFrames += 1;
            }
            if (I < 2)
            {
                if (Input.Grip && Held[I] == Target) GripTime[I] = Now;
            }
        }
    }

    UFUNCTION(BlueprintOverride)
    void Tick(float DeltaSeconds)
    {
        FurniturePose = false;
        InteractionOwnsMovement = false;
        DownedPose = false;
        if (!OwnerWorldAvailable())
        {
            WeaponCommand = 0;
            VRFistsDrawn = false;
            ConsumeSwampweedSampleAt = -1.0f;
            if (ConsumeStatus == 0) ClearConsumeRequest();
            CleanupOnRebind = true;
            return;
        }
        if (CleanupOnRebind)
        {
            CleanupOnRebind = false;
            // Restore only after the owner is valid in this world again.
            Enabled = false;
            SuspendOwner();
            OwnerSuspended = true;
            return;
        }
        // The bed menu can suppress combat input while the interaction is still active.
        if (!Hero.IsDead() && IsValid(Hero.CharacterState) && GetGameTimeSinceCreation() - Heartbeat < 0.3f)
        {
            FurniturePose = Hero.CharacterState.HasGameplayTag(GameplayTag::Action_Interact_Sit) ||
                Hero.CharacterState.HasGameplayTag(GameplayTag::Action_Bed) ||
                Hero.CharacterState.HasGameplayTag(GameplayTag::Action_Crafting) ||
                Hero.CharacterState.HasGameplayTag(GameplayTag::Action_Open_Door) ||
                Hero.CharacterState.HasGameplayTag(GameplayTag::Action_Open_Container);
            DownedPose = Hero.IsDefeated() || Hero.HasGameplayTag(GameplayTag::State_Ragdoll);
            InteractionOwnsMovement = FurniturePose || DownedPose || Hero.CharacterState.IsDoingAnyInteraction();
        }
        if (!Ready())
        {
            WeaponCommand = 0;
            VRFistsDrawn = false;
            if (!OwnerSuspended) SuspendOwner();
            OwnerSuspended = true;
            return;
        }
        OwnerSuspended = false;
        if (LuteAudience.Requested || !LuteAudience.Listeners.IsEmpty() || LuteAudience.TriedAsset)
            LuteAudience.Tick(Hero, GetGameTimeSinceCreation(), DeltaSeconds);
        UpdateWeaponToggle();
        auto ChainBridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (ChainBridge.VRChainOwner == Hero) SampleVRChainFocus(ChainBridge);
        if (FocusNameRequest != 0) ResolveFocusName();
        LocalWood.Tick(Hero, GetGameTimeSinceCreation(), this);
        BowReleaseTick();
        if (VRCrossbow.Phase != 0 || !VRCrossbow.Flying.IsEmpty() || IsValid(VRCrossbow.FastMontage))
            VRCrossbow.Tick(Hero, GetGameTimeSinceCreation(), InteractionOwnsMovement || Hero.IsDefeated() || Hero.IsInConversation());
        TorchContactTick();
        ObserveCombatVoices();
        ConsumptionTick();
        if (ConsumeSwampweedSampleAt >= 0.0f && GetGameTimeSinceCreation() >= ConsumeSwampweedSampleAt)
        {
            ConsumeSwampweedSampleAt = -1.0f;
            ConsumeSwampweedAfter = GetVRSwampweedLevel();
        }
        float Delta = Math::Clamp(DeltaSeconds, 0.0f, 0.05f);
        if (GrassPending)
        {
            GrassPending = false;
            if (Ready() && IsValid(GrassController) && GrassController.GetWorld() == GetWorld() && IsValid(GrassData))
            {
                if (GrassTickMarker.IsBound())
                {
                    GrassDispatchWindow = true;
                    GrassMarkerRuns += 1;
                    GrassTickMarker.ExecuteIfBound();
                    GrassDispatchWindow = false;
                    if (GrassAcknowledged == GrassRequests) GrassDispatches += 1;
                }
            }
        }
        if (ImpactPending)
        {
            ImpactPending = false;
            if (Ready() && IsValid(EnvironmentHit.Component) && IsValid(EnvironmentHit.GetPhysMaterial()) &&
                IsValid(EnvironmentHit.Component.Owner) && EnvironmentHit.Component.Owner.GetWorld() == GetWorld() &&
                IsValid(Hero.GetFXComponent()) && IsValid(Hero.CarryComponent) && IsValid(Hero.CarryComponent.ItemVisual) &&
                IsValid(Hero.CarryComponent.EquippedItemDefinition))
            {
                LastImpact = GetGameTimeSinceCreation();
                // The deflected definition sets both FMOD switches (source weapon and
                // target material) and inherits the surface particle selection.
                TSoftObjectPtr<UFMODEvent> Sound;
                Hero.GetFXComponent().PlayEffectWithHitResult(GameplayTag::FX_Attack_Hit_Environment_Deflected, EnvironmentHit, Sound);
                WorldImpactCalls += 1;
            }
        }
        if (Ready())
        {
            float Now = GetGameTimeSinceCreation();
            if (Now >= NextStrengthSample)
            {
                float Strength = Math::Max(0.0f, Hero.CharacterState.GetStrengthAttribute(10.0f));
                StrengthScale = 0.86f + 0.014f * Strength;
                NextStrengthSample = Now + 0.25f;
            }
            WarmTime += Delta;
            if (WarmTime >= 1.0f)
            {
                WarmTime = 0.0f;
                PrepareVRFinishingVariant();
                WarmRecovery();
                for (int I = BowFlights.Num() - 1; I >= 0; I--)
                    if (BowFlights[I].Expires < Now || !IsValid(BowFlights[I].Arrow)) BowFlights.RemoveAt(I);
            }
            auto Movement = Hero.GetGothicMovementComponent();
            if (Now >= WaterProbeTime)
            {
                WaterDiving = Hero.IsDiving();
                SwimmingPose = WaterDiving || Hero.IsSwimming();
                float WaterDepth = IsValid(Movement) ? Movement.GetWaterDepth() : 0.0f;
                Wet = SwimmingPose || WaterDepth > 5.0f;
                HasWadingSurface = !SwimmingPose && Wet && IsValid(Movement) && IsValid(Hero.CapsuleComponent) &&
                    WaterDepth <= Movement.GetWalkToSwimHeight() + 12.0f;
                if (HasWadingSurface)
                    WadingSurfaceZ = Hero.CapsuleComponent.GetWorldLocation().Z - Hero.CapsuleComponent.GetScaledCapsuleHalfHeight() + WaterDepth;
                WaterProbeTime = Now + (Wet ? 0.05f : 0.18f);
            }
            if (!SwimmingPose || !IsValid(Movement) || Now - SwimTime >= 0.15f ||
                Hero.IsDefeated() || Hero.HasGameplayTag(GameplayTag::State_Ragdoll))
            {
                HasSwimFloor = false;
                NextSwimFloorSample = Now;
            }
            else if (Now >= NextSwimFloorSample)
            {
                FFindFloorResult Bottom;
                Movement.FindFloor(Hero.GetActorLocation(), Bottom);
                HasSwimFloor = Bottom.bBlockingHit && Bottom.bWalkableFloor && !Bottom.HitResult.bStartPenetrating &&
                    Bottom.HitResult.ImpactNormal.Z >= 0.65f;
                CapsuleOnSwimFloor = HasSwimFloor && (Bottom.bLineTrace ? Bottom.LineDist : Bottom.FloorDist) <= 3.0f;
                if (HasSwimFloor)
                {
                    SwimFloorPoint = FVector(Bottom.HitResult.ImpactPoint.X, Bottom.HitResult.ImpactPoint.Y, Bottom.HitResult.ImpactPoint.Z);
                    SwimFloorNormal = FVector(Bottom.HitResult.ImpactNormal.X, Bottom.HitResult.ImpactNormal.Y, Bottom.HitResult.ImpactNormal.Z);
                }
                NextSwimFloorSample = Now + 0.10f;
            }
            if (IsValid(Movement) && SwimmingPose && Now - SwimTime < 0.15f &&
                !Hero.IsDefeated() && !Hero.HasGameplayTag(GameplayTag::State_Ragdoll))
            {
                FVector Current = Hero.GetVelocity();
                SwimSpeed = Current.Size();
                FVector Planar = FVector(Current.X, Current.Y, 0.0f);
                float MeasuredSpeed = Planar.Size();
                float GlideSpeed = SwimPlanarGoal.Size();
                float Span = Math::Clamp(Delta, 0.0f, 0.05f);
                if (SwimForce.Size() > 12.0f)
                {
                    // A new stroke can brake the old direction as well as
                    // accelerate along the replacement heading.
                    float CatchUp = 1050.0f + Math::Max(0.0f, GlideSpeed - 170.0f) * 3.0f;
                    FVector Correction = ((SwimPlanarGoal - Planar) * 12.0f).GetClampedToMaxSize(CatchUp);
                    float Limit = Math::Max(175.0f, GlideSpeed);
                    Planar = (Planar + Correction * Span).GetClampedToMaxSize(Math::Max(Limit, MeasuredSpeed));
                }
                else if (GlideSpeed > 1.0f && SwimLastSample > 0.0f)
                {
                    FVector Heading = SwimPlanarGoal / GlideSpeed;
                    float Along = Planar.DotProduct(Heading);
                    // Only soften native drag during recovery. A stopped
                    // capsule against a wall must not launch on release.
                    if (Along > 1.0f && MeasuredSpeed > 1.0f)
                    {
                        float ChangeAlong = Math::Clamp((GlideSpeed - Along) * 8.0f, 0.0f, 360.0f) * Span;
                        Planar = (Planar + Heading * ChangeAlong).GetClampedToMaxSize(Math::Max(MeasuredSpeed, SwimLastPlanarSpeed));
                    }
                }
                SwimLastPlanarSpeed = MeasuredSpeed;
                float Height = Hero.GetActorLocation().Z;
                float Step = Now - SwimLastSample;
                float Travel = Height - SwimLastHeight;
                if (Step > 0.001f && Step <= 0.1f && Math::Abs(Travel) < 35.0f)
                {
                    // Velocity can disagree with actual travel during the
                    // surface/dive transition. Only learn the passive drift;
                    // a wall or the surface must not wind up a thrust boost.
                    float Follow = 1.0f - Math::Exp(-8.0f * Step);
                    SwimObservedZ += (Travel / Step - SwimObservedZ) * Follow;
                    if (Math::Abs(SwimVerticalGoal + 5.0f) < 3.0f && !(HasSwimFloor && CapsuleOnSwimFloor))
                        SwimVerticalTrim = Math::Clamp(SwimVerticalTrim + (SwimVerticalGoal - SwimObservedZ) * Step * 2.4f, -36.0f, 36.0f);
                    else
                        SwimVerticalTrim *= Math::Exp(-6.0f * Step);
                }
                else { SwimVerticalTrim = 0.0f; SwimObservedZ = Current.Z; }
                SwimLastHeight = Height;
                SwimLastSample = Now;
                // Correct bounded speed error even during a stroke. This
                // term has no memory when the capsule is pressed into a floor.
                float StrokeCorrection = Math::Clamp((SwimVerticalGoal - SwimObservedZ) * 0.58f, -32.0f, 32.0f);
                float Vertical = Math::Clamp(SwimVerticalGoal + SwimVerticalTrim + StrokeCorrection, -155.0f, 155.0f);
                // Let the game settle at the air interface after surfacing.
                if (!WaterDiving && Now - EyeTime < 0.15f && EyeDepth < -5.0f && Vertical > 0.0f)
                    Vertical = Math::Min(Vertical, 15.0f);
                float MaxChange = 1600.0f * Math::Clamp(Delta, 0.0f, 0.05f);
                Vertical = Math::Clamp(Vertical, Current.Z-MaxChange, Current.Z+MaxChange);
                FVector Change = FVector(Planar.X, Planar.Y, Vertical) - Current;
                if (Change.Size() > 0.01f) Movement.AddImpulse(Change, true);
                if (SwimForce.Size() > 1.0f) SwimFrames += 1;
            }
            else { SwimLastSample = -1000.0f; }
        }
        else { Wet = false; SwimmingPose = false; WaterDiving = false; HasWadingSurface = false; }
        SwimVisionTick(Delta);
        PouchTick();
        FinishTick(Delta);
        if (!MeleeHits.IsEmpty()) MeleeTick();
        FinishWitnessTick();
        RecoveryTick();
        FistTick();
        ArmTick(Delta);
        BodyTick(Delta);
        LandingTick();
        DownedTick(Delta);
        GetupWatchTick();
        DownedRecoveryTick(false);
        BodyLeanTick(Delta);
        BodyMotionTick(Delta);
        ProvocationTick();
    }

    // Lua publishes the pose. The game Tick queries only local characters for this equipped spell.
    void SampleVRChainFocus(UGothicVRInventoryBridge Bridge)
    {
        if (!Bridge.HasVRChainView(Hero)) { Bridge.ClearVRChainView(); return; }
        float Now = Hero.GetGameTimeSinceCreation();
        if (Bridge.VRChainSample >= 0.0f && Now - Bridge.VRChainSample < 0.075f) return;
        Bridge.VRChainSample = Now; Bridge.VRChainTarget = nullptr;
        auto Nearby = UNearbyActorsSubsystem::Get();
        auto Spell = UGA_CastSpell_ChainLightning.GetDefaultObject();
        if (!IsValid(Nearby) || !IsValid(Spell)) return;
        float Range = Spell.GetTraceRangeFromConfig_Scriptable();
        auto Actors = Nearby.FindActorsOfClassInRadius2D(AGothicCharacter::StaticClass(), Hero.GetActorLocation(), Range);
        float Best = -1.0f;
        float BestDistance = Range + 1.0f;
        for (auto Actor : Actors)
        {
            auto NPC = Cast<AGothicCharacter>(Actor);
            if (!IsValid(NPC) || NPC == Hero || NPC.IsDead() || !IsValid(NPC.CharacterState) ||
                !IsValid(NPC.GetGothicAbilitySystemComponent()) ||
                NPC.GetActorLocation().Distance(Hero.GetActorLocation()) > Range) continue;
            FVector Center = NPC.GetActorLocation();
            for (int I = 0; I < 2; I++)
            {
                FVector Point = Center;
                if (I == 1)
                {
                    if (!IsValid(NPC.Mesh) || !NPC.Mesh.DoesSocketExist(n"head")) continue;
                    Point = NPC.Mesh.GetSocketLocation(n"head");
                }
                float Distance = Point.Distance(Bridge.VRChainEye);
                float Score = GothicVRChainSight::Rank(Bridge, Point, Range);
                if (Score < 0.0f || Score < Best || (Score == Best && Distance >= BestDistance)) continue;
                if (!GothicVRChainSight::Visible(Hero, NPC, Bridge.VRChainEye, Point)) continue;
                if (!Spell.IsTargetValid_Script(Hero, NPC)) continue;
                Best = Score; BestDistance = Distance; Bridge.VRChainTarget = NPC;
            }
        }
    }

    void SuspendOwner()
    {
        LandingActors.Empty(); NextLandingScan=0.0f;
        DownedRecoveryTick(true);
        for (int I = DownedBodies.Num()-1; I >= 0; I--) EndDowned(I);
        GetupWatches.Empty();
        LuteAudience.Clear(OwnerWorldAvailable() ? Hero : nullptr);
        QueueFocusName(0, nullptr, nullptr);
        FocusStyledOutput = nullptr;
        ClearVRTorchProbe(0); ClearVRTorchProbe(1);
        ConsumeSwampweedSampleAt = -1.0f;
        CombatVoiceWindow = false; VoiceContactUntil = -1.0f; NearbySpeaking = 0;
        ClearPouch();
        if (ConsumeStatus == 0) ClearConsumeRequest();
        GrassPending = false;
        ImpactPending = false;
        HasPreviousBlade = false;
        GuardMoving = false;
        BladeTime = -1000.0f;
        GuardRaised = -1000.0f;
        GuardLeftArm = false; GuardRightArm = false; GuardArmsTime = -1000.0f;
        IncomingFists.Reset();
        GuardLeftHand = false; GuardRightHand = false;
        Wet = false;
        SwimmingPose = false;
        WaterDiving = false;
        HasWadingSurface = false;
        WaterProbeTime = -1.0f;
        HasSwimFloor = false;
        NextSwimFloorSample = 0.0f;
        SwimForce = FVector::ZeroVector;
        SwimPlanarGoal = FVector::ZeroVector;
        SwimTime = -1000.0f;
        SwimLastSample = -1000.0f;
        SwimVerticalTrim = 0.0f;
        SwimVisionTick(0.0f);
        BodyLeanTick(0.0f);
        for (int I = 0; I < ArmDrives.Num(); I++)
        {
            auto T = ArmDrives[I].Target;
            bool Restore = IsValid(T) && T.GetWorld() == GetWorld() && IsValid(T.CharacterState) &&
                IsValid(T.Mesh) && T.Mesh == ArmDrives[I].Mesh && !T.IsDead() &&
                !T.HasGameplayTag(GameplayTag::State_Ragdoll) && !T.IsDefeated();
            EndArm(I, Restore);
        }
        for (int I = 0; I < Held.Num(); I++) ReleaseHand(I);
        for (int I = 0; I < BodyMotions.Num(); I++) ClearBodyMotion(I);
        FGothicVRBodyInput Empty;
        for (int I = 0; I < Hands.Num(); I++) Hands[I] = Empty;
        PendingHandImpacts.Empty();
        PendingFistBounties.Empty();
        HandDefeats.Empty();
        for (int I = 0; I < FistHits.Num(); I++)
        {
            FistHits[I] = Empty;
            RecentPunch[I] = Empty;
            PushTravel[I] = 0.0f;
        }
        VRFinishingPending.Empty();
        MeleeHits.Empty();
        BowFlights.Empty();
        VRCrossbow.Reset();
        if (OwnerWorldAvailable()) LocalWood.SuspendProps();
        LocalWood.Clear();
        LastWoodPart = nullptr;
        VRWoodMesh = n"None";
        VRWoodInstance = -1;
        VRWoodApproximate = false;
        ClearBowRelease();
        if (!PendingDeathReports.IsEmpty())
        {
            WitnessRevision += 1;
            WitnessEligible = PendingDeathReports.Last().Witnesses.Num();
            WitnessDelivered = 0;
            WitnessOutcome = "reset";
            PendingDeathReports.Empty();
        }
        LiveContacts.Empty();
        CorpseContacts.Empty();
        Provocations.Empty();
    }

    UFUNCTION(BlueprintOverride)
    void EndPlay(EEndPlayReason Reason)
    {
        Enabled = false;
        if (Reason != EEndPlayReason::Destroyed) return;
        if (!OwnerWorldAvailable()) return;
        if (!OwnerSuspended) SuspendOwner();
    }

    // One stock human reaction is resolved per warm-up call, never loaded on impact.
    void PrepareVRFinishingVariant()
    {
        if (VRFinishingWarmIndex >= 10) return;
        FGameplayTagContainer HitTags;
        HitTags.AddTag(GameplayTag::Combat_HitType_Riposte);
        UAnimMontage Montage;
        int VariantIndex = VRFinishingWarmIndex;
        VRFinishingWarmIndex += 1;
        switch (VariantIndex)
        {
            case 0: Montage = UHitData_Default_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 1: Montage = UHitData_S1H_Tr_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 2: Montage = UHitData_S2H_Tr_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 3: Montage = UHitData_Fists_Tr_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 4: Montage = UHitData_Bow_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 5: Montage = UHitData_Crossbow_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 6: Montage = UHitData_A2H_Tr_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 7: Montage = UHitData_M2H_Tr_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 8: Montage = UHitData_Sff2H_Tr_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
            case 9: Montage = UHitData_Rune_Human.GetDefaultObject().GetDeathFromDefeatedAnimMontage(HitTags); break;
        }
        if (IsValid(Montage) && Montage.GetPathName().StartsWith("/Game/AnimLibrary/Humanoid/Man/Items/") && !VRFinishingMontages.Contains(Montage)) VRFinishingMontages.Add(Montage);
        if (VRFinishingWarmIndex == 10 && VRFinishingPending.IsEmpty()) VRFinishingStatus = "ready";
    }


}
