struct FVRSceneryCursor
{
    TWeakObjectPtr<ULevelStreaming> Stream;
    TWeakObjectPtr<ULevel> Level;
    TWeakObjectPtr<AActor> Owner;
    TArray<TWeakObjectPtr<USceneComponent>> Trail;
    TArray<int> Child;
    int ActorIndex = 0;
}

struct FVRSceneryEntry
{
    TWeakObjectPtr<UStaticMeshComponent> Part;
    TWeakObjectPtr<ULevelStreaming> Stream;
    bool Streamed = false;
}

struct FVRScenery
{
    UPROPERTY() TArray<UStaticMeshComponent> Nearby;
    TArray<FVRSceneryEntry> Cache;
    FVRSceneryCursor Persistent;
    TArray<FVRSceneryCursor> Streams;
    TWeakObjectPtr<UWorld> World;
    int NextStream = 0;
    float NextDiscovery = -1.f;
    float NextPublish = -1.f;
    float NextWork = -1.f;
    FVector LastWorkAt;

    void Clear()
    {
        Nearby.Reset(); Cache.Reset(); Streams.Reset();
        FVRSceneryCursor Empty;
        Persistent = Empty; World = nullptr;
        NextStream = 0; NextDiscovery = -1.f; NextPublish = -1.f; NextWork = -1.f;
    }

    float DistanceSquared(USceneComponent Part, FVector Eye) const
    {
        auto Bounds = Part.GetBounds();
        FVector D = Eye - Bounds.Origin;
        FVector E = Bounds.BoxExtent;
        return FVector(Math::Max(0.0, Math::Abs(D.X)-E.X), Math::Max(0.0, Math::Abs(D.Y)-E.Y),
            Math::Max(0.0, Math::Abs(D.Z)-E.Z)).SizeSquared();
    }

    void Remember(USceneComponent Node, ULevelStreaming Stream, FVector Eye)
    {
        auto Part = Cast<UStaticMeshComponent>(Node);
        if (!IsValid(Part) || !IsValid(Part.StaticMesh) || !Part.IsVisible() ||
            DistanceSquared(Part, Eye) > 2400.f * 2400.f ||
            GothicVRSurface::WoodKind(Part.StaticMesh) == 0) return;
        auto Instances = Cast<UInstancedStaticMeshComponent>(Part);
        if (IsValid(Instances) && Instances.GetInstancesOverlappingSphere(Eye, 360.f, true).IsEmpty()) return;
        int Slot = -1;
        float Farthest = DistanceSquared(Part, Eye);
        for (int I = 0; I < Cache.Num(); I++)
        {
            auto Other = Cache[I].Part.Get();
            if (Other == Part) return;
            if (Cache.Num() < 96) continue;
            if (!IsValid(Other)) { Slot = I; break; }
            float D = DistanceSquared(Other, Eye);
            if (D > Farthest) { Farthest = D; Slot = I; }
        }
        FVRSceneryEntry Entry;
        Entry.Part = Part; Entry.Stream = Stream; Entry.Streamed = IsValid(Stream);
        if (Cache.Num() < 96) Cache.Add(Entry);
        else if (Slot >= 0) Cache[Slot] = Entry;
    }

    void PushNode(FVRSceneryCursor& Cursor, USceneComponent Node)
    {
        TWeakObjectPtr<USceneComponent> Weak = Node;
        Cursor.Trail.Add(Weak); Cursor.Child.Add(-1);
    }

    // Actor slots, including nulls, and each child visit/pop cost one step.
    // ActorIndex is independent of the search position and survives walking.
    bool Advance(FVRSceneryCursor& Cursor, ULevel Level, ULevelStreaming Stream, FVector Eye, int Budget)
    {
        for (int Step = 0; Step < Budget; Step++)
        {
            int Depth = Cursor.Trail.Num()-1;
            if (Depth >= 0)
            {
                auto Node = Cursor.Trail[Depth].Get();
                if (!IsValid(Node) || !IsValid(Cursor.Owner.Get()) || Node.GetOwner() != Cursor.Owner.Get() ||
                    Cursor.Child[Depth] >= Node.GetNumChildrenComponents())
                {
                    Cursor.Trail.RemoveAt(Depth); Cursor.Child.RemoveAt(Depth);
                    continue;
                }
                if (Cursor.Child[Depth] < 0)
                {
                    Remember(Node, Stream, Eye);
                    Cursor.Child[Depth] = 0;
                    continue;
                }
                int Index = Cursor.Child[Depth];
                Cursor.Child[Depth] += 1;
                auto Child = Node.GetChildComponent(Index);
                if (Depth < 15 && IsValid(Child) && Child.GetOwner() == Cursor.Owner.Get())
                    PushNode(Cursor, Child);
                continue;
            }
            // GetActors returns a const reference. Avoid a copy of every actor.
            if (Cursor.ActorIndex >= Level.GetActors().Num()) return true;
            auto Owner = Level.GetActors()[Cursor.ActorIndex];
            Cursor.ActorIndex += 1;
            if (!IsValid(Owner) || Owner.IsHidden() || !IsValid(Owner.RootComponent) ||
                IsValid(Cast<APawn>(Owner)) || DistanceSquared(Owner.RootComponent, Eye) > 3000.f * 3000.f) continue;
            Cursor.Owner = Owner;
            PushNode(Cursor, Owner.RootComponent);
        }
        return false;
    }

    void Discover(UWorld W)
    {
        // Unlike GetActors, the public binding returns this list by value.
        // Keep weak references to at most twelve already-visible levels.
        auto Handles = W.GetStreamingLevels();
        if (NextStream >= Handles.Num()) NextStream = 0;
        int Budget = Math::Min(64, Handles.Num());
        for (int I = 0; I < Budget && Streams.Num() < 12; I++)
        {
            auto S = Handles[NextStream];
            NextStream = (NextStream + 1) % Handles.Num();
            if (!IsValid(S) || !S.IsLevelVisible() || !IsValid(S.GetLoadedLevel())) continue;
            bool Known = false;
            for (int J = 0; J < Streams.Num(); J++)
            {
                if (Streams[J].Stream.Get() == S) { Known = true; break; }
            }
            if (Known) continue;
            FVRSceneryCursor Cursor;
            Cursor.Stream = S; Cursor.Level = S.GetLoadedLevel();
            Streams.Add(Cursor);
        }
    }

    void Tick(AGothicCharacter Hero, float Now)
    {
        if (!IsValid(Hero) || !IsValid(Hero.GetWorld())) { Clear(); return; }
        auto W = Hero.GetWorld();
        if (World.Get() != W || Persistent.Level.Get() != W.PersistentLevel)
        {
            Clear(); World = W; Persistent.Level = W.PersistentLevel;
        }
        FVector Eye = Hero.GetActorLocation();
        // Only discovery is paced. Registered contact surfaces still sweep at
        // hand tracking rate, including when the player stands perfectly still.
        float Moved = (Eye-LastWorkAt).SizeSquared();
        if (Now < NextWork && Moved < 35.f*35.f) return;
        NextWork = Now + ((Moved > 3.f*3.f) ? 0.032f : 0.060f);
        LastWorkAt = Eye;
        if (IsValid(W.PersistentLevel) && Advance(Persistent, W.PersistentLevel, nullptr, Eye, 16))
            Persistent.ActorIndex = 0;
        if (Now >= NextDiscovery && Streams.Num() < 12)
        {
            NextDiscovery = Now + 0.20f;
            Discover(W);
        }
        // Share a fixed 48 steps between all occupied streaming cursors.
        int PerLevel = int(48.0f / Math::Max(1, Streams.Num()));
        for (int I = Streams.Num()-1; I >= 0; I--)
        {
            auto S = Streams[I].Stream.Get();
            auto L = Streams[I].Level.Get();
            if (!IsValid(S) || !IsValid(L) || !S.IsLevelVisible() || S.GetLoadedLevel() != L ||
                Advance(Streams[I], L, S, Eye, PerLevel)) Streams.RemoveAt(I);
        }
        if (Now < NextPublish) return;
        NextPublish = Now + 0.075f;
        Nearby.Reset();
        for (int I = Cache.Num()-1; I >= 0; I--)
        {
            auto Part = Cache[I].Part.Get();
            auto S = Cache[I].Stream.Get();
            if (!IsValid(Part) || !IsValid(Part.GetOwner()) || Part.GetWorld() != W ||
                (Cache[I].Streamed && (!IsValid(S) || !S.IsLevelVisible() || S.GetLoadedLevel() != Part.GetOwner().GetLevel())))
            { Cache.RemoveAtSwap(I); continue; }
            float D = DistanceSquared(Part, Eye);
            if (D > 3000.f * 3000.f) { Cache.RemoveAtSwap(I); continue; }
            if (D <= 360.f * 360.f && Part.IsVisible() && !Part.GetOwner().IsHidden()) Nearby.Add(Part);
        }
    }
}
