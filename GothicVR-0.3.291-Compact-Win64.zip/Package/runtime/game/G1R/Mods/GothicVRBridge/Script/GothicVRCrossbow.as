// Owns references to stock crossbow projectiles. Inventory, hit effects,
// muzzle speed and reload animation stay with GA_ArcheryCrossbow.
struct FGothicVRCrossbowBolt
{
    UPROPERTY() AArrowVisual Bolt;
    UPROPERTY() UWeaponDefinition Weapon;
    bool ContactSeen = false;
    bool Assist = false;
    bool Homing = false;
    float Until = 0.0f;

    bool NearImpact(UWeaponDefinition SourceWeapon, FVector Point) const
    {
        return Weapon == SourceWeapon && IsValid(Bolt) && IsValid(Bolt.m_MovementComp) &&
            !IsValid(Bolt.GetAttachParentActor()) && Bolt.m_MovementComp.IsActive() &&
            Bolt.m_MovementComp.Velocity.SizeSquared() > 10000.0f &&
            (Bolt.GetActorLocation() - Point).SizeSquared() < 45.0f * 45.0f;
    }

    void FreeAim()
    {
        if (!IsValid(Bolt) || !IsValid(Bolt.m_MovementComp)) return;
        if (Bolt.m_AimingAssistanceData.m_enableAimingAssistance)
        {
            Assist = true;
            Bolt.m_AimingAssistanceData.m_enableAimingAssistance = false;
        }
        if (Bolt.m_MovementComp.bIsHomingProjectile)
        {
            Homing = true;
            Bolt.m_MovementComp.bIsHomingProjectile = false;
        }
    }

    void Restore()
    {
        if (!IsValid(Bolt) || !IsValid(Bolt.m_MovementComp)) return;
        if (Assist) Bolt.m_AimingAssistanceData.m_enableAimingAssistance = true;
        if (Homing) Bolt.m_MovementComp.bIsHomingProjectile = true;
    }
}

struct FGothicVRCrossbowShot
{
    UPROPERTY() UCrossbowComponent Component;
    UPROPERTY() AArcheryWeaponVisual Visual;
    UPROPERTY() UWeaponDefinition Definition;
    UPROPERTY() FGothicVRCrossbowBolt Current;
    UPROPERTY() TArray<FGothicVRCrossbowBolt> Flying;
    FVector Origin;
    FVector TriggerOrigin;
    FVector Axis;
    UPROPERTY() USceneComponent PresentedRail;
    FVector LocalNock;
    FVector RailUp;
    float Deadline = 0.0f;
    int Phase = 0;  // 1 armed, 2 released, 3 prime only
    bool NotchIssued = false;
    int Serial = 0;
    UPROPERTY() int IssuedSerial = 0;
    UPROPERTY() int ReleaseDelayMs = -1;
    UPROPERTY() int ShootClipMs = -1;
    UPROPERTY() bool UsedReadyQuickState = false;
    UPROPERTY() int StateAtTrigger = -1;
    UPROPERTY() AArrowVisual NockedAtTrigger;
    UPROPERTY() int FlightDelayMs = -1;
    UPROPERTY() float LaunchNockErrorCm = -1.0f;
    UPROPERTY() float MaxRailAngleDeg = 0.0f;
    UPROPERTY() float StockLaunchAngleDeg = -1.0f;
    UPROPERTY() float AppliedLaunchAngleDeg = -1.0f;
    UPROPERTY() int SpeedSerial = 0;
    UPROPERTY() int FlightsStarted = 0;
    UPROPERTY() int TimedOutPhase = 0;
    UPROPERTY() int StateAtClose = -1;
    UPROPERTY() AArrowVisual LastLaunched;
    UPROPERTY() int ClipBoosts = 0;
    UPROPERTY() int ReboundSerial = 0;
    UPROPERTY() UAnimInstance FastAnim;
    UPROPERTY() UAnimMontage FastMontage;
    float OriginalRate = 1.0f;
    float FastRate = 1.0f;
    int FastSerial = 0;
    float PressedAt = 0.0f;
    UPROPERTY() int Releases = 0;
    UPROPERTY() float LastSpeed = 0.0f;
    UPROPERTY() FString Status = "idle";

    void RestoreRate()
    {
        if (IsValid(FastAnim) && IsValid(FastMontage) && FastAnim.Montage_IsPlaying(FastMontage) &&
            Math::Abs(FastAnim.Montage_GetPlayRate(FastMontage) - FastRate) < 0.001f)
            FastAnim.Montage_SetPlayRate(FastMontage, OriginalRate);
        FastAnim = nullptr; FastMontage = nullptr;
    }

    void AdvanceMontage(AGothicCharacter Hero, float Now)
    {
        if (Phase == 0 && !IsValid(FastMontage)) return;
        auto Montage = Hero.GetCurrentMontage();
        if (IsValid(FastMontage) && Montage != FastMontage) RestoreRate();
        if (Phase == 0 || !IsValid(Montage) || !IsValid(Hero.Mesh)) return;
        if (FastMontage == Montage)
        {
            // The engine can restart the same asset for the next shot and
            // reset its rate. Re-arm only at the start of a later release.
            if (Phase != 2 || FastSerial == Serial || !IsValid(FastAnim) ||
                FastAnim.Montage_GetPosition(Montage) > 0.15f ||
                Math::Abs(FastAnim.Montage_GetPlayRate(Montage) - OriginalRate) > 0.001f) return;
            RestoreRate();
        }
        const FString Clip = Montage.GetName().ToString();
        if (!(Clip.StartsWith("Man_Crossbow_N_") || Clip.StartsWith("Man_Crossbow_STL_"))) return;
        bool Reload = Clip.Contains("_Reload_") && (Clip.Contains("_Relax_") || Clip.Contains("_Aim_") || Clip.Contains("_QuickShoot_"));
        bool Shoot = Clip.Contains("_Aim_Shoot_") || Clip.Contains("_QuickShoot_Shoot_");
        if (!Reload && !Shoot) return;
        auto Anim = Hero.Mesh.GetAnimInstance();
        if (!IsValid(Anim) || !Anim.Montage_IsPlaying(Montage)) return;
        float Rate = Anim.Montage_GetPlayRate(Montage);
        if (Rate <= 0.0f || Rate > 3.0f) return;
        FastAnim = Anim; FastMontage = Montage; OriginalRate = Rate; FastSerial = Serial;
        if (Shoot && Phase == 2 && ShootClipMs < 0) ShootClipMs = int((Now - PressedAt) * 1000.0f + 0.5f);
        float ShootRate = Phase == 2 ? 7.0f : 5.0f;
        FastRate = Rate * (Reload ? 8.0f : ShootRate);
        Anim.Montage_SetPlayRate(Montage, FastRate);
        ClipBoosts += 1;
    }

    void Close(const FString&in Outcome)
    {
        if (Outcome != "flying" && Outcome != "primed" && Outcome != "impacted_before_redirect") RestoreRate();
        Current.Restore();
        FGothicVRCrossbowBolt Empty;
        Current = Empty;
        NockedAtTrigger = nullptr;
        Component = nullptr;
        Visual = nullptr;
        Definition = nullptr;
        PresentedRail = nullptr;
        Phase = 0;
        Status = Outcome;
    }

    void Reset()
    {
        RestoreRate();
        LastLaunched = nullptr;
        Close("cancelled");
        for (int I = 0; I < Flying.Num(); I++) Flying[I].Restore();
        Flying.Empty();
    }

    bool Equipped(AGothicCharacter Hero) const
    {
        if (!IsValid(Hero) || !IsValid(Component) || !IsValid(Visual) || Component.GetOwner() != Hero ||
            !IsValid(Definition) || !Definition.GetItemType().MatchesTag(GameplayTag::Item_Weapon_Crossbow)) return false;
        auto Carry = Hero.GetCarryComponent();
        return IsValid(Carry) && Carry.GetEquippedItemDefinition() == Definition &&
               Carry.GetItemVisual() == Visual && Component.GetBowOrCrossbowWeapon() == Visual;
    }

    bool HasFreshNotch(AGothicCharacter Hero) const
    {
        if (!Visual.HasArrowNotched()) return false;
        auto Arrow = Component.GetCurrentArrow();
        if (!IsValid(LastLaunched) || Arrow != LastLaunched) return true;
        auto Parent = Arrow.GetAttachParentActor();
        return (Parent == Hero || Parent == Visual) && IsValid(Arrow.m_MovementComp) &&
            Arrow.m_MovementComp.Velocity.SizeSquared() <= 100.0f;
    }

    bool FromEarlierFlight(AActor Projectile) const
    {
        if (Projectile == LastLaunched) return true;
        for (auto Flight : Flying)
            if (Projectile == Flight.Bolt) return true;
        return false;
    }

    int Arm(AGothicCharacter Hero, UCrossbowComponent EquippedComponent, FVector Muzzle, FVector Forward, float Now, bool Prime = false)
    {
        bool ContinuePrime = Phase == 3 && EquippedComponent == Component && !Prime;
        if ((Phase != 0 && !ContinuePrime) || !IsValid(EquippedComponent) || EquippedComponent.GetOwner() != Hero ||
            !IsValid(Hero.GetCarryComponent()) || !(Forward.SizeSquared() >= 0.0001f) ||
            !((Muzzle - Hero.GetActorLocation()).SizeSquared() <= 240.0f * 240.0f)) return 0;
        Component = EquippedComponent;
        Visual = Component.GetBowOrCrossbowWeapon();
        Definition = Cast<UWeaponDefinition>(Hero.GetCarryComponent().GetEquippedItemDefinition());
        if (!Equipped(Hero)) { Close("unavailable"); return 0; }
        if (!ContinuePrime && !HasFreshNotch(Hero) && !Component.IsNotchingArrowOntoBow() &&
            UGothicVRInventoryBridge.GetDefaultObject().CountVRItem(Hero, UItAm_Bolt::StaticClass()) <= 0)
        { Close("no_bolt"); return 0; }
        TriggerOrigin = Muzzle; Origin = Muzzle; Axis = Forward.GetSafeNormal(); RailUp = FVector::ZeroVector;
        Serial += 1; Phase = Prime ? 3 : 1;
        if (!ContinuePrime) NotchIssued = false;
        Deadline = Now + (Prime ? 1.5f : 0.60f);
        PressedAt = Now; ReleaseDelayMs = -1; ShootClipMs = -1; FlightDelayMs = -1; TimedOutPhase = 0; StateAtClose = -1;
        LaunchNockErrorCm = -1.0f;
        MaxRailAngleDeg = 0.0f; StockLaunchAngleDeg = -1.0f; AppliedLaunchAngleDeg = -1.0f;
        UsedReadyQuickState = false;
        StateAtTrigger = -1;
        Status = Prime ? "priming" : "queued";
        return Serial;
    }

    void Tick(AGothicCharacter Hero, float Now, bool BlockInput)
    {
        for (int I = Flying.Num() - 1; I >= 0; I--)
        {
            auto Arrow = Flying[I].Bolt;
            if (IsValid(Arrow) && IsValid(Arrow.m_MovementComp) && !IsValid(Arrow.GetAttachParentActor()) &&
                Arrow.m_MovementComp.IsActive() && Arrow.m_MovementComp.Velocity.SizeSquared() > 100.0f && Now < Flying[I].Until) continue;
            Flying[I].Restore();
            Flying.RemoveAt(I);
        }
        if (BlockInput || (Phase != 0 && !Equipped(Hero))) RestoreRate();
        else AdvanceMontage(Hero, Now);
        if (Phase == 0) return;
        // Axis was captured at the trigger edge. Follow small translations of
        // the displayed nock while the stock montage starts; a later turn or
        // an equipment pose reset cannot steer the committed shot.
        if (Phase != 3 && IsValid(PresentedRail) && PresentedRail.GetWorld() == Hero.GetWorld())
        {
            FTransform Pose = PresentedRail.GetWorldTransform();
            FVector Nock = Pose.TransformPosition(LocalNock);
            FVector Direction = Pose.TransformVector(FVector(0,0,1)).GetSafeNormal();
            if (Direction.SizeSquared() > 0.99f)
            {
                float Alignment = Math::Clamp(Axis.DotProduct(Direction), -1.0f, 1.0f);
                MaxRailAngleDeg = Math::Max(MaxRailAngleDeg, float(Math::RadiansToDegrees(Math::Acos(Alignment))));
                if (Alignment >= 0.985f && (Nock - TriggerOrigin).SizeSquared() <= 15.0f * 15.0f)
                { Origin = Nock; RailUp = Pose.TransformVector(FVector(-1,0,0)).GetSafeNormal(); }
            }
        }
        if (Now > Deadline)
        {
            TimedOutPhase = Phase;
            if (IsValid(Component) && IsValid(Visual))
                StateAtClose = (Component.IsNotchingArrowOntoBow() ? 1 : 0) +
                    (Visual.HasArrowNotched() ? 2 : 0) + (Component.IsWaitingToFinishRelease() ? 4 : 0);
            // Cancel a stock notify only if the exact bolt we committed is
            // still on this weapon and the corresponding VR montage is playing.
            if (Phase == 2 && Equipped(Hero) && IsValid(FastMontage) && Hero.GetCurrentMontage() == FastMontage &&
                IsValid(Current.Bolt) && Component.GetCurrentArrow() == Current.Bolt &&
                (Current.Bolt.GetAttachParentActor() == Hero || Current.Bolt.GetAttachParentActor() == Visual) &&
                IsValid(Current.Bolt.m_MovementComp) && Current.Bolt.m_MovementComp.Velocity.SizeSquared() <= 100.0f)
            {
                auto StaleClip = FastMontage;
                RestoreRate();
                Component.ServerSetWantContinueQuickRelease(false);
                Hero.StopAnimMontage(StaleClip);
                Component.ChangeState(EArcheryState::Interrupted);
            }
            RestoreRate();
            Close("timed_out"); return;
        }
        if (Phase == 1 || Phase == 3)
        {
            if (BlockInput || !Equipped(Hero))
            { Close("cancelled"); return; }
            if (Phase == 1 && (Origin - Hero.GetActorLocation()).SizeSquared() > 240.0f * 240.0f)
            { Close("muzzle_out_of_reach"); return; }
            // Do not mark another animation's notch as our own command. If
            // it settles empty, the same physical load still gets one attempt.
            if (Component.IsNotchingArrowOntoBow()) return;
            if (!HasFreshNotch(Hero))
            {
                if (!NotchIssued)
                {
                    NotchIssued = true; Status = "notching";
                    Component.ChangeState(Component.IsWaitingToFinishRelease() ?
                        EArcheryState::NotchArrowOntoBowFromQuickRelease : EArcheryState::NotchArrowOntoBowFromRelax);
                }
                return;
            }
            auto Arrow = Cast<ACrossBowBoltProjectileVisual>(Component.GetCurrentArrow());
            if (!IsValid(Arrow) || !IsValid(Arrow.m_MovementComp) || Arrow.GetWorld() != Hero.GetWorld() ||
                Arrow.m_MovementComp.Velocity.SizeSquared() > 100.0f) return;
            auto Parent = Arrow.GetAttachParentActor();
            if (Parent != Hero && Parent != Visual && (IsValid(Parent) ||
                (Arrow.GetOwner() != Hero && Arrow.GetOwner() != Visual))) return;
            if (!IsValid(Parent) && (Arrow.GetActorLocation() - Visual.GetActorLocation()).SizeSquared() > 10000.0f) return;
            if (Arrow == LastLaunched && (Parent == Hero || Parent == Visual)) LastLaunched = nullptr;
            if (Phase == 3) { Close("primed"); return; }
            if (Component.IsAiming() && !Component.IsSecureToFire()) return;
            Current.Bolt = Arrow; Current.Weapon = Definition; Current.FreeAim();
            IssuedSerial = Serial; ReleaseDelayMs = int((Now - PressedAt) * 1000.0f + 0.5f);
            Phase = 2; Deadline = Now + 0.75f; Releases += 1; Status = "released";
            if (Component.IsAiming()) Component.OnReleaseBowStringOrCrossbow();
            else if (StateAtTrigger == int(EArcheryState::BowInHandNotchedRelaxed) && Arrow == NockedAtTrigger && Now - PressedAt <= 0.12f &&
                (Parent == Hero || Parent == Visual) && !Component.IsWaitingToFinishRelease())
            {
                // The manual load has already seated this exact stock bolt.
                // Enter the stock quick-shot montage without its raise-to-aim
                // wait. Only that montage's release notify launches the bolt.
                UsedReadyQuickState = true;
                Component.ChangeState(EArcheryState::QuickReleaseBowString);
            }
            else Component.OnQuickReleaseBowString();
            // Some ability paths start the shooting montage synchronously.
            // Catch that first animation update without issuing another shot.
            if (Phase == 2 && Equipped(Hero)) AdvanceMontage(Hero, Now);
            return;
        }
        auto Bolt = Current.Bolt;
        // The animation may exchange its notched representation for a
        // different stock actor. Only the proved current crossbow's new,
        // detached, flying, locally owned projectile can inherit this release.
        if (Equipped(Hero) && (!IsValid(Bolt) || !IsValid(Bolt.m_MovementComp) ||
            IsValid(Bolt.GetAttachParentActor()) || Bolt.m_MovementComp.Velocity.SizeSquared() < 10000.0f))
        {
            auto Actual = Cast<ACrossBowBoltProjectileVisual>(Component.GetCurrentArrow());
            if (IsValid(Actual) && Actual != Bolt && !FromEarlierFlight(Actual) && Actual.GetWorld() == Hero.GetWorld() &&
                !IsValid(Actual.GetAttachParentActor()) && (Actual.GetOwner() == Hero || Actual.GetOwner() == Visual) &&
                IsValid(Actual.m_MovementComp) && Actual.m_MovementComp.IsActive() &&
                Actual.m_MovementComp.Velocity.SizeSquared() >= 10000.0f &&
                (Actual.GetActorLocation() - Origin).SizeSquared() < 420.0f * 420.0f)
            {
                Current.Restore();
                FGothicVRCrossbowBolt Fresh;
                Current = Fresh;
                Current.Bolt = Actual; Current.Weapon = Definition; Bolt = Actual;
                ReboundSerial = Serial;
            }
        }
        if (!IsValid(Bolt) || !IsValid(Bolt.m_MovementComp)) { Close("lost_bolt"); return; }
        Current.FreeAim();
        auto Parent = Bolt.GetAttachParentActor();
        if (IsValid(Parent))
        {
            if (Parent != Hero && Parent != Visual) Close("impacted_before_redirect");
            return;
        }
        if (!Bolt.m_MovementComp.IsActive()) return;
        float Speed = Bolt.m_MovementComp.Velocity.Size();
        if (Speed < 100.0f) return;
        // A changed or stopped stock projectile must never be relaunched.
        LastSpeed = Speed;
        StockLaunchAngleDeg = Math::RadiansToDegrees(Math::Acos(Math::Clamp(Axis.DotProduct(Bolt.m_MovementComp.Velocity.GetSafeNormal()), -1.0f, 1.0f)));
        FlightDelayMs = int((Now - PressedAt) * 1000.0f + 0.5f);
        SpeedSerial = Serial;
        LastLaunched = Bolt;
        Bolt.SetActorRotation(RailUp.SizeSquared() > 0.99f ? FRotator::MakeFromXZ(Axis, RailUp) : Axis.Rotation());
        if (Phase != 2 || !IsValid(Bolt) || Current.Bolt != Bolt || IsValid(Bolt.GetAttachParentActor())) return;
        // Align the stock mesh's nock (LOD0 X = -0.65576 cm). Root or
        // collision component origin need not coincide with the mesh pivot.
        FVector RootAtLaunch = Origin;
        if (IsValid(Bolt.m_MeshComp))
            RootAtLaunch += Bolt.GetActorLocation() - Bolt.m_MeshComp.GetWorldTransform().TransformPosition(FVector(-0.6557617f,0,0));
        Bolt.SetActorLocation(RootAtLaunch);
        // Moving to the tracked rail can synchronously dispatch a hit.
        if (Phase != 2 || !IsValid(Bolt) || Current.Bolt != Bolt || IsValid(Bolt.GetAttachParentActor()) ||
            !IsValid(Bolt.m_MovementComp) || !Bolt.m_MovementComp.IsActive()) return;
        if (IsValid(Bolt.m_MeshComp))
            LaunchNockErrorCm = (Bolt.m_MeshComp.GetWorldTransform().TransformPosition(FVector(-0.6557617f,0,0)) - Origin).Size();
        Bolt.SetVelocity(Axis * Speed);
        Bolt.m_MovementComp.Velocity = Axis * Speed;
        AppliedLaunchAngleDeg = Math::RadiansToDegrees(Math::Acos(Math::Clamp(Axis.DotProduct(Bolt.m_MovementComp.Velocity.GetSafeNormal()), -1.0f, 1.0f)));
        Current.Until = Now + 15.0f;
        Flying.Add(Current);
        FlightsStarted += 1;
        FGothicVRCrossbowBolt Empty;
        Current = Empty;
        Close("flying");
    }
}

// Collision may precede our observation of movement (e.g. point blank).
// Consume the pending redirect, then let the original impact finish once.
UCLASS(meta=(ReplaceParentClass))
class ACrossBowBoltProjectileVisual_GothicVR : ACrossBowBoltProjectileVisual
{
    void RecordVRBoltContact(AActor HitActor)
    {
        auto Runtime = UGothicVRInventoryBridge.GetDefaultObject().Runtime;
        if (!IsValid(Runtime)) return;
        Runtime.ObserveCrossbowContact(this, HitActor);
        if (Runtime.VRCrossbow.Phase == 2 && Runtime.VRCrossbow.Current.Bolt == this)
        {
            if (Runtime.VRCrossbow.StockLaunchAngleDeg < 0.0f && IsValid(m_MovementComp) && m_MovementComp.Velocity.SizeSquared() > 10000.0f)
                Runtime.VRCrossbow.StockLaunchAngleDeg = Math::RadiansToDegrees(Math::Acos(Math::Clamp(
                    Runtime.VRCrossbow.Axis.DotProduct(m_MovementComp.Velocity.GetSafeNormal()), -1.0f, 1.0f)));
            Runtime.VRCrossbow.LastLaunched = this;
            Runtime.VRCrossbow.Close("impacted_before_redirect");
        }
    }

    UFUNCTION(BlueprintOverride)
    bool CanAttachArrowOnHitActor_Scriptable(AActor HitActor, float SurfaceHardness)
    {
        RecordVRBoltContact(HitActor);
        return Super::CanAttachArrowOnHitActor_Scriptable(HitActor, SurfaceHardness);
    }

    UFUNCTION(BlueprintOverride)
    bool HasBouncingWhenHit_Scriptable(AActor HitActor, float SurfaceHardness)
    {
        RecordVRBoltContact(HitActor);
        return Super::HasBouncingWhenHit_Scriptable(HitActor, SurfaceHardness);
    }
}
