// Admission and revalidation use the same facts while the audience is active.
bool VRLuteCanInterrupt(AGothicCharacter N, AGothicCharacter Hero)
{
    if (!IsValid(Hero) || !IsValid(Hero.GetWorld()) || !IsValid(N) || N == Hero ||
        N.GetWorld() != Hero.GetWorld() || !IsValid(N.CharacterState) || !IsValid(N.Mesh) ||
        !N.IsHuman() || N.IsDead() || N.IsDefeated() ||
        N.HasGameplayTag(GameplayTag::State_Ragdoll) || N.HasGameplayTag(GameplayTag::State_PartOfCinematic)) return false;

    // State_Smalltalk spans the listener's silent intervals. Smalltalk_Offering
    // only advertises willingness to talk during a routine.
    if (N.IsInCombat() || N.IsInConversation() ||
        N.HasGameplayTag(GameplayTag::State_Smalltalk) ||
        N.HasGameplayTag(GameplayTag::State_AmbientConversation)) return false;

    if (N.HasGameplayTag(GameplayTag::Action_Crafting_Cook) ||
        N.HasGameplayTag(GameplayTag::Action_Ambient_Cook) ||
        N.HasGameplayTag(GameplayTag::Action_Ambient_FillCauldron) ||
        N.HasGameplayTag(GameplayTag::Action_Ambient_RoastScavenger)) return false;

    // AbilityTask_Interaction_Human uses these four character montages for the
    // pan, cauldron and spit. The ordinary campfire task uses other assets.
    auto Active = N.GetCurrentMontage();
    if (!IsValid(Active)) return true;
    FName Clip = Active.GetName();
    return Clip != n"Man_Digger_Cook_Pan_Montage" && Clip != n"Woman_Campfire_Montage" &&
        Clip != n"Man_Interact_Cauldron_Montage" && Clip != n"Man_Digger_Cook_Rotisserie_Montage";
}
