struct FGothicVRMeleeHit
{
    UPROPERTY() AActor Target;
    UPROPERTY() UWeaponMeleeDefinition Weapon;
    UPROPERTY() FHitResult Sweep;
    UPROPERTY() FGameplayTag Attack;
    UPROPERTY() float Time;
}

struct FGothicVRFinishingHit
{
    UPROPERTY() AGothicCharacter Hero;
    UPROPERTY() AGothicCharacter Target;
    UPROPERTY() UAnimMontage Montage;
    UPROPERTY() float Time = 0.0f;
    UPROPERTY() float Duration = 0.0f;
    UPROPERTY() int Phase = 0;
    UPROPERTY() bool ImmediateFinish = false;
    UPROPERTY() TArray<AGothicCharacter> Witnesses;
}

// Typed inventory access and explicit VR consumption/bowl support.
class UGothicVRInventoryBridge : UObject
{
    UPROPERTY() AGothicVRRuntime Runtime;
    // Read the same displayed entries and soft icon references as W_Inventory_Slot.
    // These UI queries never load an asset or change the player's inventory.
    UFUNCTION(BlueprintCallable)
    TArray<UUserWidget> GetVRInventoryEntries(UListView List) const
    {
        if (IsValid(List)) return List.GetDisplayedEntryWidgets();
        TArray<UUserWidget> Empty;
        return Empty;
    }

    UFUNCTION(BlueprintPure)
    UTexture2D GetVRResidentInventoryIcon(UInventorySlotData Data) const
    {
        if (!IsValid(Data) || Data.m_IsEmpty || Data.m_Amount < 1) return nullptr;
        return Data.m_IconPath.Get();
    }
    UFUNCTION(BlueprintCallable)
    int GetVRHeroStatus(AActor Player) const
    {
        auto Pawn = Cast<AGothicCharacter>(Player);
        if (!IsValid(Pawn) || !IsValid(Pawn.CharacterState) || !IsValid(Pawn.Mesh) || !IsValid(Pawn.GetWorld())) return 0;
        return Pawn.IsDead() ? 2 : 1;
    }
    UFUNCTION(BlueprintCallable)
    void SetVRRuntime(AGothicVRRuntime Value) { Runtime = Value; }
    UFUNCTION(BlueprintCallable)
    int GetVRFinishingVariantCount() const { return IsValid(Runtime) ? Runtime.VRFinishingMontages.Num() : 0; }
    UFUNCTION(BlueprintCallable)
    FString GetVRFinishingStatus() const { return IsValid(Runtime) ? Runtime.VRFinishingStatus : "runtime_missing"; }
    UFUNCTION(BlueprintCallable)
    FString GetVRFinishingMontage() const { return IsValid(Runtime) ? Runtime.VRFinishingMontage : ""; }
    UFUNCTION(BlueprintCallable)
    bool IsVRFinishingTarget(AActor Victim)
    {
        auto Target = Cast<AGothicCharacter>(Victim);
        return IsValid(Target) && IsValid(Target.CharacterState) && Target.IsDefeated() && !Target.IsDead();
    }
    // Reflection entry only enqueues data. GAS/montages run from the actor's native Tick.
    UFUNCTION(BlueprintCallable)
    int TryVRFinishingHit(AActor Attacker, AActor Victim)
    {
        return IsValid(Runtime) ? Runtime.QueueFinisher(Attacker, Victim) : 2;
    }
    // Legacy entry points deliberately have no gameplay side effects.
    UFUNCTION(BlueprintCallable)
    void PrepareVRFinishingVariant() {}
    UFUNCTION(BlueprintCallable)
    void TickVRFinishingHits(AActor Owner, float DeltaSeconds) {}

    UFUNCTION(BlueprintCallable)
    int GetVRBridgeVersion() const { return 285; }
    UFUNCTION(BlueprintCallable)
    int GetVRMagicLaunchCount() const { return VRMagicLaunchCount; }

    UFUNCTION(BlueprintCallable)
    int GetVRMagicHookCount() const { return VRMagicHookCount; }
    UPROPERTY() int VRMagicHookCount = 0;
    UPROPERTY() AActor VRMagicOwner;
    UPROPERTY() FVector VRMagicOrigin;
    UPROPERTY() FVector VRMagicTarget;
    UPROPERTY() AActor VRChainOwner;
    UPROPERTY() AGothicCharacter VRChainTarget;
    FVector VRChainEye;
    FVector VRChainForward;
    FVector VRChainRight;
    float VRChainHalfX;
    float VRChainHalfY;
    float VRChainTime = -1.0f;
    float VRChainSample = -1.0f;
    UPROPERTY() int VRChainCasts = 0;
    UPROPERTY() FString VRChainLastTarget;
    UFUNCTION(BlueprintCallable)
    void ClearVRChainView()
    {
        VRChainOwner = nullptr; VRChainTarget = nullptr; VRChainTime = -1.0f; VRChainSample = -1.0f;
    }
    UFUNCTION(BlueprintCallable)
    void SetVRChainView(AActor Owner, FVector Eye, FVector Forward, FVector Right, float HalfX, float HalfY)
    {
        if (Owner != VRChainOwner) ClearVRChainView();
        if (!IsValid(Owner)) return;
        VRChainOwner = Owner; VRChainEye = Eye; VRChainForward = Forward.GetSafeNormal();
        VRChainRight = Right.GetSafeNormal(); VRChainHalfX = HalfX; VRChainHalfY = HalfY;
        VRChainTime = Owner.GetGameTimeSinceCreation();
    }
    bool HasVRChainView(AActor Owner) const
    {
        return IsValid(Owner) && Owner == VRChainOwner && HasVRMagicPose(Owner) &&
            Owner.GetGameTimeSinceCreation() - VRChainTime >= 0.0f && Owner.GetGameTimeSinceCreation() - VRChainTime < 0.20f;
    }
    UPROPERTY() int VRMagicLaunchCount = 0;
    UPROPERTY() int VRMagicSpawnCount = 0;
    UPROPERTY() int VRMagicEarlyStarts = 0;
    UPROPERTY() int VRMagicLateStarts = 0;
    UPROPERTY() FVector VRMagicStartBefore;
    UPROPERTY() FVector VRMagicStartExpected;
    UPROPERTY() FVector VRMagicStartAfter;
    UPROPERTY() float VRMagicStartAge = 0.0f;
    FVector GetVRProjectileSpawnOrigin()
    {
        VRMagicSpawnCount += 1;
        return VRMagicOrigin;
    }
    UPROPERTY() float VRMagicTime = -1000.0f;

    UFUNCTION(BlueprintCallable)
    void SetVRMagicPose(AActor Owner, FVector Origin, FVector Target)
    {
        VRMagicOwner = Owner;
        if (Owner == nullptr) { VRMagicTime = -1000.0f; ClearVRChainView(); return; }
        VRMagicOrigin = Origin; VRMagicTarget = Target;
        VRMagicTime = Owner.GetGameTimeSinceCreation();
    }
    bool HasVRMagicPose(AActor Owner) const
    {
        return Owner != nullptr && Owner == VRMagicOwner && Owner.GetGameTimeSinceCreation() - VRMagicTime >= 0.0f && Owner.GetGameTimeSinceCreation() - VRMagicTime < 0.2f;
    }
    FVector GetVRMagicOrigin(AActor Owner, FVector Fallback) const
    {
        return HasVRMagicPose(Owner) ? VRMagicOrigin : Fallback;
    }
    AActor VRSpellCaster(ASpellBallVisual_AS Projectile) const
    {
        if (!IsValid(Projectile) || !IsValid(VRMagicOwner) || Projectile.GetWorld() != VRMagicOwner.GetWorld()) return nullptr;
        AActor Owner = Projectile.GetOwner();
        APawn Instigator = Projectile.GetInstigator();
        // A non-player pawn on either field is authoritative even if another
        // system left the player on the other field of a recycled projectile.
        if ((Cast<APawn>(Owner) != nullptr && Owner != VRMagicOwner) ||
            (Instigator != nullptr && Instigator != VRMagicOwner)) return nullptr;
        if (HasVRMagicPose(Owner)) return Owner;
        if (HasVRMagicPose(Instigator)) return Instigator;
        return nullptr;
    }
    bool PlaceVRSpell(ASpellBallVisual_AS Projectile, bool Late, float Age)
    {
        if (VRSpellCaster(Projectile) == nullptr || Projectile.m_HasCollided) return false;
        VRMagicStartBefore = Projectile.GetActorLocation();
        VRMagicStartExpected = VRMagicOrigin;
        VRMagicStartAge = Age;
        Projectile.SetActorLocation(VRMagicStartExpected);
        VRMagicStartAfter = Projectile.GetActorLocation();
        if ((VRMagicStartAfter - VRMagicStartExpected).Size() > 1.0f) return false;
        if (Late) VRMagicLateStarts += 1;
        else VRMagicEarlyStarts += 1;
        return true;
    }
    void ApplyVRProjectileLaunch(ASpellBallVisual_AS Projectile, AActor Caster)
    {
        if (Projectile == nullptr || !HasVRMagicPose(Caster)) return;
        VRMagicLaunchCount++;
        auto Weapon = Projectile.GetWeaponDefinition();
        if (Weapon == nullptr) return;
        auto Definition = Cast<USpellProjectileDefinition>(Weapon.Get().GetDefaultObject());
        if (Definition == nullptr) return;
        // The ability spawned at the palm before BeginPlay. The hand can already
        // have moved when the projectile definition and game velocity become ready.
        FVector Direction = VRMagicTarget - Projectile.GetActorLocation();
        if (Direction.Size() < 1.0f) return;
        Direction.Normalize();
        Projectile.SetVelocity(Direction * Definition.m_Speed);
    }

    UFUNCTION(BlueprintCallable)
    bool ReleaseVRBow(UBowComponent Component)
    {
        if (Component == nullptr || Component.GetBowOrCrossbowWeapon() == nullptr) return false;
        if (Component.IsAiming() || Component.IsNotchingArrowOntoBow() || Component.IsWaitingToFinishRelease()) return false;
        if (Component.GetCurrentArrow() == nullptr) return false;
        Component.OnQuickReleaseBowString();
        return true;
    }

    UFUNCTION(BlueprintCallable)
    bool ConsumeVRItem(AGothicCharacter Character, TSubclassOf<UItemDefinition> Item)
    {
        if (Character == nullptr || Character.Inventory == nullptr)
            return false;
        return Character.Inventory.ConsumeItemOfKind(Item);
    }

    UFUNCTION(BlueprintCallable)
    int CountVRItem(AActor Actor, TSubclassOf<UItemDefinition> Definition)
    {
        auto Container = DataModule::GetContainerDataModule(Actor);
        if (Container == nullptr) return -1;
        int Count = 0;
        for (const auto& Item : Container.GetItemsInConst(EInventoryTypes::MainContainer))
            if (Item.m_SlotData.m_ItemDefinition == Definition) Count += Item.m_SlotData.m_ItemCount;
        for (const auto& Item : Container.GetItemsInConst(EInventoryTypes::QuickItems))
            if (Item.m_SlotData.m_ItemDefinition == Definition) Count += Item.m_SlotData.m_ItemCount;
        for (const auto& Item : Container.GetItemsInConst(EInventoryTypes::Pouch))
            if (Item.m_SlotData.m_ItemDefinition == Definition) Count += Item.m_SlotData.m_ItemCount;
        return Count;
    }

    UFUNCTION(BlueprintCallable)
    void EnableVRBowls()
    {
        UItFo_Soup.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        UItFo_Meatbugragout.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        UItFo_MushroomStew.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        UItFo_Crawlersoup.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        UItFo_DragonsbreathStew.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        UItFo_Meatbugsauteed.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        UItFo_Ottostew.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        UItFo_Rice.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        UItFo_SyraRecipe.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
        // The inventory uses this tag for the quick bar. The VR wheel checks
        // its own edible definitions before ever requesting consumption.
        UItMi_Lute.GetDefaultObject().AddItemSpec(GameplayTag::Item_Property_QuickConsumable);
    }

    UFUNCTION(BlueprintCallable)
    TSubclassOf<UItemDefinition> GetSlotItem(AActor Actor, int Kind, int Slot)
    {
        if (Actor == nullptr || Kind < 3 || Kind > 5)
            return nullptr;
        auto Container = DataModule::GetContainerDataModule(Actor);
        if (Container == nullptr)
            return nullptr;
        const auto& Items = Container.GetItemsInConst(EInventoryTypes(Kind));
        for (const auto& Item : Items)
        {
            if ((Kind != 5 || Item.m_Id == Slot) && Item.m_SlotData.m_ItemCount > 0)
                return Item.m_SlotData.m_ItemDefinition;
        }
        return nullptr;
    }

    UFUNCTION(BlueprintCallable)
    int GetSlotID(AActor Actor, int Kind, int Slot)
    {
        if (Actor == nullptr || Kind < 3 || Kind > 5)
            return -1;
        auto Container = DataModule::GetContainerDataModule(Actor);
        if (Container == nullptr)
            return -1;
        const auto& Items = Container.GetItemsInConst(EInventoryTypes(Kind));
        for (const auto& Item : Items)
        {
            if ((Kind != 5 || Item.m_Id == Slot) && Item.m_SlotData.m_ItemCount > 0)
                return Item.m_Id;
        }
        return -1;
    }
}
