UCLASS(meta=(ReplaceParentClass))
class UGE_Ex_Damage_GothicVRBow : UGE_Ex_Damage
{
    bool SetVRBowDraw(const FGameplayEffectCustomExecutionParameters& ExecutionParams,
                      FGameplayEffectContextHandle&out HitContext, float&out PreviousDraw) const
    {
        auto VR = UGothicVRInventoryBridge.GetDefaultObject().Runtime;
        if (!IsValid(VR)) return false;
        if (VR.BowFlights.IsEmpty() && VR.VRCrossbow.Phase != 2 && VR.VRCrossbow.Flying.IsEmpty()) return false;

        auto SourceASC = Cast<UGothicAbilitySystemComponent>(ExecutionParams.GetSourceAbilitySystemComponent());
        auto TargetASC = Cast<UGothicAbilitySystemComponent>(ExecutionParams.GetTargetAbilitySystemComponent());
        if (!IsValid(SourceASC) || !IsValid(TargetASC)) return false;
        auto Shooter = Cast<AGothicCharacter>(SourceASC.GetAvatar());
        auto Victim = Cast<AGothicCharacter>(TargetASC.GetAvatar());
        if (!IsValid(Shooter) || Shooter != VR.Hero || !Shooter.IsPlayerControlled() || !IsValid(Victim)) return false;

        HitContext = ExecutionParams.GetOwningSpec().GetContext();
        auto HitData = HitContext.GetHitContext();
        if (HitData.WeaponUsed == nullptr) return false;
        auto Weapon = Cast<UWeaponDefinition>(HitData.WeaponUsed.Get().GetDefaultObject());
        if (!IsValid(Weapon)) return false;
        FHitResult Impact;
        HitContext.GetHitResult(Impact);
        if (Weapon.GetItemType().MatchesTag(GameplayTag::Item_Weapon_Crossbow))
        {
            VR.ObserveCrossbowDamage(Weapon, HitContext.EffectCauser, Victim, Impact);
            return false;
        }
        if (!Weapon.GetItemType().MatchesTag(GameplayTag::Item_Weapon_Bow)) return false;
        PreviousDraw = HitData.BowStretch;
        float Draw = VR.ResolveBowDraw(Shooter, Weapon, HitContext.EffectCauser, Victim, Impact, PreviousDraw);
        if (Draw == PreviousDraw) return false;
        HitData.BowStretch = Draw;
        HitContext.SetHitContext(HitData);
        return true;
    }

    UFUNCTION(BlueprintOverride)
    void Execute(const FGameplayEffectCustomExecutionParameters& ExecutionParams, FGameplayEffectCustomExecutionOutput& OutExecutionOutput) const
    {
        FGameplayEffectContextHandle HitContext;
        float PreviousDraw = 0.0f;
        bool Changed = SetVRBowDraw(ExecutionParams, HitContext, PreviousDraw);
        Super::Execute(ExecutionParams, OutExecutionOutput);
        if (Changed)
        {
            // A copied handle shares this context. Preserve any other changes
            // made by the game or by the next override in the chain.
            auto HitData = HitContext.GetHitContext();
            HitData.BowStretch = PreviousDraw;
            HitContext.SetHitContext(HitData);
        }
    }
}
