// Damage execution is already inside the game's world context. Grant the stock
// guard only for a fresh geometric intersection, then restore the prior stance.
UCLASS(meta=(ReplaceParentClass))
class UGE_Ex_Damage_GothicVR : UGE_Ex_Damage
{
    float SegmentDistance(FVector A, FVector B, FVector C, FVector D) const
    {
        FVector U = B - A; FVector V = D - C; FVector W = A - C;
        float AA = U.DotProduct(U); float BB = U.DotProduct(V);
        float CC = V.DotProduct(V); float DD = U.DotProduct(W); float EE = V.DotProduct(W);
        if (AA < 1.0f || CC < 1.0f) return 10000.0f;
        float Denom = AA * CC - BB * BB;
        float S = Denom > 0.001f ? Math::Clamp((BB * EE - CC * DD) / Denom, 0.0f, 1.0f) : 0.0f;
        float T = Math::Clamp((BB * S + EE) / CC, 0.0f, 1.0f);
        S = Math::Clamp((BB * T - DD) / AA, 0.0f, 1.0f);
        return (A + U * S - C - V * T).Size();
    }

    bool ArmInTrace(FVector Elbow, FVector Wrist, FVector Start, FVector Stop, FVector HeroOrigin, float Radius) const
    {
        float Length = (Elbow - Wrist).Size();
        if (Length < 10.0f || Length > 65.0f || (Elbow - HeroOrigin).Size() > 165.0f ||
            (Wrist - HeroOrigin).Size() > 175.0f) return false;
        return SegmentDistance(Elbow, Wrist, Start, Stop) <= Radius;
    }

    int InterceptPart(AGothicVRRuntime Runtime, FVector Start, FVector Stop, bool Fist) const
    {
        FVector Origin = Runtime.Hero.GetActorLocation();
        float Pad = Fist ? 2.5f : 1.5f;
        if (Runtime.GuardLeftHand && (Runtime.GuardLeftPalmBase-Origin).Size() < 175.0f &&
            (Runtime.GuardLeftKnuckles-Runtime.GuardLeftPalmBase).SizeSquared() < 28.0f*28.0f &&
            SegmentDistance(Runtime.GuardLeftPalmBase, Runtime.GuardLeftKnuckles, Start, Stop) <= 4.5f+Pad) return 2;
        if (Runtime.GuardRightHand && (Runtime.GuardRightPalmBase-Origin).Size() < 175.0f &&
            (Runtime.GuardRightKnuckles-Runtime.GuardRightPalmBase).SizeSquared() < 28.0f*28.0f &&
            SegmentDistance(Runtime.GuardRightPalmBase, Runtime.GuardRightKnuckles, Start, Stop) <= 4.5f+Pad) return 2;
        float Radius = Fist ? 7.3f : 5.6f;
        if ((Runtime.GuardLeftArm && ArmInTrace(Runtime.GuardLeftElbow, Runtime.GuardLeftWrist, Start, Stop, Origin, Radius)) ||
            (Runtime.GuardRightArm && ArmInTrace(Runtime.GuardRightElbow, Runtime.GuardRightWrist, Start, Stop, Origin, Radius))) return 1;
        return 0;
    }

    int FistCrossing(AGothicVRRuntime Runtime,FVector A,FVector B,bool ImpactKnown,FVector Impact) const
    {
        FVector D=B-A;
        float Sq=D.SizeSquared();
        if (Sq<1.0f || Sq>45.0f*45.0f || (B-Runtime.Hero.GetActorLocation()).SizeSquared()>145.0f*145.0f) return 0;
        FVector Aim=ImpactKnown ? Impact : Runtime.Hero.GetActorLocation();
        if (ImpactKnown && (B-Impact).SizeSquared()>45.0f*45.0f) return 0;
        float T=(Aim-A).DotProduct(D)/Sq;
        if (T<=0.0f) return 0;
        Runtime.GuardFistSweeps+=1;
        return InterceptPart(Runtime,A,A+D*Math::Min(1.0f,T),true);
    }

    int FistPath(AGothicVRRuntime Runtime, AGothicCharacter Source, bool ImpactKnown, FVector Impact) const
    {
        float Now=Runtime.GetGameTimeSinceCreation();
        for (const auto& H : Runtime.IncomingFists)
        {
            if (H.Source!=Source || Now<H.Time || Now-H.Time>0.095f) continue;
            for (int Side=0; Side<2; Side++)
            {
                FVector B=Side==0 ? H.Left : H.Right;
                FName Bone=Side==0 ? n"middle_01_l" : n"middle_01_r";
                if (!Source.Mesh.DoesSocketExist(Bone)) continue;
                // Damage can execute between two Lua pose samples.
                int Part=FistCrossing(Runtime,B,Source.Mesh.GetSocketLocation(Bone),ImpactKnown,Impact);
                if (Part>0) return Part;
                if (Now-H.PreviousTime>0.095f || H.Time<=H.PreviousTime) continue;
                FVector A=Side==0 ? H.PreviousLeft : H.PreviousRight;
                Part=FistCrossing(Runtime,A,B,ImpactKnown,Impact);
                if (Part>0) return Part;
            }
        }
        return 0;
    }

    int ForearmIntercept(AGothicVRRuntime Runtime, AGothicCharacter Source, bool HasHit, const FHitResult& Hit,
                         UWeaponDefinition Weapon, AActor Causer, FVector HitVelocity) const
    {
        if (!IsValid(Weapon) || Weapon.HasItemSpec(GameplayTag::Item_Property_Throwable)) return 0;
        bool Fist = Weapon.GetItemType().MatchesTag(GameplayTag::Item_Weapon_Fist);
        if (!Fist && !IsValid(Cast<UWeaponMeleeDefinition>(Weapon))) return 0;
        Runtime.GuardIncomingMelee += 1;
        Runtime.LastGuardSource=Source.GetName().ToString();
        Runtime.LastGuardPart=0;
        float Age = Runtime.GetGameTimeSinceCreation() - Runtime.GuardArmsTime;
        if (Age < 0.0f || Age > 0.12f || (!Runtime.GuardLeftArm && !Runtime.GuardRightArm &&
            !Runtime.GuardLeftHand && !Runtime.GuardRightHand)) return 0;
        auto Carry = Source.GetCarryComponent();
        if (IsValid(Causer) && Causer != Source && Causer != Source.CharacterState &&
            (!IsValid(Carry) || Causer != Carry.GetItemVisual())) return 0;
        if (HasHit && IsValid(Hit.GetActor()) && Hit.GetActor() != Runtime.Hero) return 0;

        FVector Origin = Runtime.Hero.GetActorLocation();
        FVector Path = Hit.TraceEnd - Hit.TraceStart;
        float LengthSq = Path.SizeSquared();
        bool ImpactKnown = HasHit && (Hit.ImpactPoint-Origin).Size() <= 160.0f;
        if (ImpactKnown && !Hit.bStartPenetrating && LengthSq >= 4.0f && LengthSq <= 350.0f*350.0f &&
            (Hit.TraceStart-Source.GetActorLocation()).Size() < 260.0f)
        {
            FVector ToImpact = Hit.ImpactPoint-Hit.TraceStart;
            float T = ToImpact.DotProduct(Path)/LengthSq;
            if (T > 0.0f && T <= 1.15f && (ToImpact-Path*T).Size() < 27.0f)
            {
                Runtime.GuardMeasuredSweeps += 1;
                float EndT = Math::Min(1.0f,T);
                if (Hit.Time > 0.0f && Hit.Time < EndT) EndT = Hit.Time;
                int Measured=InterceptPart(Runtime, Hit.TraceStart, Hit.TraceStart+Path*EndT, Fist);
                if (Measured>0) return Measured;
            }
        }

        // Overlaps and some native hits have no usable incoming trace. Test the
        // attacking model at the confirmed damage event, never a generic guard cone.
        if (!IsValid(Source.Mesh) || (Source.GetActorLocation()-Origin).Size() > 270.0f) return 0;
        Runtime.GuardContactFallbacks += 1;
        // Native sphere overlaps can first report contact already inside the guard.
        // Reconstruct only the last short approach, ending at the measured impact.
        if (ImpactKnown && HitVelocity.SizeSquared()>0.25f)
        {
            FVector Incoming=HitVelocity.GetSafeNormal();
            if ((Hit.ImpactPoint-Source.GetActorLocation()).DotProduct(Incoming)>0.0f)
            {
                Runtime.GuardVelocitySweeps+=1;
                int Part=InterceptPart(Runtime,Hit.ImpactPoint-Incoming*(Fist ? 24.0f : 18.0f),Hit.ImpactPoint,Fist);
                if (Part>0) return Part;
            }
        }
        if (Fist)
        {
            int Swept=FistPath(Runtime,Source,ImpactKnown,Hit.ImpactPoint);
            if (Swept>0) return Swept;
            for (int I = 0; I < 2; I++)
            {
                FName Wrist = I == 0 ? n"hand_l" : n"hand_r";
                FName Knuckle = I == 0 ? n"middle_01_l" : n"middle_01_r";
                if (!Source.Mesh.DoesSocketExist(Wrist) || !Source.Mesh.DoesSocketExist(Knuckle)) continue;
                FVector A = Source.Mesh.GetSocketLocation(Wrist);
                FVector B = Source.Mesh.GetSocketLocation(Knuckle);
                if (ImpactKnown && (B-Hit.ImpactPoint).Size() > 36.0f) continue;
                int Contact = InterceptPart(Runtime,A,B,true);
                if (Contact > 0) return Contact;
            }
            return 0;
        }
        if (!IsValid(Carry) || !IsValid(Carry.GetItemVisual())) return 0;
        auto Visual = Carry.GetItemVisual();
        TArray<UStaticMeshComponent> Parts;
        Visual.GetComponentsByClass(UStaticMeshComponent::StaticClass(),Parts);
        for (auto Mesh : Parts)
        {
            if (!IsValid(Mesh) || !IsValid(Mesh.StaticMesh) || !Mesh.IsVisible()) continue;
            FVector Low, High;
            Mesh.GetLocalBounds(Low,High);
            FVector Half = (High-Low)*0.5f;
            FVector Axis = FVector(Half.X,0,0);
            if (Half.Y > Half.X) Axis = FVector(0,Half.Y,0);
            if (Half.Z > Math::Max(Half.X,Half.Y)) Axis = FVector(0,0,Half.Z);
            FVector Mid = (High+Low)*0.5f;
            FTransform Pose = Mesh.GetWorldTransform();
            FVector A = Pose.TransformPosition(Mid-Axis);
            FVector B = Pose.TransformPosition(Mid+Axis);
            float Length = (B-A).Size();
            if (Length < 22.0f || Length > 240.0f) continue;
            // Clip at the actual hit when Gothic supplies it, from grip outward.
            if (ImpactKnown && Source.Mesh.DoesSocketExist(n"hand_r"))
            {
                FVector Hand = Source.Mesh.GetSocketLocation(n"hand_r");
                if ((B-Hand).SizeSquared() < (A-Hand).SizeSquared())
                { FVector Swap=A; A=B; B=Swap; }
                FVector Dir=(B-A)/Length;
                B=A+Dir*Math::Clamp(float((Hit.ImpactPoint-A).DotProduct(Dir)),0.0f,Length);
            }
            int Contact = InterceptPart(Runtime,A,B,false);
            if (Contact > 0) return Contact;
        }
        return 0;
    }

    UFUNCTION(BlueprintOverride)
    void Execute(const FGameplayEffectCustomExecutionParameters& Params, FGameplayEffectCustomExecutionOutput& Output) const
    {
        auto Runtime = UGothicVRInventoryBridge.GetDefaultObject().Runtime;
        auto TargetASC = Cast<UGothicAbilitySystemComponent>(Params.GetTargetAbilitySystemComponent());
        auto SourceASC = Cast<UGothicAbilitySystemComponent>(Params.GetSourceAbilitySystemComponent());
        auto Target = IsValid(TargetASC) ? Cast<AGothicCharacter>(TargetASC.GetAvatar()) : nullptr;
        auto Source = IsValid(SourceASC) ? Cast<AGothicCharacter>(SourceASC.GetAvatar()) : nullptr;
        bool Valid = IsValid(Runtime) && Runtime.Ready() && Target == Runtime.Hero && IsValid(Source) && Source != Target;
        if (!Valid) { Super::Execute(Params, Output); return; }
        float Age = Runtime.GetGameTimeSinceCreation() - Runtime.BladeTime;
        auto Carry = Target.GetCarryComponent();
        bool BladeFresh = Age >= 0.0f && Age <= 0.12f && IsValid(Carry) && Cast<UWeaponMeleeDefinition>(Carry.GetEquippedItemDefinition()) != nullptr;
        const FGameplayEffectSpec& Spec = Params.GetOwningSpec();
        auto Context = Spec.GetContext();
        auto HitData = Context.GetHitContext();
        FHitResult Hit;
        bool HasHit = Context.GetHitResult(Hit);
        auto Weapon = HitData.WeaponUsed != nullptr ? Cast<UWeaponDefinition>(HitData.WeaponUsed.Get().GetDefaultObject()) : nullptr;
        int Part = ForearmIntercept(Runtime, Source, HasHit, Hit, Weapon, Context.GetEffectCauser(), HitData.AttackLinearVelocity);
        bool Arm = Part > 0;
        if (!Arm && !BladeFresh) { Super::Execute(Params, Output); return; }
        bool Intersects = BladeFresh && SegmentDistance(Runtime.BladeA, Runtime.BladeB, Hit.TraceStart, Hit.TraceEnd) <= 7.0f;
        if (BladeFresh && !Intersects && Runtime.HasPreviousBlade)
            Intersects = SegmentDistance(Runtime.PreviousBladeA, Runtime.PreviousBladeB, Hit.TraceStart, Hit.TraceEnd) <= 7.0f ||
                SegmentDistance((Runtime.PreviousBladeA + Runtime.BladeA) * 0.5f, (Runtime.PreviousBladeB + Runtime.BladeB) * 0.5f, Hit.TraceStart, Hit.TraceEnd) <= 7.0f;
        bool Melee = HitData.WeaponUsed != nullptr ? Cast<UWeaponMeleeDefinition>(HitData.WeaponUsed.Get().GetDefaultObject()) != nullptr :
            Source.HasDrawnMeleeWeapon() && !Source.HasDrawnFists();
        bool TraceValid = (Hit.TraceStart - Hit.TraceEnd).Size() >= 2.0f && (Hit.TraceStart - Source.GetActorLocation()).Size() <= 350.0f;
        bool Blade = BladeFresh && Melee && ((TraceValid && Intersects) || Runtime.GuardLane(Source));
        if (!Blade && !Arm)
        { Super::Execute(Params, Output); return; }
        auto Combat = DataModule::GetCombatDataModule(Target);
        if (!IsValid(Combat)) { Super::Execute(Params, Output); return; }
        auto PreviousBlock = Combat.GetBlockState();
        auto PreviousDirection = Combat.GetCurrentParryDirection();
        bool Parry = Blade && HitData.CanBeParried && Runtime.GetGameTimeSinceCreation() - Runtime.GuardRaised < 0.20f;
        Combat.Server_SetCurrentParryDirection(HitData.SourceAttackDirection);
        Combat.Server_SetBlockState(Parry ? GameplayTag::Combat_BlockState_Parry : GameplayTag::Combat_BlockState_Block);
        if (Parry) Runtime.Parries += 1; else Runtime.Blocks += 1;
        Runtime.LastGuardPart=Blade ? 3 : Part;
        if (Part == 1 && !Blade) Runtime.ForearmBlocks += 1;
        if (Part == 2 && !Blade) Runtime.PalmBlocks += 1;
        // The stock damage calculation dereferences the defender's weapon for
        // block resistance. A physical interception also works with empty hands.
        if (Arm && !Blade && (!IsValid(Combat.GetEquipedWeaponDefinition()) ||
            !IsValid(Cast<UWeaponMeleeDefinition>(Weapon)) || !GothicCombatLibrary::IsHitBlocked(HitData, Target)))
            SendGameplayEvent(EReceiverEventActor::INSTIGATOR, GameplayTag::Action_Deflected, 0.0f, Params);
        else Super::Execute(Params, Output);
        if (IsValid(Target) && IsValid(Combat))
        {
            Combat.Server_SetCurrentParryDirection(PreviousDirection);
            Combat.Server_SetBlockState(PreviousBlock);
        }
    }
}
