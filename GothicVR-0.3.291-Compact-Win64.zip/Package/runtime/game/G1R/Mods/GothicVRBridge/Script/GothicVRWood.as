namespace GothicVRSurface
{
    int WoodKind(UStaticMesh Asset)
    {
        if (!IsValid(Asset)) return 0;
        FString N = Asset.Name.ToString().ToLower();
        // These cooked meshes combine a crooked trunk, a platform or iron bars.
        // Trace the individual mesh instead of treating the assembly as a cylinder.
        if (N.StartsWith("sm_hangmantree") || N.Contains("hangingtree_hangedman") ||
            N.StartsWith("sm_gibbet_") || N.StartsWith("sm_cage_") || N.StartsWith("sm_cagehanger")) return 4;
        if (N.StartsWith("sm_skeleton_") || N.StartsWith("sm_skull_") || N.StartsWith("sm_firewood_") ||
            N.StartsWith("sm_sawmill_log") || N.StartsWith("sm_cutting_log") || N.StartsWith("sm_log_") ||
            N.StartsWith("sm_wagon_") || N.StartsWith("sm_wagonwheel_") || N.StartsWith("sm_fallentree") || N.Contains("sm_log_medieval")) return 4;
        if (N.Contains("leaf") || N.Contains("leav") || N.Contains("branch") || N.Contains("twig") ||
            N.Contains("bush") || N.Contains("canopy") || N.Contains("crown") ||
            N.Contains("needle") || N.Contains("billboard") || N.Contains("impostor") || N.Contains("treetop") ||
            N.Contains("tree_top") || N.Contains("tree_root") || N.Contains("treepot") || N.Contains("street") ||
            N.Contains("spine") || N.Contains("pineapple") || N.Contains("pinecone") || N.Contains("cloak") ||
            N.Contains("stairs") || N.Contains("rope") || N.Contains("treehut") || N.Contains("treehouse") ||
            N.Contains("treebark") || N.Contains("atlas") || N.Contains("itmi_") || N.Contains("crate") ||
            N.Contains("chest") || N.Contains("plank") || N.Contains("barrel") || N.Contains("furniture")) return 0;
        if (N.Contains("stump") || N.Contains("trunk")) return 2;
        if (N.Contains("sapling")) return 3;
        if (N.Contains("tree") || N.Contains("silverdownywillow") || N.StartsWith("sm_lod_spruce") ||
            N.StartsWith("sm_spruce") || N.StartsWith("sm_pine") || N.StartsWith("sm_birch") ||
            N.StartsWith("sm_beech") || N.StartsWith("sm_oak_") || N.StartsWith("sm_willow") || N.StartsWith("sm_fir_")) return 1;
        return 0;
    }
}

// A local wood surface is one static mesh, or one instance, never a foliage actor's bounds.
struct FVRWoodStem
{
    UPROPERTY() UStaticMeshComponent Part;
    FVector Foot;
    FVector Axis;
    float Length = 0.0f;
    float Width = 0.0f;
    float SearchWidth = 0.0f;
    int Index = -1;

    // During an initial overlap the probe's centre is already inside its
    // inflated stem. Return a point on the stem itself, including the stump rim.
    FVector SurfacePoint(FVector Center, FVector Normal) const
    {
        FVector Offset = Center - Foot;
        float Height = Offset.DotProduct(Axis);
        FVector Radial = Offset - Axis * Height;
        float AlongNormal = Normal.DotProduct(Axis);
        if (Math::Abs(AlongNormal) > 0.99f)
        {
            float CapHeight = AlongNormal > 0.0f ? Length : 0.0f;
            return Foot + Axis * CapHeight + Radial.GetSafeNormal() * Math::Min(Width, Radial.Size());
        }
        return Foot + Axis * Math::Clamp(Height, 0.0f, Length) + Normal * Width;
    }

    // Intersect the radial interval and the two end planes in segment time.
    // A stump has a flat top. Starting inside permits escape and tangent motion.
    bool Sweep(FVector From, FVector To, float Probe, float Limit, float&out When, FVector&out Surface) const
    {
        FVector Delta = To - From;
        FVector Offset = From - Foot;
        float Z = Offset.DotProduct(Axis);
        float DZ = Delta.DotProduct(Axis);
        FVector XY = Offset - Axis * Z;
        FVector DXY = Delta - Axis * DZ;
        float R = Width + Probe;
        float A = DXY.SizeSquared();
        float B = XY.DotProduct(DXY);
        float C = XY.SizeSquared() - R * R;
        float Enter = 0.0f;
        float Leave = Limit;
        if (A < 0.000001f)
        {
            if (C > 0.0f) return false;
        }
        else
        {
            float Disc = B * B - A * C;
            if (Disc < 0.0f) return false;
            float Root = Math::Sqrt(Disc);
            Enter = Math::Max(Enter, (-B - Root) / A);
            Leave = Math::Min(Leave, (-B + Root) / A);
        }
        float Bottom = -Probe;
        float Top = Length + Probe;
        bool Cap = false;
        if (Math::Abs(DZ) < 0.00001f)
        {
            if (Z < Bottom || Z > Top) return false;
        }
        else
        {
            float T0 = (Bottom - Z) / DZ;
            float T1 = (Top - Z) / DZ;
            float IntoCap = Math::Min(T0, T1);
            if (IntoCap >= Enter) { Enter = IntoCap; Cap = true; }
            Leave = Math::Min(Leave, Math::Max(T0, T1));
        }
        if (Enter > Leave || Enter > Limit) return false;
        if (Enter == 0.0f && C <= 0.0f && Z >= Bottom && Z <= Top)
        {
            float Depth = R - XY.Size();
            if (Z - Bottom < Depth || Top - Z < Depth)
                Surface = (Z - Bottom < Top - Z) ? -Axis : Axis;
            else Surface = XY.GetSafeNormal();
        }
        else if (Cap) Surface = (DZ > 0.0f) ? -Axis : Axis;
        else Surface = (XY + DXY * Enter).GetSafeNormal();
        When = Enter;
        return Delta.DotProduct(Surface) < -0.00001f;
    }
}

// These meshes retain their cooked collision even when a level designer turns
// scene queries off for the placed decoration. The helper belongs to the VR
// runtime; no collision response, visibility or mobility of the source changes.
struct FVRPropSurface
{
    UPROPERTY() UStaticMeshComponent Source;
    UPROPERTY() UStaticMeshComponent Query;
    UPROPERTY() UStaticMesh Mesh;
    int Index = -1;
    FVector Center;
    FVector Extent;
    bool Used = false;
    bool UseSource = false;
}

struct FVRWoodCache
{
    UPROPERTY() TArray<FVRWoodStem> Stems;
    UPROPERTY() TArray<FVRPropSurface> Props;
    UPROPERTY() FVRScenery Scenery;
    int ActiveProps = 0;
    UPROPERTY() TSubclassOf<AActor> FoliageClass;
    UPROPERTY() TArray<AActor> Owners;
    UPROPERTY() TArray<UInstancedStaticMeshComponent> Foliage;
    UPROPERTY() UStaticMeshComponent YardTree;
    float NextOwners = -1.0f;
    float NextScan = -1.0f;
    int OwnerIndex = 0;
    FVector ScanAt;

    void Clear()
    {
        ReleaseYardTree();
        Stems.Empty(); Owners.Empty(); Foliage.Empty(); Scenery.Clear();
        ActiveProps = 0;
        for (int I = 0; I < Props.Num(); I++) { Props[I].Used=false; Props[I].Source=nullptr; }
        NextOwners = -1.0f; NextScan = -1.0f; OwnerIndex = 0;
    }

    bool NearBounds(FVector Point, FVector Center, FVector Extent, float Pad) const
    {
        return Math::Abs(Point.X-Center.X) <= Extent.X+Pad && Math::Abs(Point.Y-Center.Y) <= Extent.Y+Pad &&
            Math::Abs(Point.Z-Center.Z) <= Extent.Z+Pad;
    }

    // 1 is a crown-bearing tree, 2 a stump/trunk, 3 a young tree.
    void AddStem(UStaticMeshComponent Part, int Index, const FTransform&in Pose, const FBox&in Box, int Kind, FVector Eye)
    {
        FVector Ext = (Box.Max - Box.Min) * 0.5f;
        FVector Center = (Box.Min + Box.Max) * 0.5f;
        // Whole-tree pivots are authored at the root; crowns can be asymmetric.
        if (Kind != 2 && Box.Min.X <= 0.0f && Box.Max.X >= 0.0f && Box.Min.Y <= 0.0f && Box.Max.Y >= 0.0f)
        { Center.X = 0.0f; Center.Y = 0.0f; }
        FVector Foot = Pose.TransformPosition(FVector(Center.X, Center.Y, Box.Min.Z));
        float Fraction = (Kind == 2) ? 1.0f : 0.58f;
        FVector End = Pose.TransformPosition(FVector(Center.X, Center.Y, Box.Min.Z + 2.0f * Ext.Z * Fraction));
        FVector Axis = (End - Foot).GetSafeNormal();
        float Height = (End - Foot).Size();
        float XExtent = Pose.TransformVector(FVector(Ext.X, 0.0f, 0.0f)).Size();
        float YExtent = Pose.TransformVector(FVector(0.0f, Ext.Y, 0.0f)).Size();
        float Half = Math::Min(XExtent, YExtent);
        if (Height < 6.0f || Half < 2.0f || (Kind == 3 && Height < 22.0f)) return;
        float Width = Kind != 2 ? Math::Clamp(Math::Min(0.085f * Half, 0.022f * Height), 1.0f, 35.0f) :
            Math::Clamp(Half * 0.77f, 2.0f, 120.0f);
        float Along = Math::Clamp((Eye-Foot).DotProduct(Axis), 0.0f, Height);
        if ((Eye - Foot - Axis * Along).Size() > 240.0f + Width) return;
        if (Stems.Num() >= 48) return;
        FVRWoodStem Stem;
        Stem.Part = Part; Stem.Index = Index; Stem.Foot = Foot; Stem.Axis = Axis;
        Stem.Length = Height; Stem.Width = Width;
        Stem.SearchWidth = Math::Max(Width+12.0f, (Kind == 2) ? Math::Max(XExtent,YExtent) : Width * 2.0f);
        Stems.Add(Stem);
    }

    void AddShape(UStaticMeshComponent Part, int Index, const FTransform&in Pose, const FBox&in Box,
                  int Kind, FVector Eye, AActor Runtime)
    {
        if (Kind == 4)
        {
            CacheProp(Part, Index, Pose, Box, Eye, Runtime);
            return;
        }
        // On the spruce reported in 251 the two original capsule axes have
        // different offsets and tilt. The foliage bounds also include the crown.
        auto Body = Part.StaticMesh.BodySetup;
        if (Kind != 2 && IsValid(Body) && !Body.AggGeom.SphylElems.IsEmpty())
        {
            bool HasTrunk=false;
            for (const FKSphylElem& E : Body.AggGeom.SphylElems)
            {
                if (E.Radius < 0.5f || E.Length < E.Radius) continue;
                FVector Up = E.Rotation.GetUpVector();
                if (Math::Abs(Up.Z) < 0.65f) continue;
                HasTrunk=true;
                float R = E.Radius * 0.94f;
                FVector A = Pose.TransformPosition(E.Center - Up * (0.5f*E.Length + R*0.6f));
                FVector B = Pose.TransformPosition(E.Center + Up * (0.5f*E.Length + R*0.6f));
                float Rad = R * Math::Min(Pose.TransformVector(E.Rotation.RotateVector(FVector(1,0,0))).Size(),
                                         Pose.TransformVector(E.Rotation.RotateVector(FVector(0,1,0))).Size());
                FVector Axis = (B-A).GetSafeNormal();
                float Len = (B-A).Size();
                float H = Math::Clamp((Eye-A).DotProduct(Axis), 0.0f, Len);
                if ((Eye-A-Axis*H).SizeSquared() > (245.0f+Rad)*(245.0f+Rad) || Stems.Num() >= 48) continue;
                FVRWoodStem Stem;
                Stem.Part=Part; Stem.Index=Index; Stem.Foot=A; Stem.Axis=Axis; Stem.Length=Len;
                Stem.Width=Rad; Stem.SearchWidth=Rad+3.0f;
                Stems.Add(Stem);
            }
            if (HasTrunk) return;
        }
        AddStem(Part, Index, Pose, Box, Kind, Eye);
    }

    void CacheProp(UStaticMeshComponent Part, int Index, const FTransform&in Pose, const FBox&in Box,
                   FVector Eye, AActor Runtime)
    {
        FVector LocalExtent = (Box.Max-Box.Min)*0.5f;
        FVector Center = Pose.TransformPosition((Box.Max+Box.Min)*0.5f);
        FVector X = Pose.TransformVector(FVector(LocalExtent.X,0,0));
        FVector Y = Pose.TransformVector(FVector(0,LocalExtent.Y,0));
        FVector Z = Pose.TransformVector(FVector(0,0,LocalExtent.Z));
        FVector Extent = FVector(Math::Abs(X.X)+Math::Abs(Y.X)+Math::Abs(Z.X),
            Math::Abs(X.Y)+Math::Abs(Y.Y)+Math::Abs(Z.Y),Math::Abs(X.Z)+Math::Abs(Y.Z)+Math::Abs(Z.Z));
        if (!NearBounds(Eye,Center,Extent,215.0f)) return;
        int Slot = -1;
        for (int I=0; I<Props.Num(); I++)
        {
            if (Props[I].Source == Part && Props[I].Index == Index) { Slot=I; break; }
            if (!IsValid(Props[I].Source)) Slot=I;
        }
        if (Slot < 0)
        {
            if (Props.Num() >= 12 && Part != YardTree) return;
            FVRPropSurface NewProp;
            Slot=Props.Num();
            Props.Add(NewProp);
        }
        if (Props[Slot].Used) return;
        Props[Slot].Used=true; ActiveProps+=1;
        Props[Slot].Source=Part; Props[Slot].Index=Index;
        Props[Slot].Center=Center; Props[Slot].Extent=Extent;
        auto Mode=Part.GetCollisionEnabled();
        Props[Slot].UseSource=Index < 0 && (Mode==ECollisionEnabled::QueryOnly || Mode==ECollisionEnabled::QueryAndPhysics);
        if (Props[Slot].UseSource)
        {
            ReleaseProxy(Props[Slot]);
            return;
        }
        // Original and instanced geometry can use a profile with no query body.
        // Use an isolated per-instance query with the stock cooked convex hulls.
        if (!IsValid(Props[Slot].Query))
        {
            auto NewQuery=UStaticMeshComponent::Create(Runtime);
            if (!IsValid(NewQuery)) return;
            NewQuery.SetMobility(EComponentMobility::Movable);
            NewQuery.SetVisibility(false); NewQuery.SetHiddenInGame(true);
            NewQuery.SetCastShadow(false); NewQuery.SetAffectDistanceFieldLighting(false);
            NewQuery.SetVisibleInRayTracing(false); NewQuery.SetRenderInMainPass(false); NewQuery.SetRenderInDepthPass(false);
            NewQuery.SetGenerateOverlapEvents(false);
            NewQuery.SetCollisionEnabled(ECollisionEnabled::NoCollision);
            Props[Slot].Query=NewQuery; Props[Slot].Mesh=nullptr;
        }
        auto Query=Props[Slot].Query;
        if (Props[Slot].Mesh != Part.StaticMesh)
        {
            Query.SetWorldTransform(Pose);
            Query.SetStaticMesh(Part.StaticMesh);
            Query.SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Ignore);
            Query.SetCollisionEnabled(ECollisionEnabled::QueryOnly);
            Props[Slot].Mesh=Part.StaticMesh;
        }
        else if (!Query.GetWorldTransform().Equals(Pose, 0.001f))
            Query.SetWorldTransform(Pose);
    }

    void ReleaseProxy(FVRPropSurface& Slot)
    {
        if (IsValid(Slot.Query) && IsValid(Slot.Mesh))
        {
            Slot.Query.SetCollisionEnabled(ECollisionEnabled::NoCollision);
            Slot.Query.SetStaticMesh(nullptr);
        }
        Slot.Mesh=nullptr;
    }

    void SuspendProps()
    {
        ReleaseYardTree();
        for (int I=0; I<Props.Num(); I++)
        {
            ReleaseProxy(Props[I]);
            Props[I].Source=nullptr;
            Props[I].Used=false;
        }
        ActiveProps=0;
    }

    void ReleaseYardTree()
    {
        if (IsValid(YardTree) && IsValid(YardTree.StaticMesh))
        {
            YardTree.SetCollisionEnabled(ECollisionEnabled::NoCollision);
            YardTree.SetStaticMesh(nullptr);
        }
    }

    // The courtyard tree in cell CPJ9EFAS73KJY9YUQPM74WKG7 is an entry in a
    // lightweight decoration container, without its own UStaticMeshComponent.
    // Use its cooked transform and mesh for a private component sweep.
    void CacheYardTree(AGothicCharacter Hero, FVector Eye, AActor Runtime)
    {
        FVector Root = Gameplay::RebaseZeroOriginOntoLocal(FVector(116719.175088,-101755.009573,-4259.845586));
        if (!NearBounds(Eye,Root,FVector(345,345,1000),245.0f) || Hero.GetWorld().Name != n"MainMap")
        { ReleaseYardTree(); return; }
        TSoftObjectPtr<UStaticMesh> Ref(n"/Game/Assets/Environment/Biomes/Temperate/Flora/SM_DeadTree_01.SM_DeadTree_01");
        auto Asset = Ref.Get();
        if (!IsValid(Asset)) { ReleaseYardTree(); return; }
        if (!IsValid(YardTree))
        {
            YardTree = UStaticMeshComponent::Create(Runtime);
            if (!IsValid(YardTree)) return;
            YardTree.SetMobility(EComponentMobility::Movable);
            YardTree.SetAbsolute(true,true,true);
            YardTree.SetVisibility(false); YardTree.SetHiddenInGame(true);
            YardTree.SetCastShadow(false); YardTree.SetAffectDistanceFieldLighting(false);
            YardTree.SetVisibleInRayTracing(false); YardTree.SetRenderInMainPass(false); YardTree.SetRenderInDepthPass(false);
            YardTree.SetGenerateOverlapEvents(false);
            YardTree.SetCollisionEnabled(ECollisionEnabled::NoCollision);
        }
        FTransform Pose(FQuat(-0.00864831936,0.04172581588,-0.92211295521,0.38456710817),Root,
                        FVector(1.4953789711,1.4953789711,1.4953789711));
        if (YardTree.StaticMesh != Asset || !YardTree.GetWorldTransform().Equals(Pose,0.001f))
        {
            YardTree.SetWorldTransform(Pose);
            YardTree.SetStaticMesh(Asset);
            YardTree.SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Ignore);
            YardTree.SetCollisionEnabled(ECollisionEnabled::QueryOnly);
        }
        CacheProp(YardTree,-1,Pose,Asset.GetBoundingBox(),Eye,Runtime);
    }

    bool SweepProps(FVector From, FVector To, float Probe, float Limit, FHitResult&out Hit, int&out InstanceIndex) const
    {
        if (ActiveProps == 0) return false;
        bool Found=false;
        float Best=Limit;
        FVector Span=To-From;
        FVector Mid=From+Span*0.5f;
        for (const FVRPropSurface& P : Props)
        {
            if (!P.Used || !IsValid(P.Source)) continue;
            auto Surface=P.UseSource ? P.Source : P.Query;
            if (!IsValid(Surface)) continue;
            if (Math::Abs(Mid.X-P.Center.X)>P.Extent.X+Math::Abs(Span.X)*0.5f+Probe ||
                Math::Abs(Mid.Y-P.Center.Y)>P.Extent.Y+Math::Abs(Span.Y)*0.5f+Probe ||
                Math::Abs(Mid.Z-P.Center.Z)>P.Extent.Z+Math::Abs(Span.Z)*0.5f+Probe) continue;
            FHitResult H; FVector Pos, Norm; FName Bone;
            bool Reached=Surface.SphereTraceComponent(From,To,Probe,true,false,false,Pos,Norm,Bone,H);
            if (!Reached)
                Reached=Surface.SphereTraceComponent(From,To,Probe,false,false,false,Pos,Norm,Bone,H);
            if (!Reached || H.Time>Best || Span.DotProduct(H.ImpactNormal)>=0.0f) continue;
            H.SetActor(P.Source.GetOwner()); H.SetComponent(P.Source);
            Hit=H; InstanceIndex=P.Index; Best=H.Time; Found=true;
        }
        return Found;
    }

    void AddPart(UStaticMeshComponent Part, FVector Eye, AActor Runtime)
    {
        if (!IsValid(Part) || !Part.bVisible || Part.bHiddenInGame) return;
        int Kind = GothicVRSurface::WoodKind(Part.StaticMesh);
        if (Kind == 0 || (Kind != 4 && Stems.Num() >= 48)) return;
        FBox Box = Part.StaticMesh.GetBoundingBox();
        auto Instances = Cast<UInstancedStaticMeshComponent>(Part);
        if (!IsValid(Instances)) { AddShape(Part, -1, Part.GetWorldTransform(), Box, Kind, Eye, Runtime); return; }
        auto Nearby = Instances.GetInstancesOverlappingSphere(Eye, 245.0f, true);
        for (int I = 0; I < Nearby.Num() && (Kind == 4 ? ActiveProps < 12 : Stems.Num() < 48); I++)
        {
            FTransform Pose;
            if (Instances.GetInstanceTransform(Nearby[I], Pose, true)) AddShape(Part, Nearby[I], Pose, Box, Kind, Eye, Runtime);
        }
    }

    void Tick(AGothicCharacter Hero, float Now, AActor Runtime)
    {
        FVector Eye = Hero.GetActorLocation();
        Scenery.Tick(Hero,Now);
        if (FoliageClass != nullptr)
        {
            if (Now >= NextOwners && OwnerIndex >= Owners.Num())
            {
                Owners.Empty();
                Gameplay::GetAllActorsOfClass(FoliageClass, Owners);
                OwnerIndex = 0; NextOwners = Now + 3.0f;
                for (int I = Foliage.Num()-1; I >= 0; I--)
                {
                    auto P = Foliage[I];
                    if (!IsValid(P) || P.GetWorld() != Hero.GetWorld()) { Foliage.RemoveAt(I); continue; }
                    auto B = P.GetBounds();
                    if (!NearBounds(Eye, B.Origin, B.BoxExtent, 700.0f)) Foliage.RemoveAt(I);
                }
            }
            for (int I = 0; I < 4 && OwnerIndex < Owners.Num(); I++)
            {
                auto Owner = Owners[OwnerIndex]; OwnerIndex += 1;
                if (!IsValid(Owner) || Owner.GetWorld() != Hero.GetWorld()) continue;
                FVector Center, Extent;
                Owner.GetActorBounds(false, Center, Extent);
                if (!NearBounds(Eye, Center, Extent, 650.0f)) continue;
                TArray<UActorComponent> Parts;
                Owner.GetComponentsByClass(UInstancedStaticMeshComponent::StaticClass(), Parts);
                for (auto P : Parts)
                {
                    auto Mesh = Cast<UInstancedStaticMeshComponent>(P);
                    if (!IsValid(Mesh) || Foliage.Contains(Mesh) || GothicVRSurface::WoodKind(Mesh.StaticMesh) == 0) continue;
                    auto B = Mesh.GetBounds();
                    if (NearBounds(Eye, B.Origin, B.BoxExtent, 650.0f)) Foliage.Add(Mesh);
                }
            }
        }
        if (Now < NextScan && (Eye-ScanAt).SizeSquared() < 85.0f*85.0f) return;
        NextScan = Now + 0.5f; ScanAt = Eye; Stems.Empty(); ActiveProps=0;
        for (int I=0; I<Props.Num(); I++) Props[I].Used=false;
        CacheYardTree(Hero,Eye,Runtime);
        TArray<EObjectTypeQuery> Types;
        Types.Add(EObjectTypeQuery::WorldStatic); Types.Add(EObjectTypeQuery::WorldDynamic);
        TArray<AActor> Ignore; Ignore.Add(Hero); Ignore.Add(Runtime);
        TArray<UPrimitiveComponent> Overlaps;
        System::SphereOverlapComponents(Eye, 245.0f, Types, UStaticMeshComponent::StaticClass(), Ignore, Overlaps);
        for (auto P : Overlaps)
        {
            auto Mesh = Cast<UStaticMeshComponent>(P);
            AddPart(Mesh, Eye, Runtime);
        }
        for (auto Mesh : Foliage)
        {
            if (!IsValid(Mesh) || Overlaps.Contains(Mesh)) continue;
            auto B = Mesh.GetBounds();
            if (NearBounds(Eye, B.Origin, B.BoxExtent, 245.0f)) AddPart(Mesh, Eye, Runtime);
        }
        for (auto Part : Scenery.Nearby)
        {
            if (IsValid(Part) && !Overlaps.Contains(Part) && !Foliage.Contains(Cast<UInstancedStaticMeshComponent>(Part))) AddPart(Part, Eye, Runtime);
        }
        for (int I=0; I<Props.Num(); I++)
        {
            if (Props[I].Used) continue;
            ReleaseProxy(Props[I]);
            Props[I].Source=nullptr;
        }
    }

    bool Sweep(FVector From, FVector To, float Radius, float Limit, FHitResult&out Hit, bool&out Approximate, int&out InstanceIndex) const
    {
        float Best = Math::Clamp(Limit, 0.0f, 1.0f);
        if (Best <= 0.0f || (To-From).SizeSquared() < 0.000001f) return false;
        float Probe = Math::Max(0.05f, Radius);
        FVector Mid = From + (To-From) * (Best * 0.5f);
        float Range = (To-From).Size() * Best * 0.5f + Probe;
        bool Found = SweepProps(From, To, Probe, Best, Hit, InstanceIndex);
        if (Found) { Best=Hit.Time; Approximate=false; }
        UStaticMeshComponent LastPart;
        FHitResult Exact;
        bool HasExact = false;
        for (const FVRWoodStem& Stem : Stems)
        {
            if (!IsValid(Stem.Part)) continue;
            float Z = Math::Clamp((Mid-Stem.Foot).DotProduct(Stem.Axis), 0.0f, Stem.Length);
            float Band = Stem.SearchWidth + Range;
            if ((Mid-Stem.Foot-Stem.Axis*Z).SizeSquared() > Band*Band) continue;
            if (Stem.Part != LastPart)
            {
                // Instances of one mesh are adjacent in Stems. The engine traces
                // their common scene proxy once; test that response per instance.
                LastPart = Stem.Part;
                FVector Pos, TraceNormal;
                FName Bone;
                HasExact = Stem.Part.SphereTraceComponent(From, To, Probe, true, false, false, Pos, TraceNormal, Bone, Exact);
            }
            if (HasExact)
            {
                // The query on an ISM can hit another tree or its crown. Only use
                // a hit near this instance's trunk; reject tangential/outward overlap.
                FVector Shift = Exact.ImpactPoint - Stem.Foot;
                float Height = Shift.DotProduct(Stem.Axis);
                if (Height >= -Probe && Height <= Stem.Length+Probe &&
                    (Shift-Stem.Axis*Height).SizeSquared() <= Stem.SearchWidth*Stem.SearchWidth &&
                    (To-From).DotProduct(Exact.ImpactNormal) < 0.0f)
                {
                    if (Exact.Time <= Best) { Hit = Exact; Best = Exact.Time; Found = true; Approximate = false; InstanceIndex = Stem.Index; }
                    continue;
                }
            }
            float At;
            FVector Normal;
            if (Stem.Sweep(From, To, Probe, Best, At, Normal))
            {
                FHitResult Synth;
                Synth.SetActor(Stem.Part.GetOwner());
                Synth.SetComponent(Stem.Part);
                Synth.Time = At; Synth.bBlockingHit = true; Synth.bStartPenetrating = At == 0.0f;
                Synth.TraceStart = From; Synth.TraceEnd = To;
                Synth.Location = From+(To-From)*At;
                Synth.ImpactPoint = Stem.SurfacePoint(Synth.Location, Normal);
                if (Synth.bStartPenetrating)
                    Synth.PenetrationDepth = Math::Max(0.0f, Probe - (Synth.Location-Synth.ImpactPoint).DotProduct(Normal));
                Synth.Distance = (Synth.Location-From).Size(); Synth.ImpactNormal = Normal; Synth.Normal = Normal;
                Hit = Synth; Best = At; Found = true; Approximate = true; InstanceIndex = Stem.Index;
            }
        }
        return Found;
    }
}
