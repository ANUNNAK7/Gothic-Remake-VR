// Firebolt and the shared projectile-start guard live in GothicVRFirebolt.as.
// Official G1R inheritance injection; no world scan or per-frame Lua UObject calls.
UCLASS(meta=(ReplaceParentClass))
class AIceboltVisual_GothicVR : AIceboltVisual
{
    FVRSpellStart VRStart;

    UFUNCTION(BlueprintOverride)
    void OnProjectileBeginPlay()
    {
        if (!VRStart.Begin(this)) return;
        Super::OnProjectileBeginPlay();
        VRStart.Schedule(this);
    }

    UFUNCTION()
    void FinishVRLaunch() { VRStart.Finish(this); }

    UFUNCTION(BlueprintOverride)
    void OnProjectileEndPlay()
    {
        VRStart.End();
        Super::OnProjectileEndPlay();
    }
}

// Official G1R inheritance injection; no world scan or per-frame Lua UObject calls.
UCLASS(meta=(ReplaceParentClass))
class AFireballVisual_GothicVR : AFireballVisual
{
    FVRSpellStart VRStart;

    UFUNCTION(BlueprintOverride)
    void OnProjectileBeginPlay()
    {
        if (!VRStart.Begin(this)) return;
        Super::OnProjectileBeginPlay();
        VRStart.Schedule(this);
    }

    UFUNCTION()
    void FinishVRLaunch() { VRStart.Finish(this); }

    UFUNCTION(BlueprintOverride)
    void OnProjectileEndPlay()
    {
        VRStart.End();
        Super::OnProjectileEndPlay();
    }
}

// Official G1R inheritance injection; no world scan or per-frame Lua UObject calls.
UCLASS(meta=(ReplaceParentClass))
class ABallLightningVisual_GothicVR : ABallLightningVisual
{
    FVRSpellStart VRStart;

    UFUNCTION(BlueprintOverride)
    void OnProjectileBeginPlay()
    {
        if (!VRStart.Begin(this)) return;
        Super::OnProjectileBeginPlay();
        VRStart.Schedule(this);
    }

    UFUNCTION()
    void FinishVRLaunch() { VRStart.Finish(this); }

    UFUNCTION(BlueprintOverride)
    void OnProjectileEndPlay()
    {
        VRStart.End();
        Super::OnProjectileEndPlay();
    }
}


// Preserve native charging/levels; substitute only steering of an already spawned VR projectile.
UCLASS(meta=(ReplaceParentClass))
class UGA_Spell_SpawnRechargeableProjectile_GothicVR : UGA_Spell_SpawnRechargeableProjectile
{
    UFUNCTION(BlueprintOverride)
    void OnUpdateSpellServer_Scriptable(float DeltaTime)
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (m_Projectile != nullptr && m_ProjectileDefinition != nullptr &&
            Bridge.HasVRMagicPose(GetActorInfo().GetAvatarActor()))
        {
            MoveProjectilesTo(Bridge.VRMagicTarget);
            return;
        }
        Super::OnUpdateSpellServer_Scriptable(DeltaTime);
    }
}

UCLASS(meta=(ReplaceParentClass))
class UGA_Spell_SpawnRepeatingProjectile_GothicVR : UGA_Spell_SpawnRepeatingProjectile
{
    UFUNCTION(BlueprintOverride)
    FVector GetSpawnPositionServer_Scriptable(AGothicCharacter owner, TSubclassOf<UObject> actorToSpawnClass) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRMagicPose(owner)) return Bridge.GetVRProjectileSpawnOrigin();
        return Super::GetSpawnPositionServer_Scriptable(owner, actorToSpawnClass);
    }
}

UCLASS(meta=(ReplaceParentClass))
class UGA_Spell_Fireball_GothicVR : UGA_Spell_Fireball
{
    UFUNCTION(BlueprintOverride)
    FVector GetSpawnPositionServer_Scriptable(AGothicCharacter owner, TSubclassOf<UObject> actorToSpawnClass) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRMagicPose(owner)) return Bridge.GetVRProjectileSpawnOrigin();
        return Super::GetSpawnPositionServer_Scriptable(owner, actorToSpawnClass);
    }
}

UCLASS(meta=(ReplaceParentClass))
class UGA_Spell_BallLightning_GothicVR : UGA_Spell_BallLightning
{
    UFUNCTION(BlueprintOverride)
    FVector GetSpawnPositionServer_Scriptable(AGothicCharacter owner, TSubclassOf<UObject> actorToSpawnClass) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRMagicPose(owner)) return Bridge.GetVRProjectileSpawnOrigin();
        return Super::GetSpawnPositionServer_Scriptable(owner, actorToSpawnClass);
    }
}

UCLASS(meta=(ReplaceParentClass))
class UGA_Spell_FistOfWind_GothicVR : UGA_Spell_FistOfWind
{
    UFUNCTION(BlueprintOverride)
    FVector GetSpawnPositionServer_Scriptable(AGothicCharacter owner, TSubclassOf<UObject> actorToSpawnClass) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRMagicPose(owner)) return Bridge.GetVRProjectileSpawnOrigin();
        return Super::GetSpawnPositionServer_Scriptable(owner, actorToSpawnClass);
    }

    UFUNCTION(BlueprintOverride)
    FRotator GetSpawnRotationServer_Scriptable(AGothicCharacter owner, TSubclassOf<UObject> actorToSpawnClass) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRMagicPose(owner))
            return MagicScript::FindLookAtRotation(Bridge.VRMagicOrigin, Bridge.VRMagicTarget);
        return Super::GetSpawnRotationServer_Scriptable(owner, actorToSpawnClass);
    }
}

UCLASS(meta=(ReplaceParentClass))
class UGA_Spell_BreathOfDeath_GothicVR : UGA_Spell_BreathOfDeath
{
    UFUNCTION(BlueprintOverride)
    FVector GetSpawnPositionServer_Scriptable(AGothicCharacter owner, TSubclassOf<UObject> actorToSpawnClass) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRMagicPose(owner)) return Bridge.GetVRProjectileSpawnOrigin();
        return Super::GetSpawnPositionServer_Scriptable(owner, actorToSpawnClass);
    }

    UFUNCTION(BlueprintOverride)
    FRotator GetSpawnRotationServer_Scriptable(AGothicCharacter owner, TSubclassOf<UObject> actorToSpawnClass) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRMagicPose(owner))
            return MagicScript::FindLookAtRotation(Bridge.VRMagicOrigin, Bridge.VRMagicTarget);
        return Super::GetSpawnRotationServer_Scriptable(owner, actorToSpawnClass);
    }
}

// Both the native multicast Initialize and Tick call this script method.
// Keep the target hurtbox, Niagara parameter and chaining chosen by Gothic.
UCLASS(meta=(ReplaceParentClass))
class ALightningRayVisual_GothicVR : ALightningRayVisual
{
    void UpdateRayPosition() override
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (!IsValid(Particle) || !IsValid(m_Target) || !Bridge.HasVRMagicPose(m_Source))
        {
            Super::UpdateRayPosition();
            return;
        }
        FVector Origin = Bridge.VRMagicOrigin;
        FVector Target = GetTargetPosition();
        SetActorRotation(MagicScript::FindLookAtRotation(Origin, Target));
        SetActorLocation(Origin);
        Particle.SetVectorParameter(ParticleEndPositionParameterName, FVector(Origin.Distance(Target), 0, 0));
    }
}

namespace GothicVRChainSight
{
    float Rank(UGothicVRInventoryBridge Bridge, FVector Point, float Range)
    {
        FVector Delta = Point - Bridge.VRChainEye;
        float Depth = Delta.DotProduct(Bridge.VRChainForward);
        float Distance = Delta.Size();
        FVector Up = Bridge.VRChainForward.CrossProduct(Bridge.VRChainRight);
        if (Depth <= 0.1f || Distance > Range ||
            Math::Abs(Delta.DotProduct(Bridge.VRChainRight)) > Depth * Bridge.VRChainHalfX ||
            Math::Abs(Delta.DotProduct(Up)) > Depth * Bridge.VRChainHalfY) return -1.0f;
        return Depth / Distance;
    }

    bool Visible(AActor Hero, AActor NPC, FVector Eye, FVector Point)
    {
        TArray<AActor> Ignore;
        Ignore.Add(Hero);
        FHitResult Hit;
        return !System::LineTraceSingle(Eye, Point, ETraceTypeQuery::Visibility, true, Ignore,
            EDrawDebugTrace::None, Hit, true) || Hit.GetActor() == NPC;
    }

    bool AtRelease(UGothicVRInventoryBridge Bridge, AActor Owner, AGothicCharacter Target, float Range)
    {
        if (!IsValid(Target) || Target.GetWorld() != Owner.GetWorld() ||
            Target.GetActorLocation().Distance(Owner.GetActorLocation()) > Range) return false;
        FVector Body = Target.GetActorLocation();
        if (Rank(Bridge, Body, Range) >= 0.0f && Visible(Owner, Target, Bridge.VRChainEye, Body)) return true;
        if (!IsValid(Target.Mesh) || !Target.Mesh.DoesSocketExist(n"head")) return false;
        FVector Head = Target.Mesh.GetSocketLocation(n"head");
        return Rank(Bridge, Head, Range) >= 0.0f && Visible(Owner, Target, Bridge.VRChainEye, Head);
    }
}

// Both shipped item definitions name their concrete cast ability. Only the first
// actor of a local VR cast is supplied here. The spell itself owns all links.
UCLASS(meta=(ReplaceParentClass))
class UGA_CastSpell_ChainLightning_GothicVR : UGA_CastSpell_ChainLightning
{
    UPROPERTY() AActor VRFirstLink;

    UFUNCTION(BlueprintOverride)
    AActor GetFocusedTarget_Scriptable(AActor AvatarActor) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRChainView(AvatarActor)) return Bridge.VRChainTarget;
        return Super::GetFocusedTarget_Scriptable(AvatarActor);
    }

    UFUNCTION(BlueprintOverride)
    bool CanLaunchSpellAbilityServer_Scriptable()
    {
        VRFirstLink = nullptr;
        auto Owner = GetAvatarActorFromActorInfo();
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (!Bridge.HasVRChainView(Owner)) return Super::CanLaunchSpellAbilityServer_Scriptable();
        auto FirstCandidate = Bridge.VRChainTarget;
        if (!GothicVRChainSight::AtRelease(Bridge, Owner, FirstCandidate, GetTraceRangeFromConfig_Scriptable()) ||
            !IsTargetValid_Script(Owner, FirstCandidate)) return false;
        VRFirstLink = FirstCandidate;
        Bridge.VRChainCasts += 1; Bridge.VRChainLastTarget = FirstCandidate.GetPathName();
        if (GetTarget() != FirstCandidate) ActivateTarget(FirstCandidate);
        return true;
    }

    UFUNCTION(BlueprintOverride)
    FGameplayEventData GetTargetEventData_Scriptable(AActor Actor)
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (IsValid(VRFirstLink) && Bridge.HasVRChainView(GetAvatarActorFromActorInfo()))
            return Super::GetTargetEventData_Scriptable(VRFirstLink);
        return Super::GetTargetEventData_Scriptable(Actor);
    }
}

// Both shipped item definitions name their concrete cast ability. Only the first
// actor of a local VR cast is supplied here. The spell itself owns all links.
UCLASS(meta=(ReplaceParentClass))
class UGA_CastSpell_Scroll_ChainLightning_GothicVR : UGA_CastSpell_Scroll_ChainLightning
{
    UPROPERTY() AActor VRScrollFirstLink;

    UFUNCTION(BlueprintOverride)
    AActor GetFocusedTarget_Scriptable(AActor AvatarActor) const
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (Bridge.HasVRChainView(AvatarActor)) return Bridge.VRChainTarget;
        return Super::GetFocusedTarget_Scriptable(AvatarActor);
    }

    UFUNCTION(BlueprintOverride)
    bool CanLaunchSpellAbilityServer_Scriptable()
    {
        VRScrollFirstLink = nullptr;
        auto Owner = GetAvatarActorFromActorInfo();
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (!Bridge.HasVRChainView(Owner)) return Super::CanLaunchSpellAbilityServer_Scriptable();
        auto FirstCandidate = Bridge.VRChainTarget;
        if (!GothicVRChainSight::AtRelease(Bridge, Owner, FirstCandidate, GetTraceRangeFromConfig_Scriptable()) ||
            !IsTargetValid_Script(Owner, FirstCandidate)) return false;
        VRScrollFirstLink = FirstCandidate;
        Bridge.VRChainCasts += 1; Bridge.VRChainLastTarget = FirstCandidate.GetPathName();
        if (GetTarget() != FirstCandidate) ActivateTarget(FirstCandidate);
        return true;
    }

    UFUNCTION(BlueprintOverride)
    FGameplayEventData GetTargetEventData_Scriptable(AActor Actor)
    {
        auto Bridge = UGothicVRInventoryBridge.GetDefaultObject();
        if (IsValid(VRScrollFirstLink) && Bridge.HasVRChainView(GetAvatarActorFromActorInfo()))
            return Super::GetTargetEventData_Scriptable(VRScrollFirstLink);
        return Super::GetTargetEventData_Scriptable(Actor);
    }
}
