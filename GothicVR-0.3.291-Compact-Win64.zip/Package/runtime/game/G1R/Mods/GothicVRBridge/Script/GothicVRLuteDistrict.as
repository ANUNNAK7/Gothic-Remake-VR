// All audience paths use the same physical distance in Unreal centimetres.
bool VRLuteInRange(AGothicCharacter Hero, AGothicCharacter N)
{
    const float RadiusCm = 1000.0f;
    return IsValid(Hero) && IsValid(N) && N != Hero && N.GetWorld() == Hero.GetWorld() &&
        (N.GetActorLocation() - Hero.GetActorLocation()).SizeSquared() <= RadiusCm * RadiusCm;
}

struct FVRLuteDistrict
{
    UPROPERTY() TArray<AGothicCharacter> Candidates;
    float NextRefresh = -1.0f;

    void Reset()
    {
        Candidates.Reset();
        NextRefresh = -1.0f;
    }

    bool InRange(AGothicCharacter Hero, AGothicCharacter N) const
    {
        return VRLuteInRange(Hero, N);
    }

    void Refresh(AGothicCharacter Hero, float Now)
    {
        if (!IsValid(Hero) || !IsValid(Hero.CharacterState)) { Reset(); return; }
        if (Now < NextRefresh) return;
        NextRefresh = Now + 2.0f;
        // Seated residents may have disabled their pawn collision. Discover spawned
        // characters periodically, then check their live positions again before admission.
        TArray<AGothicCharacter> Spawned;
        GetAllActorsOfClass(AGothicCharacter, Spawned);
        Candidates.Reset();
        for (auto N : Spawned)
        {
            if (VRLuteInRange(Hero, N) && IsValid(N.CharacterState) && N.IsHuman() && !N.IsDead())
                Candidates.Add(N);
        }
    }
}
